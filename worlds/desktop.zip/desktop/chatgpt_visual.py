from __future__ import annotations

from dataclasses import dataclass
import json
import time

from worlds.desktop.chatgpt_bootstrap import (
    ChatGPTComposer,
    ChatGPTDesktopBootstrap,
    ChatGPTDesktopError,
    DesktopSendTiming,
)
from worlds.desktop.motor import KEY_ENTER
from worlds.desktop.visual_screen import ScreenRect, ScreenSensor, ScreenVisionError


_ATSPI_WINDOW_GEOMETRY = r'''
import json
import sys
import pyatspi

window_name = sys.argv[1] if len(sys.argv) > 1 else ""

def safe_name(node):
    try:
        return node.name or ""
    except Exception:
        return ""

def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""

def has_state(node, state_value):
    try:
        return node.getState().contains(state_value)
    except Exception:
        return False

def children(node):
    try:
        return [node.getChildAtIndex(i) for i in range(node.childCount)]
    except Exception:
        return []

def walk(root, max_depth=10):
    stack = [(root, 0)]
    while stack:
        node, depth = stack.pop()
        yield node, depth
        if depth >= max_depth:
            continue
        for child in reversed(children(node)):
            stack.append((child, depth + 1))

def rect(node):
    try:
        ext = node.queryComponent().getExtents(pyatspi.DESKTOP_COORDS)
        return [int(ext.x), int(ext.y), int(ext.width), int(ext.height)]
    except Exception:
        return None

desktop = pyatspi.Registry.getDesktop(0)
best = None
best_score = -1
for app in children(desktop):
    if "firefox" not in safe_name(app).lower():
        continue
    for window in children(app):
        name = safe_name(window)
        if window_name and name != window_name:
            continue
        wr = rect(window)
        if wr is None or wr[2] < 300 or wr[3] < 250:
            continue
        score = wr[2] * wr[3] // 10000
        if has_state(window, pyatspi.STATE_ACTIVE):
            score += 5000
        showing_document = False
        chat_signal = False
        for node, depth in walk(window):
            if not has_state(node, pyatspi.STATE_SHOWING):
                continue
            role = safe_role(node).lower()
            node_name = safe_name(node).lower()
            if "document" in role:
                showing_document = True
                score += 500
            if "chatgpt" in node_name or node_name in {"you said:", "chatgpt said:"}:
                chat_signal = True
                score += 12000
        if window_name:
            score += 30000
        if showing_document:
            score += 500
        if chat_signal:
            score += 8000
        if score > best_score:
            best_score = score
            best = {"window": name, "rect": wr, "score": score}

if best is None:
    print(json.dumps({"ok": False, "reason": "visible Firefox window geometry not found"}))
else:
    print(json.dumps({"ok": True, **best}))
'''


@dataclass(frozen=True, slots=True)
class VisualGeometry:
    composer: ScreenRect
    window: ScreenRect

    @property
    def chat_region(self) -> ScreenRect:
        top = self.window.y + 45
        bottom = max(top + 80, self.composer.y - 20)
        return ScreenRect(
            self.window.x + 8,
            top,
            max(80, self.window.width - 16),
            max(80, bottom - top),
        )


class ChatGPTVisualDesktopBootstrap(ChatGPTDesktopBootstrap):
    """ChatGPT transport with visible pixels + physical keyboard/mouse as body.

    AT-SPI remains an auxiliary sense for exact-window/composer geometry and
    mentor text retrieval. Primary motor execution is ydotool/uinput and
    submission completion is observed from screen pixels.
    """

    def __init__(self, *args, screen: ScreenSensor | None = None, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.screen = screen or ScreenSensor()
        self._last_visual_geometry: VisualGeometry | None = None

    @staticmethod
    def _is_heiwa_protocol_draft(text: str) -> bool:
        """Recognize stale runtime-owned mentor protocol drafts conservatively.

        Firefox/AT-SPI can expose a contenteditable draft without its first
        paragraph, so the leading ``[HEIWA_...]`` marker is not always present.
        The visual transport therefore also accepts the exact machine-generated
        protocol body fingerprints, but only when the draft still contains the
        TARGET_MEANING and JSON-teacher instructions. Ordinary human text is not
        classified as Heiwa-owned merely because it mentions Heiwa.
        """

        normalized = (
            text.replace("\ufffc", "")
            .replace("\r\n", "\n")
            .replace("\r", "\n")
            .strip()
        )
        if not normalized:
            return False

        # Keep the proven legacy marker path.
        if normalized.startswith("[HEIWA_") or "[HEIWA_LANGUAGE_" in normalized:
            return True

        # AT-SPI sometimes drops the first contenteditable paragraph. Require
        # several independent fingerprints before authorizing destructive
        # stale-draft cleanup.
        protocol_bodies = (
            "This is the current Language network's real own speech attempt.",
            "This is Heiwa's own retry after local training.",
            "This is Heiwa Language network's own attempt in an explicit minimal question developmental context.",
        )
        has_body = any(body in normalized for body in protocol_bodies)
        has_meaning = "TARGET_MEANING=" in normalized
        has_json_instruction = "Return ONLY JSON" in normalized
        has_teacher_contract = (
            '"teacher_forms"' in normalized
            or '"teacher_form"' in normalized
            or "teacher_forms are explicit mentor correction" in normalized
        )
        return bool(
            has_body
            and has_meaning
            and has_json_instruction
            and has_teacher_contract
        )


    def send_message(self, text: str) -> ChatGPTComposer:
        if not isinstance(text, str) or not text:
            raise ValueError("bootstrap message must be a non-empty str")
        if not self.screen.available():
            self._diag("visual_body.unavailable", fallback="legacy_transport")
            return super().send_message(text)

        started = time.monotonic()
        try:
            composer = self._auxiliary_composer()
            geometry = self._visual_geometry(composer)
            resume = self._prepare_visual_composer(text, composer, geometry)
            activate_ms = (time.monotonic() - started) * 1000.0

            if not resume:
                before = self.screen.fingerprint(geometry.composer, cols=18, rows=7)
                self.motor.release_modifiers()
                self.motor.move_pointer_absolute(
                    geometry.composer.x + geometry.composer.width // 2,
                    geometry.composer.y + geometry.composer.height // 2,
                )
                self.motor.click_left()
                self.motor.type_unicode_linux(text)
                time.sleep(0.18)
                after = self.screen.fingerprint(geometry.composer, cols=18, rows=7)
                typed_distance = before.distance(after)
                self._diag(
                    "visual_body.typed",
                    chars=len(text),
                    visual_distance=round(typed_distance, 4),
                    keyboard_path="uinput_unicode",
                )
                if typed_distance < 0.008:
                    raise ChatGPTDesktopError(
                        "physical keyboard produced no visible composer change"
                    )

            send_started = time.monotonic()
            completed, composer_cleared, send_path = self._visual_submit(
                text,
                geometry,
            )
            send_ms = (time.monotonic() - send_started) * 1000.0
            if not completed:
                raise ChatGPTDesktopError(
                    "physical Enter was not visually confirmed; refusing blind duplicate submit"
                )

            total_motor_ms = (time.monotonic() - started) * 1000.0 - activate_ms
            self.last_send_timing = DesktopSendTiming(
                activate_ms=activate_ms,
                paste_send_ms=max(0.0, total_motor_ms),
                keyboard_path="physical_unicode",
                composer_verified=True,
                send_path=send_path,
                send_attempted=True,
                send_completed=True,
                composer_cleared=composer_cleared,
                send_ms=send_ms,
            )
            print(
                f"send_path={send_path} send_attempted=true send_completed=true "
                f"composer_cleared={str(composer_cleared).lower()} "
                f"visual=true send_ms={send_ms:.1f}",
                flush=True,
            )
            return composer or self._synthetic_composer(geometry)
        except ScreenVisionError as exc:
            self._diag("visual_body.sensor_error", error=str(exc))
            raise ChatGPTDesktopError(
                f"visual body sensor failed: {exc}"
            ) from exc


    def _auxiliary_composer(self) -> ChatGPTComposer | None:
        """Read accessibility state when available, but never require it."""

        try:
            return self.focus_composer()
        except ChatGPTDesktopError as exc:
            self._diag("visual_body.atspi_optional_miss", error=str(exc))
            return None

    def _synthetic_composer(self, geometry: VisualGeometry) -> ChatGPTComposer:
        window_name = ""
        if self._composer_hint is not None and len(self._composer_hint) >= 2:
            window_name = self._composer_hint[1]
        return ChatGPTComposer(
            application="Firefox",
            window=window_name,
            name="visual-composer",
            role="visual",
            text="",
            caret_offset=None,
            score=0,
            window_active=True,
            control_focused=True,
            document_showing=True,
        )


    def _prepare_visual_composer(
        self,
        text: str,
        composer: ChatGPTComposer | None,
        geometry: VisualGeometry,
    ) -> bool:
        """Physically focus and clear the dedicated Heiwa composer.

        During the developmental loop this composer is runtime-owned. Clearing
        it through the physical keyboard avoids stale-draft dependence on
        accessibility text reconstruction. `composer` is only auxiliary state
        and never authorizes the motor action.
        """

        self.motor.release_modifiers()
        self.motor.move_pointer_absolute(
            geometry.composer.x + geometry.composer.width // 2,
            geometry.composer.y + geometry.composer.height // 2,
        )
        self.motor.click_left()
        time.sleep(0.25)

        before_clear = self.screen.fingerprint(geometry.composer, cols=18, rows=7)
        self.motor.release_modifiers()
        self.motor.clear_focused_editable()
        time.sleep(0.25)
        after_clear = self.screen.fingerprint(geometry.composer, cols=18, rows=7)
        clear_distance = before_clear.distance(after_clear)
        self._diag(
            "visual_body.prepare",
            geometry_source="pixels",
            clear_distance=round(clear_distance, 4),
            auxiliary_atspi=composer is not None,
        )
        return False


    def _visual_geometry(
        self,
        composer: ChatGPTComposer | None,
    ) -> VisualGeometry:
        """Resolve body geometry without requiring an editable AT-SPI node."""

        window_hint: ScreenRect | None = None
        window_name = ""
        if composer is not None:
            window_name = composer.window
        elif self._composer_hint is not None and len(self._composer_hint) >= 2:
            window_name = self._composer_hint[1]

        resolved_window_name = ""
        try:
            raw = self._atspi.request(_ATSPI_WINDOW_GEOMETRY, (window_name,))
            payload = json.loads(raw)
            wr = payload.get("rect") if isinstance(payload, dict) else None
            if (
                isinstance(payload, dict)
                and payload.get("ok")
                and isinstance(wr, list)
                and len(wr) == 4
            ):
                window_hint = ScreenRect(*(int(v) for v in wr))
                resolved_window_name = str(payload.get("window", ""))
        except (ChatGPTDesktopError, json.JSONDecodeError, TypeError, ValueError) as exc:
            self._diag("visual_body.window_hint_miss", error=str(exc))

        # If accessibility can identify the containing ChatGPT Firefox frame,
        # use it only to bring that visible body surface forward. Composer
        # discovery itself remains pixel-based.
        if resolved_window_name:
            try:
                self._activate_exact_firefox_window(resolved_window_name, attempt=1)
                time.sleep(0.20)
            except ChatGPTDesktopError as exc:
                self._diag("visual_body.window_activation_optional_miss", error=str(exc))

        composer_rect, window_rect, score = self.screen.locate_chat_composer(
            window=window_hint,
        )
        geometry = VisualGeometry(composer=composer_rect, window=window_rect)
        self._last_visual_geometry = geometry
        self._diag(
            "visual_body.geometry",
            source="pixels",
            score=round(score, 3),
            composer=[
                composer_rect.x,
                composer_rect.y,
                composer_rect.width,
                composer_rect.height,
            ],
            window=[
                window_rect.x,
                window_rect.y,
                window_rect.width,
                window_rect.height,
            ],
            had_atspi_window_hint=window_hint is not None,
        )
        return geometry


    def _visual_submit(
        self,
        expected_text: str,
        geometry: VisualGeometry,
    ) -> tuple[bool, bool, str]:
        """Submit once and judge completion from visible consequences."""

        typed_composer = self.screen.fingerprint(geometry.composer, cols=18, rows=7)
        before_chat = self.screen.fingerprint(geometry.chat_region, cols=20, rows=12)

        self.motor.release_modifiers()
        self.motor.move_pointer_absolute(
            geometry.composer.x + geometry.composer.width // 2,
            geometry.composer.y + geometry.composer.height // 2,
        )
        self.motor.click_left()
        self.motor.key_press(KEY_ENTER)

        deadline = time.monotonic() + 6.0
        while time.monotonic() < deadline:
            time.sleep(0.30)
            now_composer = self.screen.fingerprint(geometry.composer, cols=18, rows=7)
            composer_delta = typed_composer.distance(now_composer)
            now_chat = self.screen.fingerprint(geometry.chat_region, cols=20, rows=12)
            chat_delta = before_chat.distance(now_chat)
            self._diag(
                "visual_body.submit_observe",
                composer_delta=round(composer_delta, 4),
                chat_delta=round(chat_delta, 4),
            )
            if composer_delta >= 0.035 or chat_delta >= 0.025:
                return True, bool(composer_delta >= 0.035), "visual_enter"

        # Attempt != completion. Never turn missing evidence into a second Enter.
        return False, False, "visual_enter_unconfirmed"

