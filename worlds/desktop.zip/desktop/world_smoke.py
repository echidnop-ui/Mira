from __future__ import annotations

import os
from pathlib import Path
import subprocess
import time
from uuid import uuid4

from contracts.cognition import ActionIntent
from worlds.desktop.adapter import (
    DesktopWorldAdapter,
    TYPE_TEXT_ACTION,
)


EXPECTED = "202608283141592653589793"


_FOCUS_TARGET = r"""
import time
import pyatspi

deadline = time.monotonic() + 5.0

while time.monotonic() < deadline:
    desktop = pyatspi.Registry.getDesktop(0)

    for app_index in range(desktop.childCount):
        try:
            app = desktop.getChildAtIndex(app_index)
            if app is None or app.name != "motor_target.py":
                continue
        except Exception:
            continue

        stack = [app]

        while stack:
            node = stack.pop()

            try:
                if (
                    node.getRole() == pyatspi.ROLE_TEXT
                    and node.queryComponent().grabFocus()
                ):
                    raise SystemExit(0)
            except Exception:
                pass

            try:
                for index in range(node.childCount):
                    child = node.getChildAtIndex(index)
                    if child is not None:
                        stack.append(child)
            except Exception:
                pass

    time.sleep(0.1)

raise SystemExit(1)
"""


def main() -> int:
    print("HEIWA DESKTOP WORLD SMOKE")

    project_root = Path(__file__).resolve().parents[2]

    target_env = os.environ.copy()
    target_env["GDK_BACKEND"] = "wayland"
    target_env["NO_AT_BRIDGE"] = "0"

    target = subprocess.Popen(
        (
            "/usr/bin/python3",
            "-m",
            "worlds.desktop.motor_target",
        ),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=str(project_root),
        env=target_env,
    )

    adapter = DesktopWorldAdapter()

    try:
        focus = subprocess.run(
            (
                "/usr/bin/python3",
                "-c",
                _FOCUS_TARGET,
            ),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=target_env,
            timeout=7.0,
        )

        print("focus_returncode:", focus.returncode)

        if focus.returncode != 0:
            print("focus_stderr:", focus.stderr.strip())
            print("WORLD SMOKE FAILED: target focus")
            return 2

        frame = adapter.poll(time.monotonic())

        print("observations:", len(frame.observations))
        print("affordances:", len(frame.affordances))
        print("completed_before_attempt:", len(frame.completed_actions))

        typing = [
            affordance
            for affordance in frame.affordances
            if affordance.action == TYPE_TEXT_ACTION
        ]

        if len(typing) != 1:
            print("WORLD SMOKE FAILED: type_text affordance")
            return 3

        affordance = typing[0]

        intent = ActionIntent(
            id=f"desktop-intent-{uuid4().hex}",
            transition_id=f"desktop-transition-{uuid4().hex}",
            affordance_id=affordance.id,
            world=adapter.world_id,
            action=affordance.action,
            created_at=time.monotonic(),
            parameters={"text": EXPECTED},
        )

        attempt = adapter.execute(
            intent,
            now=time.monotonic(),
        )

        print("attempt_accepted:", attempt.accepted)
        print("attempt_action:", attempt.action)
        print(
            "completion_unverified_at_attempt:",
            attempt.payload.get("completion_unverified"),
        )

        if not attempt.accepted:
            print(
                "WORLD SMOKE FAILED: attempt rejected:",
                attempt.payload.get("reason", ""),
            )
            return 4

        completed = ()
        deadline = time.monotonic() + 3.0

        while time.monotonic() < deadline:
            observed_frame = adapter.poll(time.monotonic())
            if observed_frame.completed_actions:
                completed = observed_frame.completed_actions
                break
            time.sleep(0.05)

        print("completed_observed:", len(completed))

        if len(completed) != 1:
            print("WORLD SMOKE FAILED: completion not observed")
            return 5

        action = completed[0]

        print("completed_status:", action.status)
        print("completed_succeeded:", action.succeeded)
        print(
            "completed_transition_preserved:",
            action.transition_id == intent.transition_id,
        )
        print(
            "completed_attempt_linked:",
            action.attempt_id == attempt.id,
        )
        print(
            "verified_by:",
            action.payload.get("verified_by"),
        )

        if not action.succeeded or action.status != "succeeded":
            print("WORLD SMOKE FAILED: bad CompletedAction")
            return 6

        if action.transition_id != intent.transition_id:
            print("WORLD SMOKE FAILED: transition_id lost")
            return 7

        if action.attempt_id != attempt.id:
            print("WORLD SMOKE FAILED: attempt linkage lost")
            return 8

        stdout, stderr = target.communicate(timeout=8.0)
        observed = stdout.strip().splitlines()
        final_text = observed[-1] if observed else ""

        print("target_text:", final_text)
        print("target_stderr:", stderr.strip())

        if final_text != EXPECTED:
            print("WORLD SMOKE FAILED: external text mismatch")
            return 9

        print(
            "CHAIN: DesktopWorldAdapter.poll -> Affordance -> ActionIntent -> "
            "ActionAttempt -> motor -> AT-SPI observation -> CompletedAction"
        )
        print("HEIWA DESKTOP WORLD SMOKE: OK")
        return 0

    finally:
        adapter.close()

        if target.poll() is None:
            target.terminate()
            try:
                target.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                target.kill()


if __name__ == "__main__":
    raise SystemExit(main())
