from __future__ import annotations

import os
from pathlib import Path
import subprocess
import time

from worlds.desktop.motor import DesktopMotor, DesktopMotorError


SOCKET = "/run/heiwa-ydotool.sock"
EXPECTED = "202608283141592653589793"


_FOCUS_TARGET = r"""
import time

import pyatspi


deadline = time.monotonic() + 5.0

while time.monotonic() < deadline:
    desktop = pyatspi.Registry.getDesktop(0)

    for application in desktop:
        try:
            if application.name != "motor_target.py":
                continue
        except Exception:
            continue

        stack = [application]
        while stack:
            node = stack.pop()
            try:
                if node.getRole() == pyatspi.ROLE_TEXT:
                    if node.queryComponent().grabFocus():
                        raise SystemExit(0)
                stack.extend(list(node))
            except Exception:
                continue

    time.sleep(0.1)

raise SystemExit(1)
"""


def main() -> int:
    print("HEIWA DESKTOP MOTOR SMOKE")

    motor = DesktopMotor(socket_path=SOCKET)

    if not motor.ready():
        print(
            "MOTOR SMOKE FAILED: DesktopMotor not ready "
            f"(socket={SOCKET})"
        )
        return 2

    target_env = os.environ.copy()
    target_env["GDK_BACKEND"] = "wayland"
    target_env["NO_AT_BRIDGE"] = "0"

    target = subprocess.Popen(
        (
            "/usr/bin/python3",
            "-m",
            "worlds.desktop.motor_target",
        ),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=str(
            Path(__file__).resolve().parents[2]
        ),
        env=target_env,
    )

    try:
        # GNOME/Wayland blocks background clients from stealing global focus.
        # AT-SPI selects the disposable Entry; DesktopMotor still supplies all
        # text through ydotool -> ydotoold -> uinput.
        focus = subprocess.run(
            (
                "/usr/bin/python3",
                "-c",
                _FOCUS_TARGET,
            ),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=target_env,
            timeout=7.0,
        )

        print("focus_returncode:", focus.returncode)
        if focus.returncode != 0:
            print("focus_stderr:", focus.stderr.strip())
            print("MOTOR SMOKE FAILED: GTK focus")
            return 4

        try:
            injected = motor.type_text(EXPECTED)
        except DesktopMotorError as exc:
            print("MOTOR SMOKE FAILED: injection command")
            print("motor_error:", str(exc))
            return 5

        stdout, stderr = target.communicate(
            timeout=8.0
        )

        observed = stdout.strip().splitlines()
        final_text = observed[-1] if observed else ""

        print("ydotool_returncode:", injected.returncode)
        print("ydotool_stderr:", injected.stderr.strip())
        print("target_text:", final_text)
        print("target_stderr:", stderr.strip())

        if final_text != EXPECTED:
            print("MOTOR SMOKE FAILED: text mismatch")
            return 6

        print(
            "CHAIN: DesktopMotor -> ydotool -> ydotoold/uinput -> "
            "focused GTK entry -> observed target text"
        )
        print("HEIWA DESKTOP MOTOR SMOKE: OK")
        return 0

    finally:
        if target.poll() is None:
            target.terminate()
            try:
                target.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                target.kill()


if __name__ == "__main__":
    raise SystemExit(main())
