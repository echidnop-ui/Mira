from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import select
import struct
import threading
import time
from uuid import uuid4

import torch
import torch.nn.functional as F

from contracts.cognition import ActionAttempt, ActionIntent, Affordance, CompletedAction, Consequence, Observation
from worlds.desktop.inference import NeuralDesktopInference
from worlds.desktop.motor import DesktopMotor, DesktopMotorError, MotorResult
from worlds.desktop.neural import ACTION_KINDS, VisualState
from worlds.desktop.ownership import PhysicalActionArbiter
from worlds.desktop.training.input_events import EV_ABS, EV_KEY, EV_REL, REL_X, REL_Y, EvdevInputCollector, InputCaptureUnavailable, RawInputEvent
from worlds.interface import WorldFrame, validate_intent_for_world


WORLD_ID = "desktop:neural"

# Dedicated human-feedback command keys emitted by Input Remapper.
# Linux input-event codes: F23=193, F24=194. These are intentionally
# separate from ordinary Backspace/Enter so normal editing/submission remains untouched.
KEY_F23 = 193
KEY_F24 = 194


@dataclass(slots=True)
class _Pending:
    attempt: ActionAttempt
    before_state: VisualState
    action_kind: int
    parameters: tuple[float, float, float, float]
    predicted_latent: torch.Tensor
    before_frame: torch.Tensor
    action_started_ns: int
    action_finished_ns: int


class NeuralSafetyGate:
    """Mechanical action limiter. It can reject but never select a target."""
    def __init__(self, *, emergency_stop: str | Path = "state/desktop.EMERGENCY_STOP", confidence: float = 0.55, max_actions_per_second: float = 3.0, emergency_key_code: int = 88) -> None:
        self.emergency_stop = Path(emergency_stop)
        self.minimum_confidence = float(confidence)
        self.minimum_interval = 1.0 / float(max_actions_per_second)
        self.last_action_at = float("-inf")
        self._key_stop = _EmergencyKeyMonitor(emergency_key_code)

    def check(self, *, confidence: float, now: float) -> tuple[bool, str]:
        if self.emergency_stop.exists() or self._key_stop.triggered: return False, f"emergency stop active: {self.emergency_stop} or key"
        if confidence < self.minimum_confidence: return False, "neural motor confidence below safety threshold"
        if now - self.last_action_at < self.minimum_interval: return False, "action rate limited"
        return True, ""

    def allow(self, *, confidence: float, now: float) -> tuple[bool, str]:
        allowed, reason = self.check(confidence=confidence, now=now)
        if not allowed: return False, reason
        self.last_action_at = now; return True, ""


def _forwarded_pointer_duplicate(event: RawInputEvent) -> bool:
    """Input Remapper pointer output duplicates the physical mouse endpoint."""
    name = event.device_name.casefold()
    if "input-remapper" not in name and "input remapper" not in name:
        return False
    if "forwarded" not in name:
        return False
    return event.event_type in {EV_REL, EV_ABS} or (
        event.event_type == EV_KEY and 272 <= int(event.code) <= 279
    )


class _EmergencyKeyMonitor:
    """Best-effort Linux evdev emergency key listener (F12 by default)."""
    _EVENT = struct.Struct("llHHI")
    def __init__(self, key_code: int) -> None:
        self.triggered = False; self.key_code = int(key_code); self._files: list[object] = []
        input_root = Path("/dev/input")
        for path in input_root.glob("event*") if input_root.exists() else ():
            try: self._files.append(path.open("rb", buffering=0))
            except OSError: pass
        if self._files:
            threading.Thread(target=self._run, name="heiwa-emergency-key", daemon=True).start()

    def _run(self) -> None:
        while not self.triggered:
            readable, _, _ = select.select(self._files, [], [], 0.5)
            for stream in readable:
                data = stream.read(self._EVENT.size)
                if len(data) != self._EVENT.size: continue
                _, _, event_type, code, value = self._EVENT.unpack(data)
                if event_type == 1 and code == self.key_code and value == 1:
                    self.triggered = True; return


class NeuralDesktopWorldAdapter:
    """Pixel-first Desktop World. AT-SPI is absent from this production path."""
    def __init__(
        self, inference: NeuralDesktopInference, *, motor: DesktopMotor | None = None,
        safety: NeuralSafetyGate | None = None, allow_clicks: bool = False,
        allow_right_clicks: bool = False, allow_typing: bool = False,
        allow_mouse: bool = True, allow_keyboard: bool = True,
        capture_input: bool = True, online_learning: bool = True,
        learn_stationary_desktop: bool = True,
        action_arbiter: PhysicalActionArbiter | None = None,
    ) -> None:
        self.inference = inference; self.motor = motor or DesktopMotor(); self.safety = safety or NeuralSafetyGate()
        self.allow_clicks = bool(allow_clicks); self.allow_right_clicks = bool(allow_right_clicks)
        self.allow_typing = bool(allow_typing); self.allow_mouse = bool(allow_mouse)
        self.allow_keyboard = bool(allow_keyboard)
        self._affordances: dict[str, Affordance] = {}; self._pending: _Pending | None = None; self._closed = False
        self._pointer: tuple[int, int] | None = None
        self.capture_input = bool(capture_input); self._input: EvdevInputCollector | None = None
        self.online_learning = bool(online_learning)
        self.learn_stationary_desktop = bool(learn_stationary_desktop)
        self.action_arbiter = action_arbiter or PhysicalActionArbiter()
        self._input_status = "starting" if self.capture_input else "disabled"
        self._last_capture_ns: int | None = None
        # Physical human feedback is carried by dedicated remapped keys:
        # F23 = strong universal "change this"; F24 = explicit universal
        # acceptance of the most recent behaviour.  Speech gets an additional
        # surface-language confirmation, but neither key asserts factual truth.
        # Ordinary Backspace and Enter are deliberately not feedback channels.
        self._pending_pointer_feedback: dict[str, object] | None = None
        self._pointer_feedback_grace_ns = int(0.40 * 1_000_000_000)
        self._pointer_feedback_deadzone = 18.0

    @property
    def world_id(self) -> str: return WORLD_ID

    def poll(self, now: float) -> WorldFrame:
        proposal = self.inference.capture_and_propose()
        capture_ns = time.monotonic_ns()
        state = self.inference.state
        assert state is not None
        if self._input is None and self.capture_input and self._input_status == "starting":
            try:
                self._input = EvdevInputCollector(
                    screen_width=proposal.screen_width, screen_height=proposal.screen_height
                ); self._input.start(); self._input_status = "linux-evdev"
            except InputCaptureUnavailable as exc:
                self._input_status = f"unavailable: {exc}"
        physical_events: tuple[RawInputEvent, ...] = ()
        previous_capture_ns = self._last_capture_ns
        if self._input is not None and self._last_capture_ns is not None:
            physical_events = self._input.drain(self._last_capture_ns, capture_ns)
        attributed_events = tuple(
            event for event in physical_events if not _forwarded_pointer_duplicate(event)
        )
        self._last_capture_ns = capture_ns
        completed: tuple[CompletedAction, ...] = (); consequences: tuple[Consequence, ...] = ()
        pointer_correction_payload: dict[str, object] | None = None

        # Do not mistake the tiny hand movement that normally precedes a click
        # for a correction.  Candidate pointer corrections wait briefly.  If a
        # physical mouse button is pressed during that grace window, the motion
        # is interpreted as click positioning and discarded as feedback.
        mouse_button_down = any(
            event.event_type == EV_KEY and event.value == 1 and 272 <= int(event.code) <= 279
            for event in attributed_events
        )
        if self._pending_pointer_feedback is not None:
            candidate = self._pending_pointer_feedback
            if mouse_button_down:
                self._pending_pointer_feedback = None
            elif capture_ns >= int(candidate["commit_after_ns"]):
                motor_metrics = self.inference.learn_pointer_correction(
                    before_state=candidate["before_state"],
                    target_xy=tuple(candidate["corrected_target_xy"]),
                    repeats=3,
                ) if self.online_learning else {"pointer_feedback": "online_learning_disabled"}
                pointer_correction_payload = {
                    key: value for key, value in candidate.items()
                    if key not in {"before_state", "commit_after_ns"}
                }
                pointer_correction_payload["motor_learning"] = motor_metrics
                pointer_correction_payload["click_guard_ms"] = 400
                pointer_correction_payload["deadzone_raw"] = self._pointer_feedback_deadzone
                self._pending_pointer_feedback = None
        if self._pending is not None:
            pending = self._pending; self._pending = None
            # A physical mouse move immediately after Heiwa's own mouse action is
            # treated as a soft directional correction, not as generic negative
            # feedback and never as proof of truth.  Only events after actuation
            # finished are eligible, so ordinary user motion before Heiwa acted
            # cannot be misattributed.
            pending_action = pending.attempt.action.removeprefix("desktop.")
            correction_events = tuple(
                event for event in attributed_events
                if event.timestamp_ns > pending.action_finished_ns
                and event.event_type == EV_REL and event.code in {REL_X, REL_Y}
            )
            correction_dx = sum(event.value for event in correction_events if event.code == REL_X)
            correction_dy = sum(event.value for event in correction_events if event.code == REL_Y)
            correction_magnitude = (float(correction_dx) ** 2 + float(correction_dy) ** 2) ** 0.5
            if (pending_action in {"move_pointer", "left_click", "double_click", "right_click", "scroll"}
                    and correction_magnitude >= self._pointer_feedback_deadzone
                    and not mouse_button_down):
                # Raw evdev deltas are device units, not screen pixels.  Preserve
                # direction and map intent strength to a bounded normalized step.
                # The actual learning is delayed for a short click-intent grace
                # period so a small aiming nudge followed by a click is ignored.
                direction_x = float(correction_dx) / correction_magnitude
                direction_y = float(correction_dy) / correction_magnitude
                step = min(0.35, max(0.05, correction_magnitude / 600.0))
                corrected_x = min(max(float(pending.parameters[0]) + direction_x * step, 0.0), 1.0)
                corrected_y = min(max(float(pending.parameters[1]) + direction_y * step, 0.0), 1.0)
                self._pending_pointer_feedback = {
                    "signal": "change_motor_target",
                    "negative_evidence": True,
                    "truth_value": "unknown",
                    "source": "physical_pointer_motion",
                    "target_transition_id": pending.attempt.transition_id,
                    "target_action": pending.attempt.action,
                    "relative_dx": int(correction_dx),
                    "relative_dy": int(correction_dy),
                    "relative_magnitude": correction_magnitude,
                    "direction": (direction_x, direction_y),
                    "previous_target_xy": (float(pending.parameters[0]), float(pending.parameters[1])),
                    "corrected_target_xy": (corrected_x, corrected_y),
                    "devices": tuple(dict.fromkeys(event.device_name for event in correction_events)),
                    "before_state": pending.before_state,
                    "commit_after_ns": capture_ns + self._pointer_feedback_grace_ns,
                }
            # Patch tokens are a direct function of pixels. Recurrent latent
            # state may drift between identical frames and is therefore not
            # sufficient evidence that a physical action changed the screen.
            patch_change = 1.0 - F.cosine_similarity(
                pending.before_state.patch_tokens, state.patch_tokens, dim=-1
            )
            change = float(patch_change.mean())
            # Any physical event after the causal before-frame contaminates
            # attribution, including a user action just before actuation.
            interfering = tuple(
                event for event in attributed_events
                if event.event_type in {EV_KEY, EV_REL, EV_ABS}
            )
            causal_before_ns = previous_capture_ns or pending.action_started_ns
            foreign_windows = self.action_arbiter.foreign_windows("heiwa", causal_before_ns, capture_ns)
            if self._input is None:
                ownership = "unknown_input_attribution"
            elif interfering:
                ownership = "mixed_user_interference"
            elif foreign_windows:
                ownership = "mixed_" + "+".join(sorted({window.source for window in foreign_windows})) + "_interference"
            else:
                ownership = "heiwa"
            succeeded = change > 1e-4 if ownership == "heiwa" else False
            interference_summary = tuple({"device": event.device_name, "type": event.event_type,
                                           "code": event.code, "value": event.value,
                                           "timestamp_ns": event.timestamp_ns}
                                          for event in interfering[:16])
            ignored_forwarded_duplicates = len(physical_events) - len(attributed_events)
            assert self.inference.last_frame is not None
            errors = self.inference.learn_transition(
                before_frame=pending.before_frame, after_frame=self.inference.last_frame,
                before_state=pending.before_state, after_state=state,
                action_kind=pending.action_kind, parameters=pending.parameters,
                ownership=ownership, completion=succeeded if ownership == "heiwa" else None,
            ) if self.online_learning else {"online_learning": "disabled"}
            if "observed_target_x" in errors and "observed_target_y" in errors:
                observed_x = float(errors["observed_target_x"]); observed_y = float(errors["observed_target_y"])
                errors["target_error_px"] = (
                    ((observed_x - pending.parameters[0]) * proposal.screen_width) ** 2
                    + ((observed_y - pending.parameters[1]) * proposal.screen_height) ** 2
                ) ** 0.5
            predicted_error = float(F.smooth_l1_loss(pending.predicted_latent, state.latent).cpu())
            action = CompletedAction(
                    id=f"desktop-completed-{uuid4().hex}", attempt_id=pending.attempt.id,
                    intent_id=pending.attempt.intent_id, transition_id=pending.attempt.transition_id,
                    world=self.world_id, action=pending.attempt.action, completed_at=now,
                    status=("observed_effect" if succeeded else "no_observed_effect") if ownership == "heiwa" else "ownership_uncertain",
                    succeeded=succeeded,
                    payload={"verified_by": "neural_visual_state_change", "latent_change": change,
                             "predicted_consequence_error": predicted_error,
                             "ownership": ownership,
                             "external_event_count": len(interfering),
                             "ignored_forwarded_pointer_duplicates": ignored_forwarded_duplicates,
                             "external_events": interference_summary, **errors},
                )
            completed = (action,); consequences = (Consequence(
                id=f"desktop-consequence-{uuid4().hex}", transition_id=action.transition_id,
                world=self.world_id, kind="desktop.visual_effect", observed_at=now,
                completed_action_id=action.id, payload={"latent_change": change,
                                                       "predicted_consequence_error": predicted_error,
                                                       "ownership": ownership,
                                                       "external_event_count": len(interfering),
                                                       "ignored_forwarded_pointer_duplicates": ignored_forwarded_duplicates,
                                                       "external_events": interference_summary,
                                                       "foreign_action_sources": tuple(window.source for window in foreign_windows),
                                                       "local_prediction_losses": errors},
            ),)
        elif self.inference.previous_frame is not None and self.inference.previous_state is not None:
            patch_change = 1.0 - F.cosine_similarity(
                self.inference.previous_state.patch_tokens, state.patch_tokens, dim=-1
            )
            passive_change = float(patch_change.mean())
            # Learn the temporal law of the desktop from lived frames, including
            # stationary ones. This teaches prediction of both change and stillness;
            # motion itself is not treated as a positive reward.
            if self.online_learning and (self.learn_stationary_desktop or physical_events or passive_change > 1e-4):
                assert self.inference.last_frame is not None
                self.inference.learn_transition(
                    before_frame=self.inference.previous_frame,
                    after_frame=self.inference.last_frame,
                    before_state=self.inference.previous_state,
                    after_state=state, action_kind=ACTION_KINDS.index("noop"),
                    parameters=(0.0, 0.0, 0.0, 0.0),
                    ownership="user" if physical_events else "environment",
                    completion=None,
                )
        # Explicit physical feedback on dedicated command keys produced by
        # Input Remapper. F23 is a universal negative/change signal. F24 is a
        # narrower positive signal meaning only "the recent Heiwa text was written
        # correctly". Neither key asserts factual truth.
        key_downs = tuple(
            event for event in physical_events
            if event.event_type == EV_KEY and event.value == 1
        )
        user_change_commands = tuple(event for event in key_downs if event.code == KEY_F23)
        user_confirm_commands = tuple(event for event in key_downs if event.code == KEY_F24)

        observation = Observation(
            id=f"desktop-observation-{uuid4().hex}", world=self.world_id,
            kind="desktop.neural_visual_state", observed_at=now,
            payload={"latent": tuple(float(v) for v in state.latent[0].cpu()),
                     "frame_digest": proposal.frame_digest,
                     "regions": tuple(tuple(float(v) for v in box) for box in state.region_positions[0].cpu()),
                     "salience": tuple(float(v) for v in state.salience[0].cpu()),
                     "input_attribution": self._input_status,
                     "external_input_events": len(physical_events),
                     "external_action_is_feedback": bool(user_change_commands or user_confirm_commands or pointer_correction_payload),
                     "user_universal_correction": bool(user_change_commands),
                     "user_universal_correction_count": len(user_change_commands),
                     "user_universal_confirmation": bool(user_confirm_commands),
                     "user_universal_confirmation_count": len(user_confirm_commands),
                     "user_pointer_correction": bool(pointer_correction_payload),
                     "visual_read_byte_ids": proposal.read_byte_ids,
                     "visual_read_confidence": proposal.read_confidence,
                     "visual_read_bbox": proposal.target_bbox,
                     "neural_proposed_action": proposal.action,
                     "neural_action_probabilities": proposal.action_distribution},
        )
        observations = [observation]
        if pointer_correction_payload is not None:
            observations.append(Observation(
                id=f"desktop-user-pointer-correction-{uuid4().hex}", world=self.world_id,
                kind="desktop.user_pointer_correction", observed_at=now,
                payload=pointer_correction_payload,
            ))
        if user_change_commands:
            observations.append(Observation(
                id=f"desktop-user-correction-{uuid4().hex}", world=self.world_id,
                kind="desktop.user_universal_correction", observed_at=now,
                payload={
                    "signal": "change_behavior",
                    "negative_evidence": True,
                    "truth_value": "unknown",
                    "source": "input_remapper_f23",
                    "count": len(user_change_commands),
                    "devices": tuple(dict.fromkeys(event.device_name for event in user_change_commands)),
                },
            ))
        if user_confirm_commands:
            observations.append(Observation(
                id=f"desktop-user-universal-confirmation-{uuid4().hex}", world=self.world_id,
                kind="desktop.user_universal_confirmation", observed_at=now,
                payload={
                    "signal": "accept_recent_behavior",
                    "positive_behavior_evidence": True,
                    "truth_value": "unknown",
                    "source": "input_remapper_f24",
                    "dedicated_command_key": "F24",
                    "count": len(user_confirm_commands),
                    "devices": tuple(dict.fromkeys(event.device_name for event in user_confirm_commands)),
                },
            ))
        # NeuralDesktopBody is a specialist: its motor head proposes a
        # distribution, while shared Heiwa Policy remains the final cognitive
        # selector.  Offer every mechanically executable primitive as a dynamic
        # affordance and attach the specialist probability as a generic prior.
        self._affordances = {}
        if len(proposal.action_distribution) == len(ACTION_KINDS):
            probabilities = {
                action: max(float(proposal.action_distribution[index]), 1e-8)
                for index, action in enumerate(ACTION_KINDS)
            }
        else:
            # Compatibility with older/fake inference providers that exposed
            # only the selected action.  Keep alternatives alive with a tiny
            # prior instead of collapsing the World back to one affordance.
            probabilities = {action: 1e-8 for action in ACTION_KINDS}
            if proposal.action in probabilities:
                probabilities[proposal.action] = 1.0

        candidate_actions: list[str] = ["noop"]
        motor_ready, _ = self.safety.check(confidence=proposal.confidence, now=now)
        if motor_ready and self.allow_mouse:
            candidate_actions.extend(("move_pointer", "scroll"))
            if self.allow_clicks:
                candidate_actions.extend(("left_click", "double_click"))
            if self.allow_right_clicks:
                candidate_actions.append("right_click")
        if motor_ready and self.allow_keyboard and self.allow_typing:
            candidate_actions.extend(("key_press", "type_text"))
        # key_chord is intentionally not offered yet: the current neural motor
        # head does not parameterize a complete chord, so exposing it would
        # create an affordance that the executor cannot realize causally.

        ranked = sorted(candidate_actions, key=lambda action: probabilities[action], reverse=True)
        for rank, action in enumerate(ranked):
            affordance = Affordance(
                id=f"desktop-affordance-{uuid4().hex}", world=self.world_id,
                action=f"desktop.{action}", offered_at=now,
                payload={
                    "neural_target_x": proposal.x, "neural_target_y": proposal.y,
                    "neural_key_code": proposal.key_code,
                    "frame_digest": proposal.frame_digest,
                    "neural_confidence": proposal.confidence,
                    "neural_proposed_action": proposal.action,
                    "neural_action_probability": probabilities[action],
                    "policy_prior_probability": probabilities[action],
                    "neural_action_rank": rank,
                    "neural_action_probabilities": proposal.action_distribution,
                    "neural_target_bbox": proposal.target_bbox,
                    "neural_trajectory": proposal.trajectory,
                    "visual_read_byte_ids": proposal.read_byte_ids,
                    "visual_read_confidence": proposal.read_confidence,
                    "screen_width": proposal.screen_width, "screen_height": proposal.screen_height,
                },
                constraints={
                    "pixel_only": True, "physical_input": True,
                    "neural_motor_candidate": True, "shared_policy_selects": True,
                },
            )
            self._affordances[affordance.id] = affordance
        return WorldFrame(self.world_id, now, tuple(observations), tuple(self._affordances.values()), completed, consequences)

    def execute(self, intent: ActionIntent, now: float) -> ActionAttempt:
        validate_intent_for_world(intent, world_id=self.world_id)
        offered = self._affordances.get(intent.affordance_id)
        if offered is None or offered.action != intent.action: return self._reject(intent, now, "stale or mismatched affordance")
        confidence = float(offered.payload["neural_confidence"])
        x, y = int(offered.payload["neural_target_x"]), int(offered.payload["neural_target_y"])
        if self._pointer is None:
            self._pointer = (int(offered.payload["screen_width"]) // 2, int(offered.payload["screen_height"]) // 2)
        action = intent.action.removeprefix("desktop.")
        if action in {"move_pointer", "left_click", "double_click", "right_click", "scroll"} and not self.allow_mouse:
            return self._reject(intent, now, "mouse execution disabled by persistent autonomy config")
        if action in {"key_press", "type_text", "key_chord"} and not self.allow_keyboard:
            return self._reject(intent, now, "keyboard execution disabled by persistent autonomy config")
        if action in {"left_click", "double_click"} and not self.allow_clicks:
            return self._reject(intent, now, "click execution requires --allow-clicks")
        if action == "right_click" and not self.allow_right_clicks:
            return self._reject(intent, now, "right click execution requires --allow-right-clicks")
        if action in {"key_press", "type_text", "key_chord"} and not self.allow_typing:
            return self._reject(intent, now, "keyboard execution requires --allow-typing")
        if action != "noop":
            allowed, reason = self.safety.allow(confidence=confidence, now=now)
            if not allowed: return self._reject(intent, now, reason)
        if action == "key_press" and "key_code" not in intent.parameters:
            from dataclasses import replace
            intent = replace(intent, parameters={"key_code": int(offered.payload["neural_key_code"])})
        action_started_ns = time.monotonic_ns()
        try:
            with self.action_arbiter.claim("heiwa"):
                result = self._actuate(action, x, y, intent, offered)
        except (DesktopMotorError, ValueError, TypeError) as exc: return self._reject(intent, now, str(exc))
        action_finished_ns = time.monotonic_ns()
        attempt = ActionAttempt(
            id=f"desktop-attempt-{uuid4().hex}", intent_id=intent.id, transition_id=intent.transition_id,
            world=self.world_id, action=intent.action, attempted_at=now, accepted=True,
            payload={"motor_returncode": result.returncode, "neural_target": (x, y),
                     "neural_confidence": confidence, "completion_unverified": True},
        )
        assert self.inference.state is not None
        assert self.inference.last_frame is not None
        normalized = (x / max(int(offered.payload["screen_width"]), 1), y / max(int(offered.payload["screen_height"]), 1), 0.0, 0.0)
        action_index = ACTION_KINDS.index(action)
        before_state = self.inference.state.detached()
        with torch.inference_mode():
            predicted, _ = self.inference.model.predict_next(
                before_state, torch.tensor([action_index], device=self.inference.device),
                torch.tensor([normalized], device=self.inference.device),
            )
        self._pending = _Pending(
            attempt, before_state, action_index, normalized, predicted.detach(),
            self.inference.last_frame.detach().clone(), action_started_ns, action_finished_ns,
        )
        self.inference.remember_action(action_index, normalized)
        return attempt

    def _move_neurally(self, x: int, y: int, offered: Affordance) -> MotorResult:
        assert self._pointer is not None
        sx, sy = self._pointer; width = int(offered.payload["screen_width"]); height = int(offered.payload["screen_height"])
        duration_raw, bend_x, bend_y = tuple(float(v) for v in offered.payload["neural_trajectory"])
        duration = 0.03 + 0.17 * (duration_raw + 1.0) / 2.0
        cx = (sx + x) / 2 + bend_x * width * 0.12; cy = (sy + y) / 2 + bend_y * height * 0.12
        points = []
        for step in range(1, 7):
            t = step / 6; u = 1 - t
            points.append((round(u*u*sx + 2*u*t*cx + t*t*x), round(u*u*sy + 2*u*t*cy + t*t*y)))
        result = self.motor.move_pointer_trajectory(tuple(points), duration=duration)
        self._pointer = (x, y); return result

    def _actuate(self, action: str, x: int, y: int, intent: ActionIntent, offered: Affordance) -> MotorResult:
        if action == "noop": return MotorResult(0, "", "")
        if action == "move_pointer": return self._move_neurally(x, y, offered)
        if action in {"left_click", "double_click", "right_click"}:
            self._move_neurally(x, y, offered)
            return {"left_click": self.motor.click_left, "double_click": self.motor.double_click_left, "right_click": self.motor.click_right}[action]()
        if action == "scroll": return self.motor.scroll(int(intent.parameters.get("dy", 1)))
        if action == "key_press": return self.motor.press_key(int(intent.parameters["key_code"]))
        if action == "type_text": return self.motor.type_unicode_linux(str(intent.parameters["text"]))
        if action == "key_chord": return self.motor.press_chord(tuple(int(v) for v in intent.parameters["key_codes"]))
        raise ValueError(f"unsupported neural Desktop action: {action}")

    def _reject(self, intent: ActionIntent, now: float, reason: str) -> ActionAttempt:
        return ActionAttempt(id=f"desktop-attempt-{uuid4().hex}", intent_id=intent.id, transition_id=intent.transition_id, world=self.world_id, action=intent.action, attempted_at=now, accepted=False, payload={"reason": reason})

    def close(self) -> None:
        if self._closed: return
        self._closed = True; self._affordances.clear(); self._pending = None
        if self._input is not None: self._input.close(); self._input = None
        self.inference.close()
