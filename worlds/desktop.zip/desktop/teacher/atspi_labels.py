from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True, slots=True)
class TeacherRegion:
    bbox_xyxy: tuple[float, float, float, float]
    kind: str
    focused: bool
    actionable: bool


def region_from_atspi(payload: Mapping[str, object], *, screen_width: int, screen_height: int) -> TeacherRegion | None:
    """Convert an explicitly collected AT-SPI bbox into an offline normalized label."""
    bounds = payload.get("bounds")
    if not isinstance(bounds, (tuple, list)) or len(bounds) != 4: return None
    x, y, width, height = (float(value) for value in bounds)
    if width <= 0 or height <= 0 or screen_width <= 0 or screen_height <= 0: return None
    return TeacherRegion(
        bbox_xyxy=(x / screen_width, y / screen_height, (x + width) / screen_width, (y + height) / screen_height),
        kind=str(payload.get("role", "unknown")), focused=bool(payload.get("focused", False)),
        actionable=bool(payload.get("focusable", False) or payload.get("editable", False)),
    )

