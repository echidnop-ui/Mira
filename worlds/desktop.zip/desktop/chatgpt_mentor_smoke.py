from __future__ import annotations

from dataclasses import replace
import secrets
import sys

import torch

from core.personal import PersonalCognitiveCore, PersonalCoreConfig
from language.organ import NeuralLanguageConfig, NeuralLanguageOrgan
from runtime.mentor import MentorIntegrator
from worlds.desktop.chatgpt_bootstrap import (
    ChatGPTDesktopBootstrap,
    ChatGPTDesktopError,
)


def main() -> int:
    print("HEIWA -> REAL CHATGPT RUSSIAN TEMPORARY-MENTOR SMOKE")
    print(f"python: {sys.version.split()[0]}")
    print(f"torch: {torch.__version__}")
    print(f"hip: {getattr(torch.version, 'hip', None)}")
    print(f"accelerator_available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"accelerator: {torch.cuda.get_device_name(0)}")

    challenge = "h" + secrets.token_hex(4)
    expected = "ХЭЙВА_ОТВЕТ_" + challenge.upper()
    outbound = (
        "[HEIWA_DESKTOP_MENTOR_SMOKE] "
        f"challenge={challenge}. "
        "Это проверка русского общения Heiwa через компьютер. "
        "Ответь ровно одной строкой: префикс ХЭЙВА_ОТВЕТ_ и затем challenge "
        "ПРОПИСНЫМИ латинскими буквами. Ничего больше не добавляй."
    )

    bridge = ChatGPTDesktopBootstrap()
    language = NeuralLanguageOrgan(NeuralLanguageConfig.local())
    core = PersonalCognitiveCore(
        replace(PersonalCoreConfig.smoke(device=None), router_top_k=4)
    )
    mentor = MentorIntegrator(language, core)

    print(f"language_device: {language.device}")
    print(f"core_device: {core.device}")
    print("core_router_top_k:", core.config.router_top_k)
    print("outbound_contains_cyrillic:", any(ord(ch) > 127 for ch in outbound))

    try:
        composer = bridge.focus_composer()
        print("chatgpt_window:", composer.window)
        print("composer_role:", composer.role)
        print("composer_name:", repr(composer.name))
        print("composer_score:", composer.score)

        if composer.has_draft:
            print("MENTOR SMOKE FAILED: ChatGPT composer contains an existing draft")
            return 2

        if bridge.find_visible_text(expected) is not None:
            print("MENTOR SMOKE FAILED: expected reply already visible before send")
            return 3

        previous_reply = bridge.latest_response()
        previous_reply_text = previous_reply.text if previous_reply is not None else ""

        before = language.telemetry()

        bridge.send_message(outbound)
        print("desktop_russian_message_submitted: True")
        print("challenge:", challenge)
        print("waiting_for_mentor_reply: True")

        match = bridge.wait_for_new_russian_response(
            previous_reply_text,
            required_text=challenge,
            timeout=300.0,
        )
        print("mentor_reply_observed: True")
        print("mentor_reply_role:", match.role)
        print("mentor_reply_text:", repr(match.text))

        result = mentor.observe(
            match.text,
            source_id="chatgpt-visible-ui",
            metadata={"verified_via": "atspi.visible_text"},
        )
        print("mentor_language_receptive: OK")
        print("mentor_core_integrate: OK")
        print("mentor_core_active_experts:", ", ".join(core.telemetry().last_active_experts))
        print("mentor_raw_text_retained:", result.raw_text_retained)
        print("mentor_temporary_context:", result.metadata["temporary_context"])
        print("mentor_automatic_long_term_memory:", result.metadata["automatic_long_term_memory"])

        after = language.telemetry()
        teacher_delta = after.teacher_language_updates - before.teacher_language_updates
        expression_delta = after.expression_learning_updates - before.expression_learning_updates
        receptive_delta = (
            after.representation_learning_updates
            - before.representation_learning_updates
        )
        print("teacher_language_updates_delta:", teacher_delta)
        print("expression_learning_updates_delta:", expression_delta)
        print("representation_learning_updates_delta:", receptive_delta)

        if teacher_delta or expression_delta or receptive_delta:
            print("MENTOR SMOKE FAILED: ordinary mentor reply changed language learning counters")
            return 4
        if result.raw_text_retained:
            print("MENTOR SMOKE FAILED: raw mentor text retained by integrator")
            return 5

        print(
            "CHAIN: Russian visible ChatGPT composer -> Unicode UI input -> Enter -> "
            "real ChatGPT reply -> AT-SPI -> Language.encode -> Core WORK/SLOW/history; "
            "NO automatic teacher update; NO automatic long-term memory"
        )
        print("HEIWA REAL CHATGPT RUSSIAN TEMPORARY-MENTOR SMOKE: OK")
        return 0

    except ChatGPTDesktopError as exc:
        print("MENTOR SMOKE FAILED:", exc)
        return 6


if __name__ == "__main__":
    raise SystemExit(main())
