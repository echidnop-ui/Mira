from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time


def _run(
    argv: tuple[str, ...],
    *,
    timeout: float = 10.0,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        argv,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=timeout,
    )


def _capture_smoke() -> dict[str, object]:
    command = shutil.which("gnome-screenshot")
    if command is None:
        return {
            "available": False,
            "ok": False,
            "reason": "gnome-screenshot missing",
        }

    fd, raw_path = tempfile.mkstemp(
        prefix="heiwa-desktop-",
        suffix=".png",
    )
    os.close(fd)
    path = Path(raw_path)

    try:
        result = _run(
            (
                command,
                "-f",
                str(path),
            ),
            timeout=15.0,
        )
        size = path.stat().st_size if path.exists() else 0
        return {
            "available": True,
            "ok": result.returncode == 0 and size > 0,
            "bytes": size,
            "stderr": result.stderr.strip(),
        }
    finally:
        try:
            path.unlink()
        except FileNotFoundError:
            pass


def _atspi_target_smoke() -> dict[str, object]:
    """
    Test AT-SPI against a disposable GTK window owned by the current user.

    We intentionally do NOT enumerate every desktop application. Sandboxed
    Snap applications may reject AT-SPI calls through AppArmor; one such app
    must not make the whole Desktop perception channel look broken.
    """
    python = Path("/usr/bin/python3")
    if not python.exists():
        return {
            "available": False,
            "ok": False,
            "reason": "/usr/bin/python3 missing",
        }

    import_check = _run(
        (
            str(python),
            "-c",
            "import pyatspi, gi; print('OK')",
        )
    )
    if import_check.returncode != 0:
        return {
            "available": False,
            "ok": False,
            "reason": import_check.stderr.strip(),
        }

    target_script = r"""
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib

window = Gtk.Window(title="Heiwa AT-SPI Probe")
window.set_default_size(420, 120)

entry = Gtk.Entry()
entry.set_name("heiwa-probe-entry")
entry.set_placeholder_text("Heiwa desktop probe")
window.add(entry)

window.connect("destroy", Gtk.main_quit)
window.show_all()

GLib.timeout_add_seconds(20, Gtk.main_quit)
Gtk.main()
"""

    try:
        target = subprocess.Popen(
            (
                str(python),
                "-c",
                target_script,
            ),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )
    except OSError as exc:
        return {
            "available": True,
            "ok": False,
            "reason": str(exc),
        }

    probe_script = r"""
import json
import time
import pyatspi

deadline = time.time() + 8.0
seen = []

while time.time() < deadline:
    desktop = pyatspi.Registry.getDesktop(0)

    for index in range(desktop.childCount):
        try:
            app = desktop.getChildAtIndex(index)
            if app is None:
                continue
            app_name = getattr(app, "name", "") or ""
        except Exception:
            continue

        for child_index in range(getattr(app, "childCount", 0)):
            try:
                child = app.getChildAtIndex(child_index)
                if child is None:
                    continue
                name = getattr(child, "name", "") or ""
                role = child.getRoleName()
                seen.append({
                    "application": app_name,
                    "name": name,
                    "role": role,
                })
                if name == "Heiwa AT-SPI Probe":
                    print(json.dumps({
                        "ok": True,
                        "target": {
                            "application": app_name,
                            "name": name,
                            "role": role,
                        },
                    }, ensure_ascii=False))
                    raise SystemExit(0)
            except SystemExit:
                raise
            except Exception:
                continue

    time.sleep(0.2)

print(json.dumps({
    "ok": False,
    "seen": seen[-20:],
}, ensure_ascii=False))
raise SystemExit(3)
"""

    try:
        result = _run(
            (
                str(python),
                "-c",
                probe_script,
            ),
            timeout=12.0,
        )

        try:
            payload = json.loads(
                result.stdout.strip() or "{}"
            )
        except json.JSONDecodeError:
            payload = {}

        payload.update({
            "available": True,
            "returncode": result.returncode,
            "stderr": result.stderr.strip(),
        })
        return payload
    finally:
        target.terminate()
        try:
            target.wait(timeout=2.0)
        except subprocess.TimeoutExpired:
            target.kill()


def _service_exists(name: str) -> bool:
    result = _run(
        (
            "systemctl",
            "--user",
            "cat",
            name,
        ),
        timeout=5.0,
    )
    return result.returncode == 0


def _service_state(name: str) -> str:
    result = _run(
        (
            "systemctl",
            "--user",
            "is-active",
            name,
        ),
        timeout=5.0,
    )
    return result.stdout.strip() or result.stderr.strip()


def _start_ydotool_service() -> dict[str, object]:
    if shutil.which("systemctl") is None:
        return {
            "ok": False,
            "reason": "systemctl missing",
        }

    candidates = (
        "ydotool.service",
        "ydotoold.service",
    )

    service = next(
        (
            name
            for name in candidates
            if _service_exists(name)
        ),
        None,
    )

    if service is None:
        return {
            "ok": False,
            "reason": "no ydotool user service installed",
            "candidates": candidates,
        }

    result = _run(
        (
            "systemctl",
            "--user",
            "enable",
            "--now",
            service,
        ),
        timeout=10.0,
    )

    time.sleep(0.5)

    return {
        "ok": result.returncode == 0,
        "service": service,
        "state": _service_state(service),
        "stdout": result.stdout.strip(),
        "stderr": result.stderr.strip(),
    }


def _ydotool_socket_path() -> Path:
    explicit = os.environ.get("YDOTOOL_SOCKET")
    if explicit:
        return Path(explicit)

    runtime = os.environ.get("XDG_RUNTIME_DIR")
    if runtime:
        return Path(runtime) / ".ydotool_socket"

    return Path("/tmp/.ydotool_socket")


def _motor_connection_smoke() -> dict[str, object]:
    command = shutil.which("ydotool")
    if command is None:
        return {
            "available": False,
            "ok": False,
            "reason": "ydotool missing",
        }

    service = _start_ydotool_service()

    socket_path = _ydotool_socket_path()

    # Newer clients normally use XDG_RUNTIME_DIR. A packaged service may use
    # /tmp instead, so probe both without changing input state.
    candidates = []
    for candidate in (
        socket_path,
        Path("/tmp/.ydotool_socket"),
    ):
        if candidate not in candidates:
            candidates.append(candidate)

    socket_info = [
        {
            "path": str(path),
            "exists": path.exists(),
            "is_socket": (
                path.exists()
                and path.stat().st_mode & 0o170000 == 0o140000
            ),
        }
        for path in candidates
    ]

    usable = next(
        (
            item
            for item in socket_info
            if item["exists"] and item["is_socket"]
        ),
        None,
    )

    if usable is None:
        return {
            "available": True,
            "ok": False,
            "service": service,
            "sockets": socket_info,
            "reason": "ydotoold socket not available",
        }

    # Do not move the pointer or type anything in bootstrap.
    # Connecting to the datagram socket is enough to prove that the motor
    # daemon boundary is reachable.
    try:
        client = socket.socket(
            socket.AF_UNIX,
            socket.SOCK_DGRAM,
        )
        client.connect(usable["path"])
        client.close()
        reachable = True
        error = None
    except OSError as exc:
        reachable = False
        error = str(exc)

    return {
        "available": True,
        "ok": reachable,
        "service": service,
        "socket": usable["path"],
        "socket_reachable": reachable,
        "socket_error": error,
        "dev_uinput_writable_by_heiwa": os.access(
            "/dev/uinput",
            os.W_OK,
        ),
        "note": (
            "Heiwa does not need direct /dev/uinput write access when "
            "ydotoold owns the device and exposes a reachable socket."
        ),
    }


def main() -> int:
    print("HEIWA DESKTOP BOOTSTRAP V2")
    print(
        "session_type:",
        os.environ.get("XDG_SESSION_TYPE"),
    )
    print(
        "desktop:",
        os.environ.get("XDG_CURRENT_DESKTOP"),
    )

    atspi = _atspi_target_smoke()
    capture = _capture_smoke()
    motor = _motor_connection_smoke()

    print(
        "ATSPI_TARGET_SMOKE:",
        json.dumps(atspi, ensure_ascii=False),
    )
    print(
        "SCREENSHOT_SMOKE:",
        json.dumps(capture, ensure_ascii=False),
    )
    print(
        "MOTOR_DAEMON_SMOKE:",
        json.dumps(motor, ensure_ascii=False),
    )

    failed = []

    if not atspi.get("ok"):
        failed.append("atspi")
    if not capture.get("ok"):
        failed.append("screenshot")
    if not motor.get("ok"):
        failed.append("motor")

    if failed:
        print(
            "DESKTOP BOOTSTRAP V2: BLOCKED:",
            ",".join(failed),
        )
        return 2

    print(
        "DESKTOP BOOTSTRAP V2: PERCEPTION + MOTOR BOUNDARY READY"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
