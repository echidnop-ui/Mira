from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping
from uuid import uuid4

from contracts.cognition import (
    ActionAttempt,
    ActionIntent,
    Affordance,
    CompletedAction,
    Observation,
)
from worlds.interface import (
    WorldFrame,
    validate_intent_for_world,
)
from worlds.desktop.motor import DesktopMotor, DesktopMotorError
from worlds.desktop.perception import (
    DesktopPerception,
    FocusedDesktopContext,
)


WORLD_ID = "desktop:local"
TYPE_TEXT_ACTION = "desktop.type_text"
FOCUS_NEXT_ACTION = "desktop.focus_next"
KEY_TAB = 15


@dataclass(frozen=True, slots=True)
class _AffordanceTarget:
    application: str
    window: str
    name: str
    role: str


@dataclass(frozen=True, slots=True)
class _PendingTypeText:
    attempt_id: str
    intent_id: str
    transition_id: str
    action: str
    target: _AffordanceTarget
    expected_text: str


@dataclass(frozen=True, slots=True)
class _PendingFocusNext:
    attempt_id: str
    intent_id: str
    transition_id: str
    action: str
    source: _AffordanceTarget


class DesktopWorldAdapter:
    """
    Minimal Desktop World adapter.

    It exposes semantic Desktop state and currently valid actions.
    It executes already-selected ActionIntent objects through DesktopMotor.

    A successful motor call creates ActionAttempt only.
    CompletedAction is emitted later by poll() only after perception observes
    the expected external text state on the exact control targeted by the
    attempt.
    """

    def __init__(
        self,
        *,
        perception: DesktopPerception | None = None,
        motor: DesktopMotor | None = None,
        world_id: str = WORLD_ID,
    ) -> None:
        self._world_id = world_id
        self._perception = perception or DesktopPerception()
        self._motor = motor or DesktopMotor()
        self._offered_targets: dict[str, _AffordanceTarget] = {}
        self._pending_type_text: dict[str, _PendingTypeText] = {}
        self._pending_focus_next: dict[str, _PendingFocusNext] = {}
        self._closed = False

    @property
    def world_id(self) -> str:
        return self._world_id

    def poll(self, now: float) -> WorldFrame:
        self._require_open()

        completed_actions = self._observe_completions(now=now)
        context = self._perception.focused_context()

        observations: tuple[Observation, ...] = ()
        affordances: tuple[Affordance, ...] = ()

        self._offered_targets.clear()

        if context is not None:
            observation = Observation(
                id=f"desktop-observation-{uuid4().hex}",
                world=self._world_id,
                kind="desktop.focused_context",
                observed_at=now,
                payload=self._context_payload(context),
            )
            observations = (observation,)

            if context.focused:
                target = self._target_from_context(context)

                if not self._has_pending_for_target(target):
                    offered: list[Affordance] = []

                    if context.editable:
                        affordance_id = f"desktop-affordance-{uuid4().hex}"
                        self._offered_targets[affordance_id] = target
                        offered.append(
                            Affordance(
                                id=affordance_id,
                                world=self._world_id,
                                action=TYPE_TEXT_ACTION,
                                offered_at=now,
                                payload={
                                    "application": context.application,
                                    "window": context.window,
                                    "control_name": context.name,
                                    "role": context.role,
                                },
                                constraints={
                                    "requires_same_focus": True,
                                    "requires_editable_control": True,
                                    "completion_requires_observed_text": True,
                                },
                            )
                        )

                    if context.focusable:
                        affordance_id = f"desktop-affordance-{uuid4().hex}"
                        self._offered_targets[affordance_id] = target
                        offered.append(
                            Affordance(
                                id=affordance_id,
                                world=self._world_id,
                                action=FOCUS_NEXT_ACTION,
                                offered_at=now,
                                payload={
                                    "application": context.application,
                                    "window": context.window,
                                    "control_name": context.name,
                                    "role": context.role,
                                },
                                constraints={
                                    "requires_same_focus": True,
                                    "completion_requires_observed_focus_change": True,
                                },
                            )
                        )

                    affordances = tuple(offered)

        return WorldFrame(
            world=self._world_id,
            observed_at=now,
            observations=observations,
            affordances=affordances,
            completed_actions=completed_actions,
        )

    def execute(
        self,
        intent: ActionIntent,
        now: float,
    ) -> ActionAttempt:
        self._require_open()
        validate_intent_for_world(intent, world_id=self._world_id)

        if intent.action not in {TYPE_TEXT_ACTION, FOCUS_NEXT_ACTION}:
            return self._rejected_attempt(
                intent,
                now,
                reason=f"unsupported action: {intent.action}",
            )

        offered_target = self._offered_targets.get(intent.affordance_id)
        if offered_target is None:
            return self._rejected_attempt(
                intent,
                now,
                reason="affordance is stale or was not offered by this adapter",
            )

        if self._has_pending_for_target(offered_target):
            return self._rejected_attempt(
                intent,
                now,
                reason="previous action is still awaiting observation",
            )

        current = self._perception.focused_context()
        if current is None or not current.focused:
            return self._rejected_attempt(
                intent,
                now,
                reason="no focused Desktop context",
            )

        if self._target_from_context(current) != offered_target:
            return self._rejected_attempt(
                intent,
                now,
                reason="Desktop focus changed after affordance was offered",
            )

        if intent.action == FOCUS_NEXT_ACTION:
            if intent.parameters:
                return self._rejected_attempt(
                    intent,
                    now,
                    reason="desktop.focus_next does not accept parameters",
                )
            if not current.focusable:
                return self._rejected_attempt(
                    intent,
                    now,
                    reason="focused Desktop control is no longer focusable",
                )

            try:
                result = self._motor.press_key(KEY_TAB)
            except DesktopMotorError as exc:
                return self._rejected_attempt(intent, now, reason=str(exc))

            attempt_id = f"desktop-attempt-{uuid4().hex}"
            self._pending_focus_next[attempt_id] = _PendingFocusNext(
                attempt_id=attempt_id,
                intent_id=intent.id,
                transition_id=intent.transition_id,
                action=intent.action,
                source=offered_target,
            )
            self._offered_targets.pop(intent.affordance_id, None)

            return ActionAttempt(
                id=attempt_id,
                intent_id=intent.id,
                transition_id=intent.transition_id,
                world=self._world_id,
                action=intent.action,
                attempted_at=now,
                accepted=True,
                external_id=None,
                payload={
                    "motor_returncode": result.returncode,
                    "motor_stderr": result.stderr.strip(),
                    "completion_unverified": True,
                    "verification": "atspi.focus_change",
                },
            )

        text = intent.parameters.get("text")
        if not isinstance(text, str):
            return self._rejected_attempt(
                intent,
                now,
                reason="desktop.type_text requires string parameter 'text'",
            )
        if not current.editable:
            return self._rejected_attempt(
                intent,
                now,
                reason="focused Desktop control is no longer editable",
            )

        expected_text = self._expected_text_after_typing(current, text)
        if expected_text is None:
            return self._rejected_attempt(
                intent,
                now,
                reason=(
                    "focused control does not expose enough text/caret state "
                    "to verify completion"
                ),
            )

        try:
            result = self._motor.type_text(text)
        except DesktopMotorError as exc:
            return self._rejected_attempt(intent, now, reason=str(exc))

        attempt_id = f"desktop-attempt-{uuid4().hex}"
        self._pending_type_text[attempt_id] = _PendingTypeText(
            attempt_id=attempt_id,
            intent_id=intent.id,
            transition_id=intent.transition_id,
            action=intent.action,
            target=offered_target,
            expected_text=expected_text,
        )
        self._offered_targets.pop(intent.affordance_id, None)

        return ActionAttempt(
            id=attempt_id,
            intent_id=intent.id,
            transition_id=intent.transition_id,
            world=self._world_id,
            action=intent.action,
            attempted_at=now,
            accepted=True,
            external_id=None,
            payload={
                "motor_returncode": result.returncode,
                "motor_stderr": result.stderr.strip(),
                "completion_unverified": True,
                "verification": "atspi.target_text",
            },
        )

    def close(self) -> None:
        self._offered_targets.clear()
        self._pending_type_text.clear()
        self._pending_focus_next.clear()
        self._closed = True

    def _observe_completions(
        self,
        *,
        now: float,
    ) -> tuple[CompletedAction, ...]:
        completed: list[CompletedAction] = []

        for attempt_id, pending in tuple(self._pending_type_text.items()):
            context = self._perception.target_context(
                application=pending.target.application,
                window=pending.target.window,
                name=pending.target.name,
                role=pending.target.role,
            )

            if context is None or context.text is None:
                continue

            if context.text != pending.expected_text:
                continue

            completed.append(
                CompletedAction(
                    id=f"desktop-completed-{uuid4().hex}",
                    attempt_id=pending.attempt_id,
                    intent_id=pending.intent_id,
                    transition_id=pending.transition_id,
                    world=self._world_id,
                    action=pending.action,
                    completed_at=now,
                    status="succeeded",
                    succeeded=True,
                    external_id=None,
                    payload={
                        "verified_by": "atspi.target_text",
                        "observed_text_length": len(context.text),
                    },
                )
            )
            self._pending_type_text.pop(attempt_id, None)

        if self._pending_focus_next:
            current = self._perception.focused_context()
            if current is not None and current.focused:
                current_target = self._target_from_context(current)
                for attempt_id, pending in tuple(self._pending_focus_next.items()):
                    if current_target == pending.source:
                        continue

                    completed.append(
                        CompletedAction(
                            id=f"desktop-completed-{uuid4().hex}",
                            attempt_id=pending.attempt_id,
                            intent_id=pending.intent_id,
                            transition_id=pending.transition_id,
                            world=self._world_id,
                            action=pending.action,
                            completed_at=now,
                            status="succeeded",
                            succeeded=True,
                            external_id=None,
                            payload={
                                "verified_by": "atspi.focus_change",
                                "from_application": pending.source.application,
                                "from_window": pending.source.window,
                                "from_control_name": pending.source.name,
                                "to_application": current.application,
                                "to_window": current.window,
                                "to_control_name": current.name,
                                "to_role": current.role,
                            },
                        )
                    )
                    self._pending_focus_next.pop(attempt_id, None)

        return tuple(completed)

    def _has_pending_for_target(
        self,
        target: _AffordanceTarget,
    ) -> bool:
        return (
            any(
                pending.target == target
                for pending in self._pending_type_text.values()
            )
            or any(
                pending.source == target
                for pending in self._pending_focus_next.values()
            )
        )

    @staticmethod
    def _expected_text_after_typing(
        context: FocusedDesktopContext,
        injected: str,
    ) -> str | None:
        if context.text is None or context.caret_offset is None:
            return None

        caret = context.caret_offset
        if caret < 0 or caret > len(context.text):
            return None

        return (
            context.text[:caret]
            + injected
            + context.text[caret:]
        )

    def _require_open(self) -> None:
        if self._closed:
            raise RuntimeError("DesktopWorldAdapter is closed")

    def _rejected_attempt(
        self,
        intent: ActionIntent,
        now: float,
        *,
        reason: str,
    ) -> ActionAttempt:
        return ActionAttempt(
            id=f"desktop-attempt-{uuid4().hex}",
            intent_id=intent.id,
            transition_id=intent.transition_id,
            world=self._world_id,
            action=intent.action,
            attempted_at=now,
            accepted=False,
            external_id=None,
            payload={"reason": reason},
        )

    @staticmethod
    def _target_from_context(
        context: FocusedDesktopContext,
    ) -> _AffordanceTarget:
        return _AffordanceTarget(
            application=context.application,
            window=context.window,
            name=context.name,
            role=context.role,
        )

    @staticmethod
    def _context_payload(
        context: FocusedDesktopContext,
    ) -> Mapping[str, object]:
        payload: dict[str, object] = {
            "application": context.application,
            "window": context.window,
            "control_name": context.name,
            "role": context.role,
            "focused": context.focused,
            "focusable": context.focusable,
            "editable": context.editable,
        }

        if context.text is not None:
            payload["text"] = context.text
        if context.caret_offset is not None:
            payload["caret_offset"] = context.caret_offset

        return payload
