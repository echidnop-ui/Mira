from __future__ import annotations

from typing import Any

import worlds.desktop.chatgpt_bootstrap as bootstrap_module
from worlds.desktop.chatgpt_bootstrap import (
    ChatGPTComposer,
    ChatGPTDesktopBootstrap,
    ChatGPTDesktopError,
)
from worlds.desktop.motor import DesktopMotor, MotorResult


class _RecordingMotor(DesktopMotor):
    def __init__(self, events: list[str] | None = None) -> None:
        super().__init__(socket_path="/mock/ydotool.sock", timeout=1.0)
        self.calls: list[tuple[str, ...]] = []
        self.events = events

    def _run(self, *arguments: str) -> MotorResult:
        self.calls.append(tuple(arguments))
        return MotorResult(0, "", "")

    def type_ascii(self, text: str) -> MotorResult:
        result = super().type_ascii(text)
        if self.events is not None:
            self.events.append("physical_ascii")
        return result

    def key_press(self, key_code: int) -> MotorResult:
        result = super().key_press(key_code)
        if self.events is not None:
            self.events.append("enter" if key_code == 28 else "key_press")
        return result


class _NoopLayoutGuard:
    def __init__(self, *, socket_path: str) -> None:
        assert socket_path == "/mock/ydotool.sock"

    def __enter__(self) -> "_NoopLayoutGuard":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None


def _composer() -> ChatGPTComposer:
    return ChatGPTComposer(
        application="Firefox",
        window="Intended ChatGPT — Mozilla Firefox",
        name="Chat with ChatGPT",
        role="entry",
        text="\ufffc",
        caret_offset=0,
        score=368,
        window_active=True,
        control_focused=True,
        document_showing=True,
    )


class _KeyboardBridge(ChatGPTDesktopBootstrap):
    def __init__(
        self,
        *,
        mismatch: bool = False,
        observations: list[bool] | None = None,
    ) -> None:
        self.events: list[str] = []
        self.recording_motor = _RecordingMotor(self.events)
        super().__init__(motor=self.recording_motor, diagnostics=False)
        self.mismatch = mismatch
        self.observations = list(observations or [True])
        self.clipboard_calls = 0
        self.button_clicks = 0

    def _activate_ready_composer(self) -> ChatGPTComposer:
        self.events.append("fresh_invariant")
        return _composer()

    def _verify_composer_text(self, expected: str) -> None:
        self.events.append("composer_verify")
        assert expected == "?"
        if self.mismatch:
            raise ChatGPTDesktopError("mock composer mismatch")

    def _observe_submission(
        self,
        expected_text: str,
        *,
        timeout: float = 3.0,
        poll_interval: float = 0.15,
    ) -> Any:
        del timeout, poll_interval
        assert expected_text == "?"
        self.events.append("observe")
        completed = self.observations.pop(0)
        return bootstrap_module._SubmissionObservation(
            completed=completed,
            composer_cleared=completed,
            content_matches_expected=not completed,
            safe_for_fallback=not completed,
        )

    def _click_send_button(self) -> None:
        self.button_clicks += 1
        self.events.append("button_click")

    def _paste_unicode_text(self, text: str) -> Any:
        del text
        self.clipboard_calls += 1
        raise AssertionError("ASCII path used clipboard fallback")


def main() -> int:
    print("HEIWA CHATGPT PHYSICAL KEYBOARD LOCAL SMOKE")

    motor = _RecordingMotor()
    motor.type_ascii("aA?")
    assert motor.calls == [
        (
            "key",
            "30:1", "30:0",
            "42:1", "30:1", "30:0", "42:0",
            "42:1", "53:1", "53:0", "42:0",
        )
    ]
    motor.key_down(28)
    motor.key_up(28)
    motor.key_press(14)
    motor.type_ascii("\n")
    assert motor.calls[-4:] == [
        ("key", "28:1"),
        ("key", "28:0"),
        ("key", "14:1", "14:0"),
        ("key", "42:1", "28:1", "28:0", "42:0"),
    ]
    print("physical_ascii_key_events: OK")
    print("physical_question_shift_slash: OK")
    print("key_down_up_press_backspace_enter: OK")

    original_guard = bootstrap_module._KeyboardLayoutGuard
    bootstrap_module._KeyboardLayoutGuard = _NoopLayoutGuard
    try:
        bridge = _KeyboardBridge(observations=[True])
        bridge.send_message("?")
        assert bridge.events == [
            "fresh_invariant",
            "physical_ascii",
            "composer_verify",
            "enter",
            "observe",
        ]
        assert bridge.clipboard_calls == 0
        assert bridge.button_clicks == 0
        assert bridge.last_send_timing.keyboard_path == "physical"
        assert bridge.last_send_timing.composer_verified
        assert bridge.last_send_timing.send_path == "enter"
        assert bridge.last_send_timing.send_attempted
        assert bridge.last_send_timing.send_completed
        assert bridge.last_send_timing.composer_cleared

        fallback = _KeyboardBridge(observations=[False, True])
        fallback.send_message("?")
        assert fallback.events.count("enter") == 1
        assert fallback.events.count("button_click") == 1
        assert fallback.events[-3:] == ["observe", "button_click", "observe"]
        assert fallback.last_send_timing.send_path == "button_fallback"
        assert fallback.last_send_timing.send_completed

        failed = _KeyboardBridge(observations=[False, False])
        try:
            failed.send_message("?")
        except ChatGPTDesktopError as exc:
            assert "not externally confirmed" in str(exc)
        else:
            raise AssertionError("unconfirmed submission did not fail closed")
        assert failed.events.count("enter") == 1
        assert failed.events.count("button_click") == 1

        blocked = _KeyboardBridge(mismatch=True)
        try:
            blocked.send_message("?")
        except ChatGPTDesktopError as exc:
            assert "mismatch" in str(exc)
        else:
            raise AssertionError("composer mismatch did not block send")
        assert "enter" not in blocked.events
        assert "button_click" not in blocked.events
        assert blocked.clipboard_calls == 0
    finally:
        bootstrap_module._KeyboardLayoutGuard = original_guard

    print("question_clipboard_calls: 0")
    print("composer_exact_text_verified_before_send: OK")
    print("verified_composer_enter_attempted: OK")
    print("enter_completion_observed: OK")
    print("bounded_button_fallback: OK")
    print("unconfirmed_submission_errors: OK")
    print("no_duplicate_submit: OK")
    print("composer_mismatch_blocks_send: OK")
    print("HEIWA CHATGPT PHYSICAL KEYBOARD LOCAL SMOKE: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
