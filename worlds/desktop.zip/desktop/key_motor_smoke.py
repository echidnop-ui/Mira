from __future__ import annotations

import os
from pathlib import Path
import subprocess
import time

from worlds.desktop.motor import DesktopMotor, DesktopMotorError
from worlds.desktop.perception import DesktopPerception


KEY_TAB = 15


_FOCUS_FIRST = r"""
import time
import pyatspi

deadline = time.monotonic() + 5.0

while time.monotonic() < deadline:
    desktop = pyatspi.Registry.getDesktop(0)

    for app_index in range(desktop.childCount):
        try:
            app = desktop.getChildAtIndex(app_index)
            if app is None or app.name != "key_target.py":
                continue
        except Exception:
            continue

        stack = [app]

        while stack:
            node = stack.pop()

            try:
                if (
                    node.getRole() == pyatspi.ROLE_TEXT
                    and node.name == "Heiwa Key First"
                    and node.queryComponent().grabFocus()
                ):
                    raise SystemExit(0)
            except Exception:
                pass

            try:
                for index in range(node.childCount):
                    child = node.getChildAtIndex(index)
                    if child is not None:
                        stack.append(child)
            except Exception:
                pass

    time.sleep(0.1)

raise SystemExit(1)
"""


def main() -> int:
    print("HEIWA DESKTOP KEY MOTOR SMOKE")

    project_root = Path(__file__).resolve().parents[2]

    target_env = os.environ.copy()
    target_env["GDK_BACKEND"] = "wayland"
    target_env["NO_AT_BRIDGE"] = "0"

    target = subprocess.Popen(
        (
            "/usr/bin/python3",
            "-m",
            "worlds.desktop.key_target",
        ),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=str(project_root),
        env=target_env,
    )

    try:
        focus = subprocess.run(
            (
                "/usr/bin/python3",
                "-c",
                _FOCUS_FIRST,
            ),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=target_env,
            timeout=7.0,
        )

        print("focus_returncode:", focus.returncode)
        if focus.returncode != 0:
            print("focus_stderr:", focus.stderr.strip())
            print("KEY MOTOR SMOKE FAILED: first focus")
            return 2

        perception = DesktopPerception()
        before = perception.focused_context()

        print(
            "before_name:",
            before.name if before is not None else "",
        )

        if (
            before is None
            or before.application != "key_target.py"
            or before.name != "Heiwa Key First"
        ):
            print("KEY MOTOR SMOKE FAILED: wrong initial focus")
            return 3

        motor = DesktopMotor()

        try:
            result = motor.press_key(KEY_TAB)
        except DesktopMotorError as exc:
            print("KEY MOTOR SMOKE FAILED:", str(exc))
            return 4

        print("ydotool_returncode:", result.returncode)
        print("ydotool_stderr:", result.stderr.strip())

        after = None
        deadline = time.monotonic() + 2.0

        while time.monotonic() < deadline:
            context = perception.focused_context()

            if (
                context is not None
                and context.application == "key_target.py"
                and context.name == "Heiwa Key Second"
            ):
                after = context
                break

            time.sleep(0.05)

        print(
            "after_name:",
            after.name if after is not None else "",
        )

        if after is None:
            print("KEY MOTOR SMOKE FAILED: Tab focus change not observed")
            return 5

        stdout, stderr = target.communicate(timeout=8.0)

        final = stdout.strip().splitlines()
        final_focus = final[-1] if final else ""

        print("target_focus:", final_focus)
        print("target_stderr:", stderr.strip())

        if final_focus != "second":
            print("KEY MOTOR SMOKE FAILED: target did not retain second focus")
            return 6

        print(
            "CHAIN: DesktopMotor.press_key(KEY_TAB) -> ydotoold/uinput -> "
            "GTK focus moved First -> Second -> AT-SPI observed"
        )
        print("HEIWA DESKTOP KEY MOTOR SMOKE: OK")
        return 0

    finally:
        if target.poll() is None:
            target.terminate()
            try:
                target.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                target.kill()


if __name__ == "__main__":
    raise SystemExit(main())
