from __future__ import annotations

from dataclasses import asdict, dataclass
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Iterable


@dataclass(frozen=True, slots=True)
class DesktopProbe:
    session_type: str | None
    desktop: str | None
    display: str | None
    wayland_display: str | None
    dbus_session_bus: bool
    atspi_python: bool
    toolkit_accessibility: str | None
    commands: dict[str, str | None]
    dev_uinput_exists: bool
    dev_uinput_readable: bool
    dev_uinput_writable: bool
    recommendations: tuple[str, ...]


def _command(name: str) -> str | None:
    return shutil.which(name)


def _run(
    argv: Iterable[str],
    *,
    timeout: float = 2.0,
) -> str | None:
    try:
        result = subprocess.run(
            tuple(argv),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None

    if result.returncode != 0:
        return None

    text = result.stdout.strip()
    return text or None


def _gsettings_accessibility() -> str | None:
    if _command("gsettings") is None:
        return None

    return _run(
        (
            "gsettings",
            "get",
            "org.gnome.desktop.interface",
            "toolkit-accessibility",
        )
    )


def _recommendations(
    *,
    session_type: str | None,
    atspi_python: bool,
    commands: dict[str, str | None],
    uinput_writable: bool,
) -> tuple[str, ...]:
    result: list[str] = []

    if atspi_python:
        result.append(
            "Use AT-SPI as the primary semantic UI perception channel."
        )
    else:
        result.append(
            "Install/enable Python AT-SPI bindings before semantic UI work."
        )

    if session_type == "wayland":
        if commands.get("ydotool") and uinput_writable:
            result.append(
                "Use ydotool/uinput as the first low-level keyboard/mouse motor."
            )
        else:
            result.append(
                "Wayland detected: prefer libei/desktop-portal or ydotool/uinput; "
                "do not depend on xdotool."
            )

        if commands.get("grim"):
            result.append(
                "grim is available for pixels if the compositor permits it."
            )
        elif commands.get("gnome-screenshot"):
            result.append(
                "GNOME screenshot utility is available; validate noninteractive capture."
            )
        else:
            result.append(
                "No obvious Wayland screenshot command found; use ScreenCast portal."
            )

    elif session_type == "x11":
        if commands.get("xdotool"):
            result.append(
                "Use xdotool as the first X11 motor backend."
            )
        else:
            result.append(
                "X11 detected but xdotool is missing."
            )

        if commands.get("gnome-screenshot"):
            result.append(
                "GNOME screenshot utility is available for first pixel smoke."
            )
        elif commands.get("scrot"):
            result.append(
                "scrot is available for first pixel smoke."
            )
        elif commands.get("import"):
            result.append(
                "ImageMagick import is available for first pixel smoke."
            )
        else:
            result.append(
                "No obvious X11 screenshot command found."
            )
    else:
        result.append(
            "Desktop session type is unknown; do not choose an input backend yet."
        )

    return tuple(result)


def collect() -> DesktopProbe:
    commands = {
        name: _command(name)
        for name in (
            "ydotool",
            "wtype",
            "xdotool",
            "grim",
            "slurp",
            "gnome-screenshot",
            "scrot",
            "import",
            "gdbus",
            "busctl",
            "loginctl",
            "gsettings",
        )
    }

    uinput = Path("/dev/uinput")

    atspi_python = (
        importlib.util.find_spec("pyatspi") is not None
        or importlib.util.find_spec("gi") is not None
    )

    return DesktopProbe(
        session_type=(
            os.environ.get("XDG_SESSION_TYPE")
            or None
        ),
        desktop=(
            os.environ.get("XDG_CURRENT_DESKTOP")
            or os.environ.get("DESKTOP_SESSION")
            or None
        ),
        display=os.environ.get("DISPLAY") or None,
        wayland_display=(
            os.environ.get("WAYLAND_DISPLAY")
            or None
        ),
        dbus_session_bus=bool(
            os.environ.get("DBUS_SESSION_BUS_ADDRESS")
        ),
        atspi_python=atspi_python,
        toolkit_accessibility=_gsettings_accessibility(),
        commands=commands,
        dev_uinput_exists=uinput.exists(),
        dev_uinput_readable=os.access(
            uinput,
            os.R_OK,
        ),
        dev_uinput_writable=os.access(
            uinput,
            os.W_OK,
        ),
        recommendations=_recommendations(
            session_type=(
                os.environ.get("XDG_SESSION_TYPE")
                or None
            ),
            atspi_python=atspi_python,
            commands=commands,
            uinput_writable=os.access(
                uinput,
                os.W_OK,
            ),
        ),
    )


def main() -> int:
    probe = collect()

    print("HEIWA DESKTOP CAPABILITY PROBE")
    print(
        json.dumps(
            asdict(probe),
            ensure_ascii=False,
            indent=2,
        )
    )

    if probe.session_type is None:
        print(
            "DESKTOP CAPABILITY PROBE: INCOMPLETE "
            "(no XDG_SESSION_TYPE)"
        )
        return 2

    print("DESKTOP CAPABILITY PROBE: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
