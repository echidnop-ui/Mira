"""Desktop body for Heiwa."""
