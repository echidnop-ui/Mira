from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import subprocess
from typing import Any


SYSTEM_PYTHON = "/usr/bin/python3"


class DesktopPerceptionError(RuntimeError):
    """Raised when semantic Desktop perception cannot be queried."""


@dataclass(frozen=True, slots=True)
class FocusedDesktopContext:
    application: str
    window: str
    name: str
    role: str
    focused: bool
    focusable: bool
    editable: bool
    text: str | None
    caret_offset: int | None


_FOCUSED_CONTEXT_SCRIPT = r"""
import json
import pyatspi


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def safe_state(node, state):
    try:
        return bool(node.getState().contains(state))
    except Exception:
        return False


def children(node):
    try:
        count = int(getattr(node, "childCount", 0))
    except Exception:
        return []

    result = []
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def safe_text_snapshot(node):
    try:
        text_iface = node.queryText()
        count = int(text_iface.characterCount)
        text = text_iface.getText(0, count)
        caret = int(text_iface.caretOffset)
        if caret < 0:
            caret = None
        return text, caret
    except Exception:
        return None, None


desktop = pyatspi.Registry.getDesktop(0)
active_windows = []

# A focused control belongs to the currently active top-level window.
# Restricting the search here avoids walking unrelated accessibility trees
# such as a large Firefox document merely to discover keyboard focus.
for app in children(desktop):
    app_name = safe_name(app)

    for window in children(app):
        if not (
            safe_state(window, pyatspi.STATE_ACTIVE)
            or safe_state(window, pyatspi.STATE_FOCUSED)
        ):
            continue

        active_windows.append((app_name, safe_name(window), window))

# GNOME Shell can expose an active accessibility surface while a normal
# application owns keyboard focus. Prefer application windows when present.
active_windows.sort(key=lambda item: item[0] == "gnome-shell")

result = None

for app_name, window_name, window in active_windows:
    best = None
    stack = [(window, 0)]

    while stack:
        node, depth = stack.pop()

        if safe_state(node, pyatspi.STATE_FOCUSED):
            role = safe_role(node)
            editable = safe_state(node, pyatspi.STATE_EDITABLE)
            focusable = safe_state(node, pyatspi.STATE_FOCUSABLE)

            # Prefer the deepest focused semantic control in this one active
            # window. There is no reason to continue through other apps.
            score = depth
            if role not in {"application", "frame", "window"}:
                score += 40
            if editable:
                score += 30
            if role == "text":
                score += 20
            if focusable:
                score += 5

            candidate = (
                score,
                app_name,
                window_name,
                node,
                role,
                focusable,
                editable,
            )
            if best is None or candidate[0] > best[0]:
                best = candidate

        stack.extend((child, depth + 1) for child in children(node))

    if best is not None:
        (
            _score,
            app_name,
            window_name,
            node,
            role,
            focusable,
            editable,
        ) = best
        result = (
            app_name,
            window_name,
            node,
            role,
            focusable,
            editable,
        )
        break

if result is None:
    print("null")
else:
    (
        app_name,
        window_name,
        node,
        role,
        focusable,
        editable,
    ) = result

    text, caret = safe_text_snapshot(node)

    print(
        json.dumps(
            {
                "application": app_name,
                "window": window_name,
                "name": safe_name(node),
                "role": role,
                "focused": True,
                "focusable": focusable,
                "editable": editable,
                "text": text,
                "caret_offset": caret,
            },
            ensure_ascii=False,
        )
    )
"""


_TARGET_CONTEXT_SCRIPT = r"""
import json
import sys
import pyatspi


target_application = sys.argv[1]
target_window = sys.argv[2]
target_name = sys.argv[3]
target_role = sys.argv[4]


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def safe_state(node, state):
    try:
        return bool(node.getState().contains(state))
    except Exception:
        return False


def children(node):
    try:
        count = int(getattr(node, "childCount", 0))
    except Exception:
        return []

    result = []
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def safe_text_snapshot(node):
    try:
        text_iface = node.queryText()
        count = int(text_iface.characterCount)
        text = text_iface.getText(0, count)
        caret = int(text_iface.caretOffset)
        if caret < 0:
            caret = None
        return text, caret
    except Exception:
        return None, None


desktop = pyatspi.Registry.getDesktop(0)
result = None

for app in children(desktop):
    if safe_name(app) != target_application:
        continue

    for window in children(app):
        if safe_name(window) != target_window:
            continue

        stack = [window]

        while stack:
            node = stack.pop()

            if (
                safe_name(node) == target_name
                and safe_role(node) == target_role
            ):
                text, caret = safe_text_snapshot(node)

                result = {
                    "application": safe_name(app),
                    "window": safe_name(window),
                    "name": safe_name(node),
                    "role": safe_role(node),
                    "focused": safe_state(node, pyatspi.STATE_FOCUSED),
                    "focusable": safe_state(node, pyatspi.STATE_FOCUSABLE),
                    "editable": safe_state(node, pyatspi.STATE_EDITABLE),
                    "text": text,
                    "caret_offset": caret,
                }
                break

            stack.extend(children(node))

        if result is not None:
            break

    if result is not None:
        break

print(json.dumps(result, ensure_ascii=False))
"""


class DesktopPerception:
    """
    Minimal semantic Desktop perception through AT-SPI.

    This is a sensor only. It does not focus windows, choose actions,
    or execute input.
    """

    def __init__(
        self,
        *,
        system_python: str = SYSTEM_PYTHON,
        timeout: float = 4.0,
    ) -> None:
        self.system_python = system_python
        self.timeout = timeout

    def available(self) -> bool:
        return Path(self.system_python).is_file()

    def focused_context(self) -> FocusedDesktopContext | None:
        return self._query(
            _FOCUSED_CONTEXT_SCRIPT,
        )

    def target_context(
        self,
        *,
        application: str,
        window: str,
        name: str,
        role: str,
    ) -> FocusedDesktopContext | None:
        """
        Re-read a previously observed semantic control even if it no longer
        owns global focus.

        This is used for external completion verification.
        """

        return self._query(
            _TARGET_CONTEXT_SCRIPT,
            application,
            window,
            name,
            role,
        )

    def _query(
        self,
        script: str,
        *arguments: str,
    ) -> FocusedDesktopContext | None:
        if not self.available():
            raise DesktopPerceptionError(
                f"system Python not available: {self.system_python}"
            )

        env = os.environ.copy()
        env["NO_AT_BRIDGE"] = "0"

        try:
            result = subprocess.run(
                (
                    self.system_python,
                    "-c",
                    script,
                    *arguments,
                ),
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
                timeout=self.timeout,
            )
        except subprocess.TimeoutExpired as exc:
            raise DesktopPerceptionError(
                f"AT-SPI query timed out after {self.timeout}s"
            ) from exc
        except OSError as exc:
            raise DesktopPerceptionError(
                f"failed to query AT-SPI: {exc}"
            ) from exc

        if result.returncode != 0:
            raise DesktopPerceptionError(
                "AT-SPI query failed: "
                + (
                    result.stderr.strip()
                    or f"returncode={result.returncode}"
                )
            )

        raw = result.stdout.strip()

        try:
            payload: Any = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise DesktopPerceptionError(
                f"AT-SPI returned invalid JSON: {raw!r}"
            ) from exc

        if payload is None:
            return None

        if not isinstance(payload, dict):
            raise DesktopPerceptionError(
                "AT-SPI returned an unexpected payload"
            )

        raw_caret = payload.get("caret_offset")
        caret_offset = (
            int(raw_caret)
            if isinstance(raw_caret, int)
            else None
        )

        raw_text = payload.get("text")
        text = raw_text if isinstance(raw_text, str) else None

        return FocusedDesktopContext(
            application=str(payload.get("application", "")),
            window=str(payload.get("window", "")),
            name=str(payload.get("name", "")),
            role=str(payload.get("role", "")),
            focused=bool(payload.get("focused", False)),
            focusable=bool(payload.get("focusable", False)),
            editable=bool(payload.get("editable", False)),
            text=text,
            caret_offset=caret_offset,
        )
