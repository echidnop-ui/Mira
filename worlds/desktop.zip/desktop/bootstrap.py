from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


_REQUIRED_APT = (
    "python3-pyatspi",
    "ydotool",
    "gnome-screenshot",
)


def _run(
    argv: tuple[str, ...],
    *,
    timeout: float = 5.0,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        argv,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=timeout,
    )


def _system_python_has_atspi() -> bool:
    python = Path("/usr/bin/python3")
    if not python.exists():
        return False

    result = _run(
        (
            str(python),
            "-c",
            "import pyatspi; print('OK')",
        )
    )
    return result.returncode == 0


def _toolkit_accessibility() -> str | None:
    if shutil.which("gsettings") is None:
        return None

    result = _run(
        (
            "gsettings",
            "get",
            "org.gnome.desktop.interface",
            "toolkit-accessibility",
        )
    )
    if result.returncode != 0:
        return None
    return result.stdout.strip()


def _enable_accessibility() -> bool:
    if shutil.which("gsettings") is None:
        return False

    result = _run(
        (
            "gsettings",
            "set",
            "org.gnome.desktop.interface",
            "toolkit-accessibility",
            "true",
        )
    )
    return result.returncode == 0


def _capture_smoke() -> dict[str, object]:
    command = shutil.which("gnome-screenshot")
    if command is None:
        return {
            "available": False,
            "ok": False,
            "reason": "gnome-screenshot missing",
        }

    fd, raw_path = tempfile.mkstemp(
        prefix="heiwa-desktop-",
        suffix=".png",
    )
    os.close(fd)
    path = Path(raw_path)

    try:
        result = _run(
            (
                command,
                "-f",
                str(path),
            ),
            timeout=10.0,
        )

        size = path.stat().st_size if path.exists() else 0

        return {
            "available": True,
            "ok": (
                result.returncode == 0
                and size > 0
            ),
            "bytes": size,
            "stderr": result.stderr.strip(),
        }
    finally:
        try:
            path.unlink()
        except FileNotFoundError:
            pass


def _atspi_smoke() -> dict[str, object]:
    if not _system_python_has_atspi():
        return {
            "available": False,
            "ok": False,
            "reason": "system Python pyatspi missing",
        }

    script = r"""
import json
import pyatspi

desktop = pyatspi.Registry.getDesktop(0)

apps = []
for index in range(desktop.childCount):
    child = desktop.getChildAtIndex(index)
    if child is None:
        continue
    apps.append({
        "name": getattr(child, "name", "") or "",
        "role": child.getRoleName(),
    })

print(json.dumps(apps, ensure_ascii=False))
"""

    result = _run(
        (
            "/usr/bin/python3",
            "-c",
            script,
        ),
        timeout=10.0,
    )

    if result.returncode != 0:
        return {
            "available": True,
            "ok": False,
            "stderr": result.stderr.strip(),
        }

    try:
        apps = json.loads(result.stdout)
    except json.JSONDecodeError:
        apps = []

    return {
        "available": True,
        "ok": True,
        "applications_seen": len(apps),
        "applications": apps[:20],
    }


def main() -> int:
    if os.environ.get("XDG_SESSION_TYPE") != "wayland":
        print(
            "DESKTOP BOOTSTRAP FAILED: expected Wayland session",
            file=sys.stderr,
        )
        return 1

    before = _toolkit_accessibility()
    accessibility_set = _enable_accessibility()
    after = _toolkit_accessibility()

    system_atspi = _system_python_has_atspi()
    ydotool = shutil.which("ydotool")
    screenshot = shutil.which("gnome-screenshot")

    missing: list[str] = []

    if not system_atspi:
        missing.append("python3-pyatspi")
    if ydotool is None:
        missing.append("ydotool")
    if screenshot is None:
        missing.append("gnome-screenshot")

    print("HEIWA DESKTOP BOOTSTRAP")
    print("session_type: wayland")
    print("accessibility_before:", before)
    print("accessibility_set:", accessibility_set)
    print("accessibility_after:", after)
    print("system_python_atspi:", system_atspi)
    print("ydotool:", ydotool)
    print("gnome_screenshot:", screenshot)
    print("dev_uinput_exists:", Path("/dev/uinput").exists())
    print(
        "dev_uinput_writable:",
        os.access("/dev/uinput", os.W_OK),
    )

    if missing:
        print(
            "MISSING_APT_PACKAGES:",
            " ".join(missing),
        )
        print(
            "INSTALL_COMMAND:",
            "sudo apt update && sudo apt install -y "
            + " ".join(missing),
        )
        print(
            "DESKTOP BOOTSTRAP: NEEDS PACKAGES"
        )
        return 2

    atspi = _atspi_smoke()
    capture = _capture_smoke()

    print(
        "ATSPI_SMOKE:",
        json.dumps(
            atspi,
            ensure_ascii=False,
        ),
    )
    print(
        "SCREENSHOT_SMOKE:",
        json.dumps(
            capture,
            ensure_ascii=False,
        ),
    )

    if not atspi.get("ok"):
        print("DESKTOP BOOTSTRAP: ATSPI FAILED")
        return 3

    if not capture.get("ok"):
        print("DESKTOP BOOTSTRAP: SCREENSHOT FAILED")
        return 4

    if not os.access("/dev/uinput", os.W_OK):
        print(
            "UINPUT_NOTE: ydotool is installed but /dev/uinput "
            "is not writable for this user; motor setup remains."
        )
        print(
            "DESKTOP BOOTSTRAP: PERCEPTION READY, MOTOR BLOCKED"
        )
        return 5

    print("DESKTOP BOOTSTRAP: READY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
