from __future__ import annotations

from dataclasses import replace
import math
import os
from pathlib import Path
import subprocess
import time
from uuid import uuid4

import torch

from contracts.cognition import ActionIntent
from core.interface import CoreInput
from core.personal import PersonalCognitiveCore, PersonalCoreConfig
from language.interface import ExpressionRequest, LanguageInput
from language.organ import NeuralLanguageConfig, NeuralLanguageOrgan
from worlds.desktop.adapter import DesktopWorldAdapter, TYPE_TEXT_ACTION
from worlds.desktop.representation import represent_desktop_frame


HUMAN_PROMPT = "Человек: Ты меня видишь? Ответь, что ты здесь."
# Keep the first physical output ASCII because current ydotool smoke has only
# proven keyboard injection, not arbitrary Unicode layout synthesis.
MENTOR_REPLY = " I am here"
TARGET_MODULE = "worlds.desktop.neural_language_target"
TARGET_APP_NAME = "neural_language_target.py"
IBUS_COMMAND = "/usr/bin/ibus"
YDOTOOL_COMMAND = "/usr/bin/ydotool"
YDOTOOL_SOCKET = "/run/heiwa-ydotool.sock"
LATIN_INPUT_ENGINE = "xkb:us::eng"


_FOCUS_TARGET = rf"""
import time
import pyatspi

deadline = time.monotonic() + 5.0

while time.monotonic() < deadline:
    desktop = pyatspi.Registry.getDesktop(0)

    for app_index in range(desktop.childCount):
        try:
            app = desktop.getChildAtIndex(app_index)
            if app is None or app.name != {TARGET_APP_NAME!r}:
                continue
        except Exception:
            continue

        stack = [app]

        while stack:
            node = stack.pop()

            try:
                if node.getRole() == pyatspi.ROLE_TEXT:
                    component = node.queryComponent()
                    if not component.grabFocus():
                        continue

                    text = node.queryText()
                    try:
                        while text.getNSelections() > 0:
                            text.removeSelection(0)
                    except Exception:
                        pass
                    text.setCaretOffset(text.characterCount)
                    time.sleep(0.15)
                    raise SystemExit(0)
            except Exception:
                pass

            try:
                for index in range(node.childCount):
                    child = node.getChildAtIndex(index)
                    if child is not None:
                        stack.append(child)
            except Exception:
                pass

    time.sleep(0.1)

raise SystemExit(1)
"""


def _focused_text(frame) -> str:
    for observation in frame.observations:
        if observation.kind != "desktop.focused_context":
            continue
        text = observation.payload.get("text")
        if isinstance(text, str):
            return text
    raise AssertionError("Desktop frame has no focused text observation")


def _typing_affordance(frame):
    matches = [
        affordance
        for affordance in frame.affordances
        if affordance.action == TYPE_TEXT_ACTION
    ]
    if len(matches) != 1:
        raise AssertionError(
            f"expected exactly one desktop.type_text affordance; got {len(matches)}"
        )
    return matches[0]


def _assert_finite(name: str, values: tuple[float, ...]) -> None:
    if not values:
        raise AssertionError(f"{name} is empty")
    if not all(math.isfinite(value) for value in values):
        raise AssertionError(f"{name} contains non-finite values")


def _ibus_engine() -> str:
    result = subprocess.run(
        (IBUS_COMMAND, "engine"),
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=3.0,
    )
    if result.returncode != 0:
        raise RuntimeError(
            "failed to query/set IBus engine: "
            + (result.stderr.strip() or f"returncode={result.returncode}")
        )
    return result.stdout.strip()


def _advance_input_engine() -> None:
    env = os.environ.copy()
    env["YDOTOOL_SOCKET"] = YDOTOOL_SOCKET
    result = subprocess.run(
        (
            YDOTOOL_COMMAND,
            "key",
            "125:1",
            "57:1",
            "57:0",
            "125:0",
        ),
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=env,
        timeout=3.0,
    )
    if result.returncode != 0:
        raise RuntimeError(
            "failed to switch input engine: "
            + (result.stderr.strip() or f"returncode={result.returncode}")
        )
    time.sleep(0.4)


def _select_input_engine(target: str) -> None:
    for _ in range(8):
        if _ibus_engine() == target:
            return
        _advance_input_engine()
    raise RuntimeError(f"could not select input engine: {target}")


def main() -> int:
    print("HEIWA DESKTOP -> LANGUAGE -> CORE -> LANGUAGE -> DESKTOP SMOKE")
    print(f"torch: {torch.__version__}")
    print(f"hip: {getattr(torch.version, 'hip', None)}")
    print(f"accelerator_available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"accelerator: {torch.cuda.get_device_name(0)}")

    project_root = Path(__file__).resolve().parents[2]
    target_env = os.environ.copy()
    target_env["GDK_BACKEND"] = "wayland"
    target_env["NO_AT_BRIDGE"] = "0"
    target_env["HEIWA_NEURAL_LANGUAGE_PROMPT"] = HUMAN_PROMPT

    target = subprocess.Popen(
        ("/usr/bin/python3", "-m", TARGET_MODULE),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=str(project_root),
        env=target_env,
    )

    adapter = DesktopWorldAdapter()
    original_input_engine = None

    try:
        focus = subprocess.run(
            ("/usr/bin/python3", "-c", _FOCUS_TARGET),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=target_env,
            timeout=7.0,
        )
        print("focus_returncode:", focus.returncode)
        if focus.returncode != 0:
            print("focus_stderr:", focus.stderr.strip())
            print("NEURAL LANGUAGE DESKTOP SMOKE FAILED: target focus")
            return 2

        transition_id = f"desktop-language-{uuid4().hex}"
        frame = adapter.poll(time.monotonic())
        observed_text = _focused_text(frame)
        affordance = _typing_affordance(frame)

        print("desktop_observed_text:", observed_text)
        print("desktop_affordance:", affordance.action)
        if observed_text != HUMAN_PROMPT:
            print("NEURAL LANGUAGE DESKTOP SMOKE FAILED: AT-SPI input mismatch")
            return 3

        desktop_representation = represent_desktop_frame(
            frame,
            transition_id=transition_id,
            size=96,
        )
        _assert_finite("desktop_representation", desktop_representation.vector)
        print("desktop_representation: OK")

        language_config = NeuralLanguageConfig(
            representation_size=96,
            cognitive_size=96,
            embedding_size=256,
            hidden_size=384,
            recurrent_layers=3,
            attention_heads=6,
            dropout=0.0,
            max_input_bytes=512,
            max_generation_bytes=64,
            learning_rate=1e-3,
            max_traces=16,
            device=None,
        )
        language = NeuralLanguageOrgan(language_config)

        core_config = replace(
            PersonalCoreConfig.smoke(device=None),
            router_top_k=4,
        )
        core = PersonalCognitiveCore(core_config)

        print("language_device:", language.device)
        print("core_device:", core.device)
        print("core_router_top_k:", core.config.router_top_k)

        human_input = LanguageInput(
            transition_id=transition_id,
            text=observed_text,
            source_kind="human",
            source_id="desktop.atspi",
            metadata={"world": adapter.world_id},
        )

        teacher_loss = language.learn_teacher_text(human_input)
        representation = language.encode(
            human_input,
            remember_for_learning=False,
        )
        _assert_finite("language_representation", representation.vector)
        print("language_receptive: OK")
        print(f"teacher_language_loss: {teacher_loss:.6f}")

        cognitive = core.integrate(
            CoreInput(
                transition_id=transition_id,
                world_id=adapter.world_id,
                representation=representation.vector,
                metadata={
                    "source": "desktop_language_smoke",
                    "desktop_representation_available": True,
                },
            ),
            remember_for_learning=False,
        )
        _assert_finite("cognitive_state", cognitive.vector)
        print("core_integrate: OK")
        print("core_active_experts:", ", ".join(core.telemetry().last_active_experts))

        mentor_target = LanguageInput(
            transition_id=f"{transition_id}:mentor-expression",
            text=MENTOR_REPLY,
            source_kind="mentor",
            source_id="integration-smoke-teacher",
        )

        realized = None
        expression_loss = float("nan")
        expression_updates = 0
        for step in range(1, 41):
            expression_loss = language.learn_expression(
                cognitive.vector,
                mentor_target,
            )
            expression_updates = step
            if step % 5 != 0:
                continue

            torch.manual_seed(20260828)
            realized = language.realize(
                ExpressionRequest(
                    transition_id=transition_id,
                    cognitive_state=cognitive.vector,
                    max_bytes=32,
                    temperature=0.05,
                    metadata={"destination": "desktop"},
                )
            )
            if realized.text == MENTOR_REPLY:
                break

        if realized is None or realized.text != MENTOR_REPLY:
            print("generated_text:", repr(realized.text if realized else None))
            print("expression_updates:", expression_updates)
            print(f"expression_loss: {expression_loss:.6f}")
            print("NEURAL LANGUAGE DESKTOP SMOKE FAILED: expression did not converge")
            return 4

        print("language_expression: OK")
        print("generated_text:", repr(realized.text))
        print("expression_updates:", expression_updates)
        print(f"expression_loss: {expression_loss:.6f}")

        original_input_engine = _ibus_engine()
        print("input_engine_before:", original_input_engine)
        _select_input_engine(LATIN_INPUT_ENGINE)
        print("input_engine_for_output:", _ibus_engine())

        refocus = subprocess.run(
            ("/usr/bin/python3", "-c", _FOCUS_TARGET),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=target_env,
            timeout=7.0,
        )
        print("refocus_returncode:", refocus.returncode)
        if refocus.returncode != 0:
            print("refocus_stderr:", refocus.stderr.strip())
            print("NEURAL LANGUAGE DESKTOP SMOKE FAILED: target refocus")
            return 5

        execution_frame = adapter.poll(time.monotonic())
        if _focused_text(execution_frame) != HUMAN_PROMPT:
            print("NEURAL LANGUAGE DESKTOP SMOKE FAILED: target changed before output")
            return 5
        affordance = _typing_affordance(execution_frame)

        intent = ActionIntent(
            id=f"desktop-intent-{uuid4().hex}",
            transition_id=transition_id,
            affordance_id=affordance.id,
            world=adapter.world_id,
            action=affordance.action,
            created_at=time.monotonic(),
            parameters={"text": realized.text},
        )
        attempt = adapter.execute(intent, now=time.monotonic())
        print("desktop_attempt_accepted:", attempt.accepted)
        if not attempt.accepted:
            print("attempt_reason:", attempt.payload.get("reason", ""))
            print("NEURAL LANGUAGE DESKTOP SMOKE FAILED: motor attempt rejected")
            return 5

        completed = ()
        last_observed = None
        deadline = time.monotonic() + 4.0
        while time.monotonic() < deadline:
            observed = adapter.poll(time.monotonic())
            last_observed = observed
            if observed.completed_actions:
                completed = observed.completed_actions
                break
            time.sleep(0.05)

        if len(completed) != 1:
            if last_observed is not None and last_observed.observations:
                payload = last_observed.observations[0].payload
                print("last_focused_application:", payload.get("application", ""))
                print("last_focused_control:", payload.get("control_name", ""))
                print("last_focused_text:", repr(payload.get("text")))
                print("last_caret_offset:", payload.get("caret_offset"))
            if target.poll() is not None:
                target_stdout, target_stderr = target.communicate(timeout=1.0)
                target_lines = target_stdout.strip().splitlines()
                print("target_observed_text:", repr(target_lines[-1] if target_lines else ""))
                print("target_stderr:", target_stderr.strip())
            print("NEURAL LANGUAGE DESKTOP SMOKE FAILED: completion not observed")
            return 6

        action = completed[0]
        print("desktop_completed:", action.succeeded)
        print("completed_transition_preserved:", action.transition_id == transition_id)
        print("verified_by:", action.payload.get("verified_by"))
        if not action.succeeded or action.transition_id != transition_id:
            print("NEURAL LANGUAGE DESKTOP SMOKE FAILED: bad CompletedAction")
            return 7

        stdout, stderr = target.communicate(timeout=8.0)
        observed_lines = stdout.strip().splitlines()
        final_text = observed_lines[-1] if observed_lines else ""
        expected_final = HUMAN_PROMPT + MENTOR_REPLY

        print("target_text:", final_text)
        print("target_stderr:", stderr.strip())
        if final_text != expected_final:
            print("expected_target_text:", expected_final)
            print("NEURAL LANGUAGE DESKTOP SMOKE FAILED: physical text mismatch")
            return 8

        print("autonomous_policy_selection: NOT TESTED (expression action externally staged)")
        print(
            "CHAIN: GTK human text -> AT-SPI -> DesktopWorldAdapter.poll -> "
            "Language.encode -> Core.integrate[4/4] -> Language.realize -> "
            "ActionIntent -> DesktopMotor -> AT-SPI -> CompletedAction"
        )
        print("HEIWA NEURAL LANGUAGE DESKTOP SMOKE: OK")
        return 0

    finally:
        adapter.close()
        if (
            original_input_engine is not None
            and original_input_engine != LATIN_INPUT_ENGINE
        ):
            try:
                _select_input_engine(original_input_engine)
            except Exception as exc:
                print("input_engine_restore_failed:", str(exc))
        if target.poll() is None:
            target.terminate()
            try:
                target.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                target.kill()


if __name__ == "__main__":
    raise SystemExit(main())
