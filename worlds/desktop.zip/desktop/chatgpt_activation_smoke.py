from __future__ import annotations

from runtime.mentor_session import MentorSession
import worlds.desktop.chatgpt_bootstrap as bootstrap_module
from worlds.desktop.chatgpt_bootstrap import (
    ChatGPTComposer,
    ChatGPTDesktopBootstrap,
    ChatGPTDesktopError,
)


def _composer(*, active: bool, focused: bool) -> ChatGPTComposer:
    return ChatGPTComposer(
        application="Firefox",
        window="Intended ChatGPT — Mozilla Firefox",
        name="Chat with ChatGPT",
        role="entry",
        text="\ufffc",
        caret_offset=0,
        score=368,
        window_active=active,
        control_focused=focused,
        document_showing=True,
    )


class _ActivationRegressionBridge(ChatGPTDesktopBootstrap):
    def __init__(self, *, activation_succeeds: bool) -> None:
        self.diagnostics = False
        self.activation_succeeds = activation_succeeds
        self.activation_calls = 0
        self.focus_calls = 0

    def focus_composer(self) -> ChatGPTComposer:
        self.focus_calls += 1
        activated = self.activation_succeeds and self.activation_calls > 0
        return _composer(active=activated, focused=activated)

    def _activate_exact_firefox_window(
        self,
        window: str,
        *,
        attempt: int,
    ) -> bool:
        assert window == "Intended ChatGPT — Mozilla Firefox"
        assert 1 <= attempt <= 3
        self.activation_calls += 1
        return self.activation_succeeds


class _CachedQueryBridge(ChatGPTDesktopBootstrap):
    def __init__(self) -> None:
        super().__init__(motor=object(), diagnostics=False)  # type: ignore[arg-type]
        self.full_discoveries = 0
        self.cached_verifications = 0
        self.window_fallbacks = 0
        self.invalidate_next = False
        self.allow_invariant = True

    def _run_atspi(
        self,
        script: str,
        *arguments: str,
        operation: str = "atspi",
    ) -> object:
        del script
        if operation == "activate_exact_firefox_window":
            return {"ok": False, "window_active": False}
        if operation not in {"focus_composer", "focus_composer_fallback"}:
            raise AssertionError(f"unexpected mock operation: {operation}")
        if len(arguments) == 4:
            self.cached_verifications += 1
            if self.invalidate_next:
                self.invalidate_next = False
                return {"ok": False, "reason": "stale cached node"}
        elif len(arguments) == 2:
            self.window_fallbacks += 1
        else:
            self.full_discoveries += 1
        return {
            "ok": True,
            "application": "Firefox",
            "window": "Intended ChatGPT — Mozilla Firefox",
            "name": "Chat with ChatGPT",
            "role": "entry",
            "text": "\ufffc",
            "caret_offset": 0,
            "score": 368,
            "window_active": self.allow_invariant,
            "control_focused": self.allow_invariant,
            "document_showing": True,
            "busy": False,
            "latest_response_text": "previous mentor reply",
        }


class _SessionSendBridge:
    def __init__(self) -> None:
        self.send_calls = 0
        self.last_pre_send_response = None

    def activate_composer(self) -> ChatGPTComposer:
        raise AssertionError("MentorSession performed redundant pre-activation")

    def latest_response(self) -> object:
        raise AssertionError("MentorSession performed redundant pre-send scan")

    def send_message(self, text: str) -> ChatGPTComposer:
        assert text == "outbound"
        self.send_calls += 1
        return _composer(active=True, focused=True)


def main() -> int:
    print("HEIWA CHATGPT EXACT WINDOW ACTIVATION SMOKE")

    for script_name in (
        "_PERSISTENT_ATSPI_EXECUTOR",
        "_FIND_AND_FOCUS_COMPOSER",
        "_CHATGPT_BUSY",
        "_LATEST_CHATGPT_RESPONSE",
        "_CLICK_CHATGPT_SEND",
        "_VERIFY_EXACT_COMPOSER_TEXT",
        "_OBSERVE_EXACT_COMPOSER_SUBMISSION",
    ):
        compile(getattr(bootstrap_module, script_name), script_name, "exec")
    print("embedded_atspi_workers_compile: OK")

    configured = ChatGPTDesktopBootstrap(motor=object(), diagnostics=False)  # type: ignore[arg-type]
    assert configured.query_timeout == 10.0
    custom = ChatGPTDesktopBootstrap(
        motor=object(),  # type: ignore[arg-type]
        query_timeout=7.5,
        diagnostics=False,
    )
    assert custom.query_timeout == 7.5
    try:
        ChatGPTDesktopBootstrap(
            motor=object(),  # type: ignore[arg-type]
            query_timeout=0.0,
            diagnostics=False,
        )
    except ValueError:
        pass
    else:
        raise AssertionError("unbounded AT-SPI timeout configuration was accepted")
    print("atspi_query_timeout_default_seconds: 10.0")
    print("atspi_query_timeout_bounded: OK")

    cached = _CachedQueryBridge()
    first = cached._activate_ready_composer()
    assert first.window_active and first.control_focused
    assert cached.full_discoveries == 1
    assert cached.cached_verifications == 0
    second = cached._activate_ready_composer()
    assert second.window_active and second.control_focused
    assert cached.full_discoveries == 1
    assert cached.cached_verifications == 1
    print("normal_send_full_discovery_count: 1")
    print("cached_fresh_invariant_verification: OK")

    cached.invalidate_next = True
    recovered = cached._activate_ready_composer()
    assert recovered.window_active and recovered.control_focused
    assert cached.window_fallbacks == 1
    assert cached.full_discoveries == 1
    print("cache_invalidation_exact_window_fallback: OK")

    unsafe = _CachedQueryBridge()
    unsafe.allow_invariant = False
    try:
        unsafe._activate_ready_composer()
    except ChatGPTDesktopError:
        pass
    else:
        raise AssertionError("send preparation passed without fresh invariant")
    print("send_without_fresh_invariant: BLOCKED_OK")

    session_bridge = _SessionSendBridge()
    session = MentorSession(session_bridge, object())  # type: ignore[arg-type]
    session.send_supervised_message("outbound")
    assert session_bridge.send_calls == 1
    print("mentor_session_redundant_prescans: 0")

    bridge = _ActivationRegressionBridge(activation_succeeds=True)
    result = bridge.activate_composer()
    assert result.window_active
    assert result.control_focused
    assert result.document_showing
    assert bridge.activation_calls == 1
    assert bridge.focus_calls == 2
    print("inactive_window_exact_activation: OK")
    print("composer_refocus_after_activation: OK")
    print("activation_invariant: OK")

    blocked = _ActivationRegressionBridge(activation_succeeds=False)
    try:
        blocked.activate_composer()
    except ChatGPTDesktopError as exc:
        assert "window_active" in str(exc)
        assert "control_focused" in str(exc)
    else:
        raise AssertionError("inactive Firefox window unexpectedly passed invariant")
    assert blocked.activation_calls == 3
    print("bounded_attempts: 3")
    print("failed_activation_rejected: OK")
    print("HEIWA CHATGPT EXACT WINDOW ACTIVATION SMOKE: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
