from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import select
import shlex
import subprocess
import time
from typing import Any

from worlds.desktop.motor import DesktopMotor, KEY_ENTER


SYSTEM_PYTHON = "/usr/bin/python3"
SNAP_COMMAND = "/usr/bin/snap"
FIREFOX_PYATSPI_DIR = Path.home() / "snap/firefox/common/heiwa-atspi"


_PERSISTENT_ATSPI_EXECUTOR = r'''
import contextlib
import io
import json
import sys

shared_cache = {}
print(json.dumps({"ready": True}), flush=True)
for raw in sys.stdin:
    try:
        request = json.loads(raw)
        output = io.StringIO()
        scope = {
            "__name__": "__main__",
            "_HEIWA_ATSPI_CACHE": shared_cache,
        }
        old_argv = sys.argv
        sys.argv = ["heiwa-atspi", *request.get("arguments", [])]
        try:
            with contextlib.redirect_stdout(output):
                try:
                    exec(request["script"], scope, scope)
                except SystemExit as exc:
                    if exc.code not in (None, 0):
                        raise
        finally:
            sys.argv = old_argv
        lines = [line for line in output.getvalue().splitlines() if line.strip()]
        if not lines:
            raise RuntimeError("AT-SPI operation produced no result")
        response = {"ok": True, "result": lines[-1]}
    except BaseException as exc:
        response = {"ok": False, "error": repr(exc)}
    print(json.dumps(response, ensure_ascii=False), flush=True)
'''


class _PersistentFirefoxATSPI:
    """Lazy long-lived Firefox Snap worker for bounded AT-SPI operations."""

    def __init__(self, *, timeout: float) -> None:
        self.timeout = float(timeout)
        self._process: subprocess.Popen[str] | None = None

    def close(self) -> None:
        process = self._process
        self._process = None
        if process is None or process.poll() is not None:
            return
        process.terminate()
        try:
            process.wait(timeout=1.0)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=1.0)

    def request(self, script: str, arguments: tuple[str, ...]) -> str:
        process = self._ensure_worker()
        if process.stdin is None:
            self.close()
            raise ChatGPTDesktopError("persistent Firefox AT-SPI stdin unavailable")
        try:
            process.stdin.write(
                json.dumps({"script": script, "arguments": arguments}) + "\n"
            )
            process.stdin.flush()
        except (BrokenPipeError, OSError) as exc:
            self.close()
            raise ChatGPTDesktopError(
                f"persistent Firefox AT-SPI write failed: {exc}"
            ) from exc
        payload = self._read_payload(process, timeout=self.timeout)
        if payload.get("ok") is not True:
            raise ChatGPTDesktopError(
                "persistent Firefox AT-SPI operation failed: "
                + str(payload.get("error", "unknown error"))
            )
        result = payload.get("result")
        if not isinstance(result, str):
            raise ChatGPTDesktopError(
                "persistent Firefox AT-SPI returned a non-text result"
            )
        return result

    def _ensure_worker(self) -> subprocess.Popen[str]:
        process = self._process
        if process is not None and process.poll() is None:
            return process
        helper_path = shlex.quote(str(FIREFOX_PYATSPI_DIR))
        python_command = shlex.join(
            ("python3", "-u", "-c", _PERSISTENT_ATSPI_EXECUTOR)
        )
        launcher = (
            f"export PYTHONPATH={helper_path}:"
            '"$SNAP/gnome-platform/usr/lib/python3.12":'
            '"$SNAP/gnome-platform/usr/lib/python3/dist-packages"; '
            f"exec {python_command}"
        )
        try:
            process = subprocess.Popen(
                (SNAP_COMMAND, "run", "--shell", "firefox", "-c", launcher),
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                bufsize=1,
            )
        except OSError as exc:
            raise ChatGPTDesktopError(
                f"persistent Firefox AT-SPI failed to start: {exc}"
            ) from exc
        self._process = process
        ready = self._read_payload(process, timeout=self.timeout)
        if ready.get("ready") is not True:
            self.close()
            raise ChatGPTDesktopError(
                f"persistent Firefox AT-SPI bad handshake: {ready!r}"
            )
        return process

    def _read_payload(
        self,
        process: subprocess.Popen[str],
        *,
        timeout: float,
    ) -> dict[str, Any]:
        if process.stdout is None:
            self.close()
            raise ChatGPTDesktopError("persistent Firefox AT-SPI stdout unavailable")
        readable, _, _ = select.select([process.stdout], [], [], timeout)
        if not readable:
            self.close()
            raise ChatGPTDesktopError(
                f"persistent Firefox AT-SPI timed out after {timeout:.3f}s"
            )
        raw = process.stdout.readline()
        if not raw:
            code = process.poll()
            self.close()
            raise ChatGPTDesktopError(
                "persistent Firefox AT-SPI exited unexpectedly: "
                f"returncode={code}"
            )
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            self.close()
            raise ChatGPTDesktopError(
                f"persistent Firefox AT-SPI invalid JSON: {raw[:300]!r}"
            ) from exc
        if not isinstance(payload, dict):
            raise ChatGPTDesktopError(
                "persistent Firefox AT-SPI payload must be an object"
            )
        return payload


class ChatGPTDesktopError(RuntimeError):
    """Raised when the bootstrap ChatGPT UI bridge cannot verify an operation."""


@dataclass(frozen=True, slots=True)
class ChatGPTComposer:
    application: str
    window: str
    name: str
    role: str
    text: str
    caret_offset: int | None
    score: int
    window_active: bool
    control_focused: bool
    document_showing: bool

    @property
    def has_draft(self) -> bool:
        return bool(self.text.replace("\ufffc", "").strip())


@dataclass(frozen=True, slots=True)
class ChatGPTTextMatch:
    application: str
    window: str
    name: str
    role: str
    text: str


@dataclass(frozen=True, slots=True)
class DesktopSendTiming:
    activate_ms: float = 0.0
    paste_send_ms: float = 0.0
    keyboard_path: str = ""
    composer_verified: bool = False
    send_path: str = ""
    send_attempted: bool = False
    send_completed: bool = False
    composer_cleared: bool = False
    send_ms: float = 0.0


@dataclass(frozen=True, slots=True)
class _SubmissionObservation:
    completed: bool
    composer_cleared: bool
    content_matches_expected: bool
    safe_for_fallback: bool
    user_message_count: int
    message_observed: bool


@dataclass(frozen=True, slots=True)
class _SubmissionResult:
    send_path: str
    send_attempted: bool
    send_completed: bool
    composer_cleared: bool
    send_ms: float


_SWITCH_CHATGPT_TAB = r'''
import json
import time
import pyatspi


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def state(node, value):
    try:
        return bool(node.getState().contains(value))
    except Exception:
        return False


def children(node):
    result = []
    try:
        count = int(node.childCount)
    except Exception:
        return result
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def shallow_nodes(root, max_depth=8):
    # Firefox's web document may contain thousands of AT-SPI nodes. Tab
    # discovery is browser chrome work, so never descend into document web.
    result = []
    stack = [(root, 0)]
    while stack:
        node, depth = stack.pop()
        result.append(node)
        if depth >= max_depth or safe_role(node) == "document web":
            continue
        stack.extend((child, depth + 1) for child in children(node))
    return result


def looks_like_chatgpt(value):
    lower = value.lower()
    return "chatgpt" in lower or "openai" in lower


desktop = pyatspi.Registry.getDesktop(0)
result = {"ok": False, "reason": "ChatGPT Firefox tab not found"}
for app_index in range(desktop.childCount):
    try:
        app = desktop.getChildAtIndex(app_index)
    except Exception:
        continue
    if app is None:
        continue
    app_name = safe_name(app).lower()
    if "firefox" not in app_name:
        continue

    for window in children(app):
        nodes = shallow_nodes(window)

        # If the visible web document already identifies itself as ChatGPT,
        # there is nothing to switch. This is the normal mentor-session path.
        showing_chatgpt = next(
            (
                node
                for node in nodes
                if safe_role(node) == "document web"
                and state(node, pyatspi.STATE_SHOWING)
                and looks_like_chatgpt(safe_name(node))
            ),
            None,
        )
        if showing_chatgpt is not None:
            result = {
                "ok": True,
                "document": safe_name(showing_chatgpt),
                "already_showing": True,
            }
            break

        tabs = [
            node
            for node in nodes
            if safe_role(node) == "page tab"
            and looks_like_chatgpt(safe_name(node))
        ]
        if not tabs:
            continue

        tab = tabs[0]
        try:
            actions = tab.queryAction()
            switched = False
            for action_index in range(actions.nActions):
                if actions.getName(action_index).lower() == "switch":
                    switched = bool(actions.doAction(action_index))
                    break
        except Exception as exc:
            result = {"ok": False, "reason": repr(exc)}
            break

        if switched:
            time.sleep(0.25)
            result = {
                "ok": True,
                "document": safe_name(tab),
                "already_showing": False,
            }
        else:
            result = {"ok": False, "reason": "Firefox tab switch action failed"}
        break

    if result.get("ok"):
        break

print(json.dumps(result, ensure_ascii=False))
'''


_ACTIVATE_EXACT_FIREFOX_WINDOW = r'''
import json
import sys
import time
import pyatspi

expected_window = sys.argv[1]


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def state(node, value):
    try:
        return bool(node.getState().contains(value))
    except Exception:
        return False


def children(node):
    result = []
    try:
        count = int(node.childCount)
    except Exception:
        return result
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def document_roots(window):
    result = []
    stack = [window]
    while stack:
        node = stack.pop()
        if safe_role(node) == "document web":
            result.append(node)
            continue
        stack.extend(children(node))
    return result


def contains_chatgpt_composer(document):
    stack = [document]
    while stack:
        node = stack.pop()
        if safe_name(node).strip().lower() == "chat with chatgpt":
            return True
        stack.extend(children(node))
    return False


desktop = pyatspi.Registry.getDesktop(0)
result = {
    "ok": False,
    "window": expected_window,
    "reason": "exact visible Firefox ChatGPT window not found",
}
for app_index in range(desktop.childCount):
    try:
        app = desktop.getChildAtIndex(app_index)
    except Exception:
        continue
    if "firefox" not in safe_name(app).lower():
        continue
    for window in children(app):
        if safe_name(window) != expected_window:
            continue
        intended_visible = any(
            state(document, pyatspi.STATE_SHOWING)
            and contains_chatgpt_composer(document)
            for document in document_roots(window)
        )
        if not intended_visible:
            result["reason"] = "intended ChatGPT document is not showing"
            break

        if state(window, pyatspi.STATE_ACTIVE):
            result = {
                "ok": True,
                "window": expected_window,
                "mechanism": "already_active",
                "window_active": True,
            }
            break

        mechanisms = []
        try:
            component_focused = bool(window.queryComponent().grabFocus())
            mechanisms.append("component.grabFocus")
        except Exception:
            component_focused = False
        if component_focused:
            time.sleep(0.20)

        if not state(window, pyatspi.STATE_ACTIVE):
            try:
                actions = window.queryAction()
                for action_index in range(actions.nActions):
                    if actions.getName(action_index).lower() == "click":
                        actions.doAction(action_index)
                        mechanisms.append("window.click")
                        time.sleep(0.35)
                        break
            except Exception:
                pass

        active = state(window, pyatspi.STATE_ACTIVE)
        result = {
            "ok": active,
            "window": expected_window,
            "mechanism": "+".join(mechanisms) or "none",
            "window_active": active,
            "reason": "" if active else "exact Firefox window remained inactive",
        }
        break
    if result.get("ok"):
        break

print(json.dumps(result, ensure_ascii=False))
'''


_CLICK_CHATGPT_SEND = r'''
import json
import sys
import pyatspi

expected_window = sys.argv[1] if len(sys.argv) > 1 else ""


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_description(node):
    try:
        return getattr(node, "description", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def safe_attributes(node):
    try:
        return list(node.getAttributes() or [])
    except Exception:
        return []


def state(node, value):
    try:
        return bool(node.getState().contains(value))
    except Exception:
        return False


def children(node):
    result = []
    try:
        count = int(node.childCount)
    except Exception:
        return result
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def document_roots(window):
    result = []
    stack = [window]
    while stack:
        node = stack.pop()
        if safe_role(node) == "document web":
            result.append(node)
            continue
        stack.extend(children(node))
    return result


def descendants(root):
    result = []
    stack = [root]
    while stack:
        node = stack.pop()
        result.append(node)
        stack.extend(children(node))
    return result


def looks_like_chatgpt(document, nodes):
    title = safe_name(document).lower()
    if "chatgpt" in title or "openai" in title:
        return True
    return any(safe_name(node).lower() == "chat with chatgpt" for node in nodes)


def send_signature(node):
    pieces = [safe_name(node), safe_description(node), *safe_attributes(node)]
    return " ".join(piece for piece in pieces if piece).casefold()


def is_send_button(node):
    if safe_role(node) not in {"push button", "button"}:
        return False
    if not state(node, pyatspi.STATE_SHOWING):
        return False
    signature = send_signature(node)
    return any(token in signature for token in (
        "send", "submit", "отправ", "send-button", "send_button"
    ))


def click(node):
    try:
        actions = node.queryAction()
        for action_index in range(actions.nActions):
            action_name = actions.getName(action_index).casefold()
            if action_name in {"click", "press", "activate"}:
                if actions.doAction(action_index):
                    return True
        if actions.nActions:
            return bool(actions.doAction(0))
    except Exception:
        return False
    return False


desktop = pyatspi.Registry.getDesktop(0)
result = {"ok": False, "reason": "visible ChatGPT Send button not found"}
visible_buttons = []
for app_index in range(desktop.childCount):
    try:
        app = desktop.getChildAtIndex(app_index)
    except Exception:
        continue
    app_name = safe_name(app)
    if "firefox" not in app_name.casefold():
        continue
    for window in children(app):
        if expected_window and safe_name(window) != expected_window:
            continue
        if not state(window, pyatspi.STATE_ACTIVE):
            continue
        for document in document_roots(window):
            if not state(document, pyatspi.STATE_SHOWING):
                continue
            nodes = descendants(document)
            if not looks_like_chatgpt(document, nodes):
                continue
            for node in nodes:
                if safe_role(node) in {"push button", "button"} and state(node, pyatspi.STATE_SHOWING):
                    if len(visible_buttons) < 16:
                        label = safe_name(node) or safe_description(node) or send_signature(node)[:120]
                        if label:
                            visible_buttons.append(label)
                if not is_send_button(node):
                    continue
                clicked = click(node)
                result = {
                    "ok": clicked,
                    "button": safe_name(node),
                    "signature": send_signature(node)[:240],
                    "reason": "" if clicked else "Send action returned false",
                }
                if clicked:
                    break
            if result.get("ok"):
                break
        if result.get("ok"):
            break
    if result.get("ok"):
        break

if not result.get("ok") and visible_buttons:
    result["visible_buttons"] = visible_buttons

print(json.dumps(result, ensure_ascii=False))
'''

_FIND_AND_FOCUS_COMPOSER = r'''
import json
import sys
import time
import pyatspi


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def state(node, value):
    try:
        return bool(node.getState().contains(value))
    except Exception:
        return False


def children(node):
    try:
        count = int(getattr(node, "childCount", 0))
    except Exception:
        return []
    result = []
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def text_snapshot(node):
    try:
        iface = node.queryText()
        count = int(iface.characterCount)
        return iface.getText(0, count), int(iface.caretOffset)
    except Exception:
        return "", None


def is_chatgpt_document(document, nodes):
    title = safe_name(document).lower()
    if "chatgpt" in title or "openai" in title:
        return True
    for node, _depth in nodes:
        name = safe_name(node).lower()
        if name in {"chatgpt", "openai"} or "chatgpt" in name:
            return True
    return False


def is_browser_application(application):
    # This bootstrap is deliberately bound to the proven Firefox Snap path.
    # Avoid traversing unrelated browser accessibility trees.
    return "firefox" in application.lower()


def candidate_score(node, depth):
    name = safe_name(node)
    role = safe_role(node)
    lower = name.lower()
    text, caret = text_snapshot(node)

    score = depth
    if role in {"text", "entry", "paragraph"}:
        score += 100
    if role in {"text", "paragraph"}:
        score += 45
    if state(node, pyatspi.STATE_EDITABLE):
        score += 120
    if state(node, pyatspi.STATE_FOCUSABLE):
        score += 20

    positive = (
        "message",
        "prompt",
        "ask",
        "chatgpt",
        "сообщ",
        "спрос",
        "напиш",
        "что у вас",
    )
    negative = (
        "address",
        "location",
        "search bar",
        "find in page",
        "адрес",
        "поиск в",
        "search with",
    )
    if any(term in lower for term in positive):
        score += 90
    if any(term in lower for term in negative):
        score -= 250

    # The ChatGPT composer is usually empty or short. Browser chrome entries
    # commonly contain a long URL, so this is a useful mechanical tie-breaker.
    if len(text) <= 8:
        score += 25
    elif len(text) > 120:
        score -= 25

    return score, text, caret


def latest_response_text(nodes):
    starts = [
        index
        for index, (node, _depth) in enumerate(nodes)
        if safe_role(node) == "heading"
        and safe_name(node).strip().lower() == "chatgpt said:"
    ]
    if not starts:
        return ""
    parts = []
    for node, _depth in nodes[starts[-1] + 1:]:
        if safe_role(node) == "heading" and safe_name(node).strip().lower() in {
            "you said:",
            "chatgpt said:",
        }:
            break
        if safe_role(node) != "paragraph":
            continue
        text, _caret = text_snapshot(node)
        value = text.replace("\ufffc", "").strip()
        if value:
            parts.append(value)
    return "\n".join(parts).strip()


STOP_LABELS = (
    "stop answering",
    "stop generating",
    "остановить ответ",
    "остановить создание",
)


def result_payload(
    *, score, application, window, name, role, text, caret,
    window_node, document, composer, nodes,
):
    try:
        focused = bool(composer.queryComponent().grabFocus())
    except Exception:
        focused = False
    if focused:
        time.sleep(0.15)
    control_focused = state(composer, pyatspi.STATE_FOCUSED)
    if focused:
        try:
            iface = composer.queryText()
            iface.setCaretOffset(int(iface.characterCount))
        except Exception:
            pass
    busy = any(
        any(label in safe_name(node).strip().lower() for label in STOP_LABELS)
        for node, _depth in nodes
    )
    return {
        "ok": True,
        "application": application,
        "window": window,
        "name": name,
        "role": role,
        "text": text,
        "caret_offset": caret,
        "score": score,
        "window_active": state(window_node, pyatspi.STATE_ACTIVE),
        "control_focused": control_focused,
        "document_showing": state(document, pyatspi.STATE_SHOWING),
        "busy": busy,
        "latest_response_text": latest_response_text(nodes),
        "reason": "" if focused else "grabFocus returned false",
    }


expected_application = sys.argv[1] if len(sys.argv) > 2 else ""
expected_window = sys.argv[2] if len(sys.argv) > 2 else ""
expected_name = sys.argv[3] if len(sys.argv) > 4 else ""
expected_role = sys.argv[4] if len(sys.argv) > 4 else ""
cache = globals().get("_HEIWA_ATSPI_CACHE", {})
cached = cache.get("composer") if expected_name and expected_role else None
if cached is not None:
    try:
        (
            cached_application, cached_window_name, cached_name, cached_role,
            cached_window, cached_document, cached_composer,
        ) = cached
        valid = (
            cached_application == expected_application
            and cached_window_name == expected_window
            and cached_name == expected_name
            and cached_role == expected_role
            and safe_name(cached_window) == expected_window
            and safe_name(cached_composer) == expected_name
            and safe_role(cached_composer) == expected_role
            and state(cached_document, pyatspi.STATE_SHOWING)
            and state(cached_composer, pyatspi.STATE_EDITABLE)
        )
    except Exception:
        valid = False
    if valid:
        nodes = []
        stack = [(cached_document, 0)]
        while stack:
            cached_node, cached_depth = stack.pop()
            nodes.append((cached_node, cached_depth))
            stack.extend(
                (child, cached_depth + 1)
                for child in reversed(children(cached_node))
            )
        payload = result_payload(
            score=1000,
            application=cached_application,
            window=cached_window_name,
            name=cached_name,
            role=cached_role,
            text=text_snapshot(cached_composer)[0],
            caret=text_snapshot(cached_composer)[1],
            window_node=cached_window,
            document=cached_document,
            composer=cached_composer,
            nodes=nodes,
        )
        payload["cache_hit"] = True
        print(json.dumps(payload, ensure_ascii=False))
        raise SystemExit(0)
    cache.pop("composer", None)


desktop = pyatspi.Registry.getDesktop(0)
candidates = []

for app_index in range(desktop.childCount):
    try:
        app = desktop.getChildAtIndex(app_index)
    except Exception:
        continue
    if app is None:
        continue

    app_name = safe_name(app)
    if not is_browser_application(app_name):
        continue
    if expected_application and app_name != expected_application:
        continue
    for window in children(app):
        if expected_window and safe_name(window) != expected_window:
            continue
        # Find document roots without descending through each web document.
        # The old code walked the entire Firefox DOM here and then walked the
        # same document again below, which can exceed the 5 s AT-SPI timeout.
        documents = []
        stack = [(window, 0)]
        while stack:
            node, depth = stack.pop()
            if safe_role(node) == "document web":
                documents.append(node)
                continue
            stack.extend((child, depth + 1) for child in children(node))

        for document in documents:
            # activate_composer() switches to ChatGPT before this query.  Only
            # inspect the selected/showing web document; hidden tabs may have
            # very large accessibility trees and are irrelevant here.
            document_showing = state(document, pyatspi.STATE_SHOWING)
            if not document_showing:
                continue

            stack = [(document, 0)]
            nodes = []
            while stack:
                node, depth = stack.pop()
                nodes.append((node, depth))
                stack.extend(
                    (child, depth + 1) for child in reversed(children(node))
                )

            if not is_chatgpt_document(document, nodes):
                continue

            for node, depth in nodes:
                if not state(node, pyatspi.STATE_EDITABLE):
                    continue
                if expected_name and safe_name(node) != expected_name:
                    continue
                if expected_role and safe_role(node) != expected_role:
                    continue
                score, text, caret = candidate_score(node, depth)
                candidates.append(
                    (
                        score,
                        app_name,
                        safe_name(window),
                        safe_name(node),
                        safe_role(node),
                        text,
                        caret,
                        state(window, pyatspi.STATE_ACTIVE),
                        document_showing,
                        window,
                        document,
                        nodes,
                        node,
                    )
                )

if not candidates:
    print(json.dumps({"ok": False, "reason": "no ChatGPT editable candidate"}))
    raise SystemExit(0)

candidates.sort(key=lambda item: item[0], reverse=True)
(
    score,
    application,
    window_name,
    name,
    role,
    text,
    caret,
    window_active,
    document_showing,
    window_node,
    document_node,
    document_nodes,
    node,
) = candidates[0]
cache["composer"] = (
    application, window_name, name, role, window_node, document_node, node,
)
payload = result_payload(
    score=score,
    application=application,
    window=window_name,
    name=name,
    role=role,
    text=text,
    caret=caret,
    window_node=window_node,
    document=document_node,
    composer=node,
    nodes=document_nodes,
)
payload["cache_hit"] = False
print(json.dumps(payload, ensure_ascii=False))
'''


_FIND_TEXT = r'''
import json
import sys
import pyatspi

needle = sys.argv[1]


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def children(node):
    try:
        count = int(getattr(node, "childCount", 0))
    except Exception:
        return []
    result = []
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def text_snapshot(node):
    try:
        iface = node.queryText()
        count = int(iface.characterCount)
        return iface.getText(0, count)
    except Exception:
        return ""


def state(node, value):
    try:
        return bool(node.getState().contains(value))
    except Exception:
        return False


def is_chatgpt_document(document, nodes):
    title = safe_name(document).lower()
    if "chatgpt" in title or "openai" in title:
        return True
    for node in nodes:
        name = safe_name(node).lower()
        if name in {"chatgpt", "openai"} or "chatgpt" in name:
            return True
    return False


def is_browser_application(application):
    lower = application.lower()
    return any(
        marker in lower
        for marker in ("firefox", "chrome", "chromium", "brave")
    )


desktop = pyatspi.Registry.getDesktop(0)
result = None

for app_index in range(desktop.childCount):
    try:
        app = desktop.getChildAtIndex(app_index)
    except Exception:
        continue
    if app is None:
        continue

    app_name = safe_name(app)
    if not is_browser_application(app_name):
        continue
    for window in children(app):
        stack = [window]
        documents = []
        while stack:
            node = stack.pop()
            if safe_role(node) == "document web":
                documents.append(node)
                continue
            stack.extend(children(node))
        for document in documents:
            if not state(document, pyatspi.STATE_SHOWING):
                continue
            stack = [document]
            nodes = []
            while stack:
                node = stack.pop()
                nodes.append(node)
                stack.extend(children(node))

            if not is_chatgpt_document(document, nodes):
                continue

            for node in nodes:
                text = text_snapshot(node)
                name = safe_name(node)
                combined = text if text else name
                if needle in combined:
                    result = {
                        "application": app_name,
                        "window": safe_name(window),
                        "name": name,
                        "role": safe_role(node),
                        "text": combined,
                    }
                    break

            if result is not None:
                break

        if result is not None:
            break
    if result is not None:
        break

print(json.dumps(result, ensure_ascii=False))
'''


_CHATGPT_BUSY = r'''
import json
import sys
import pyatspi

expected_window = sys.argv[1] if len(sys.argv) > 1 else ""


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def state(node, value):
    try:
        return bool(node.getState().contains(value))
    except Exception:
        return False


def children(node):
    result = []
    try:
        count = int(node.childCount)
    except Exception:
        return result
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def document_roots(window):
    result = []
    stack = [window]
    while stack:
        node = stack.pop()
        if safe_role(node) == "document web":
            result.append(node)
            continue
        stack.extend(children(node))
    return result


STOP_LABELS = (
    "stop answering",
    "stop generating",
    "остановить ответ",
    "остановить создание",
)

desktop = pyatspi.Registry.getDesktop(0)
result = {"busy": False}
for app_index in range(desktop.childCount):
    try:
        app = desktop.getChildAtIndex(app_index)
    except Exception:
        continue
    app_name = safe_name(app)
    if "firefox" not in app_name.lower():
        continue
    for window in children(app):
        if expected_window and safe_name(window) != expected_window:
            continue
        for document in document_roots(window):
            if not state(document, pyatspi.STATE_SHOWING):
                continue
            stack = [document]
            while stack:
                node = stack.pop()
                name = safe_name(node).strip().lower()
                if any(label in name for label in STOP_LABELS):
                    result = {
                        "busy": True,
                        "application": app_name,
                        "window": safe_name(window),
                        "control": safe_name(node),
                    }
                    break
                stack.extend(children(node))
            if result.get("busy"):
                break
        if result.get("busy"):
            break
    if result.get("busy"):
        break

print(json.dumps(result, ensure_ascii=False))
'''

_LATEST_CHATGPT_RESPONSE = r'''
import json
import sys
import pyatspi

expected_window = sys.argv[1] if len(sys.argv) > 1 else ""


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def state(node, value):
    try:
        return bool(node.getState().contains(value))
    except Exception:
        return False


def children(node):
    result = []
    try:
        count = int(node.childCount)
    except Exception:
        return result
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def document_roots(window):
    # Locate web-document roots without descending into their DOM.
    result = []
    stack = [window]
    while stack:
        node = stack.pop()
        if safe_role(node) == "document web":
            result.append(node)
            continue
        stack.extend(children(node))
    return result


def descendants_in_order(root):
    result = []
    stack = [root]
    while stack:
        node = stack.pop()
        result.append(node)
        stack.extend(reversed(children(node)))
    return result


def text_snapshot(node):
    try:
        iface = node.queryText()
        return iface.getText(0, int(iface.characterCount)).replace("\ufffc", "").strip()
    except Exception:
        return ""


def looks_like_chatgpt(document, nodes):
    title = safe_name(document).lower()
    if "chatgpt" in title or "openai" in title:
        return True
    return any(safe_name(node).lower() == "chat with chatgpt" for node in nodes)


desktop = pyatspi.Registry.getDesktop(0)
result = None
for app_index in range(desktop.childCount):
    try:
        app = desktop.getChildAtIndex(app_index)
    except Exception:
        continue
    app_name = safe_name(app)
    lower_app = app_name.lower()
    if not any(marker in lower_app for marker in ("firefox", "chrome", "chromium", "brave")):
        continue

    for window in children(app):
        if expected_window and safe_name(window) != expected_window:
            continue
        for document in document_roots(window):
            if not state(document, pyatspi.STATE_SHOWING):
                continue

            # Traverse only the visible exact document, once, preserving UI order.
            nodes = descendants_in_order(document)
            if not any(safe_name(node).lower() == "chat with chatgpt" for node in nodes):
                continue

            starts = [
                index
                for index, node in enumerate(nodes)
                if safe_role(node) == "heading"
                and safe_name(node).strip().lower() == "chatgpt said:"
            ]
            if not starts:
                continue
            start = starts[-1]
            parts = []
            for node in nodes[start + 1:]:
                if safe_role(node) == "heading" and safe_name(node).strip().lower() in {
                    "you said:",
                    "chatgpt said:",
                }:
                    break
                if safe_role(node) != "paragraph":
                    continue
                text = text_snapshot(node)
                if text:
                    parts.append(text)
            response = "\n".join(parts).strip()
            if response:
                result = {
                    "application": app_name,
                    "window": safe_name(document),
                    "name": "ChatGPT said:",
                    "role": "paragraph",
                    "text": response,
                }
            break
        if result is not None:
            break
    if result is not None:
        break

print(json.dumps(result, ensure_ascii=False))
'''


_VERIFY_EXACT_COMPOSER_TEXT = r'''
import json
import sys
import pyatspi

expected = sys.argv[1]


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def state(node, value):
    try:
        return bool(node.getState().contains(value))
    except Exception:
        return False


def children(node):
    try:
        count = int(node.childCount)
    except Exception:
        return []
    result = []
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def text_snapshot(node):
    try:
        iface = node.queryText()
        return iface.getText(0, int(iface.characterCount)).replace("\ufffc", "")
    except Exception:
        return ""


def canonical(value):
    value = (
        value.replace("\ufffc", "")
        .replace("\r\n", "\n")
        .replace("\r", "\n")
        .replace("\u00a0", " " )
        .replace("\u200b", "")
        .replace("\ufeff", "")
    )
    return "".join(value.split())


def collect_candidates(composer):
    values = []
    direct = text_snapshot(composer)
    if direct:
        values.append(direct)
    parts = []
    stack = list(reversed(children(composer)))
    while stack:
        node = stack.pop()
        value = text_snapshot(node)
        if value:
            parts.append(value)
        stack.extend(reversed(children(node)))
    if parts:
        values.append("".join(parts))
        values.append("\n".join(parts))
    result = []
    for value in values:
        if value not in result:
            result.append(value)
    return result


def same_message(actual, wanted):
    return actual == wanted or canonical(actual) == canonical(wanted)


cache = globals().get("_HEIWA_ATSPI_CACHE", {})
cached = cache.get("composer")
result = {
    "verified": False,
    "actual": "",
    "window_active": False,
    "document_showing": False,
    "control_focused": False,
    "reason": "exact composer cache unavailable",
}
if cached is not None:
    (
        application, window_name, composer_name, composer_role,
        window, document, cached_composer,
    ) = cached
    window_active = state(window, pyatspi.STATE_ACTIVE)
    document_showing = state(document, pyatspi.STATE_SHOWING)
    exact_window = (
        "firefox" in application.lower()
        and safe_name(window) == window_name
        and window_active
        and document_showing
    )

    composer = None
    identity_valid = (
        exact_window
        and safe_name(cached_composer) == composer_name
        and safe_role(cached_composer) == composer_role
        and state(cached_composer, pyatspi.STATE_EDITABLE)
    )
    if identity_valid:
        composer = cached_composer
    elif exact_window:
        stack = [document]
        fallback = []
        while stack:
            node = stack.pop()
            if state(node, pyatspi.STATE_EDITABLE) and state(node, pyatspi.STATE_SHOWING):
                role_match = safe_role(node) == composer_role
                name_match = safe_name(node) == composer_name
                if role_match and name_match:
                    if state(node, pyatspi.STATE_FOCUSED):
                        composer = node
                        break
                    fallback.append(node)
            stack.extend(reversed(children(node)))
        if composer is None and len(fallback) == 1:
            composer = fallback[0]

    candidates = collect_candidates(composer) if composer is not None else []
    match = next((value for value in candidates if same_message(value, expected)), None)
    control_focused = bool(
        composer is not None and state(composer, pyatspi.STATE_FOCUSED)
    )
    verified = bool(
        exact_window
        and composer is not None
        and control_focused
        and match is not None
    )
    actual = match if match is not None else (max(candidates, key=len) if candidates else "")
    result = {
        "verified": verified,
        "actual": actual,
        "window_active": window_active,
        "document_showing": document_showing,
        "control_focused": control_focused,
        "reason": "" if verified else (
            "composer text mismatch" if composer is not None
            else "current exact composer not observable"
        ),
    }

print(json.dumps(result, ensure_ascii=False))
'''


_OBSERVE_EXACT_COMPOSER_SUBMISSION = r'''
import json
import sys
import pyatspi

expected = sys.argv[1]
baseline_user_count = int(sys.argv[2]) if len(sys.argv) > 2 else -1


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def state(node, value):
    try:
        return bool(node.getState().contains(value))
    except Exception:
        return False


def children(node):
    try:
        count = int(node.childCount)
    except Exception:
        return []
    result = []
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def text_snapshot(node):
    try:
        iface = node.queryText()
        return iface.getText(0, int(iface.characterCount)).replace("\ufffc", "")
    except Exception:
        return ""


def canonical(value):
    value = (
        value.replace("\ufffc", "")
        .replace("\r\n", "\n")
        .replace("\r", "\n")
        .replace("\u00a0", " ")
        .replace("\u200b", "")
        .replace("\ufeff", "")
    )
    return "".join(value.split())


cache = globals().get("_HEIWA_ATSPI_CACHE", {})
cached = cache.get("composer")
result = {
    "completed": False,
    "composer_cleared": False,
    "content_matches_expected": False,
    "safe_for_fallback": False,
    "user_message_count": 0,
    "message_observed": False,
    "assistant_busy": False,
    "external_expected_observed": False,
    "reason": "exact composer cache unavailable",
}
if cached is not None:
    (
        application, window_name, composer_name, composer_role,
        window, document, _cached_composer,
    ) = cached
    window_active = state(window, pyatspi.STATE_ACTIVE)
    document_showing = state(document, pyatspi.STATE_SHOWING)
    exact_window = (
        "firefox" in application.lower()
        and safe_name(window) == window_name
        and window_active
        and document_showing
    )

    current = None
    nodes = []
    if exact_window:
        stack = [document]
        while stack:
            node = stack.pop()
            nodes.append(node)
            if (
                current is None
                and safe_name(node) == composer_name
                and safe_role(node) == composer_role
                and state(node, pyatspi.STATE_SHOWING)
            ):
                current = node
            stack.extend(reversed(children(node)))

    user_labels = {"you said:", "you said", "вы сказали:", "вы сказали"}
    user_message_count = sum(
        1
        for node in nodes
        if safe_name(node).strip().casefold() in user_labels
    )
    heading_delta = (
        baseline_user_count >= 0
        and user_message_count > baseline_user_count
    )

    stop_labels = (
        "stop answering",
        "stop generating",
        "остановить ответ",
        "остановить создание",
    )
    assistant_busy = any(
        any(label in safe_name(node).strip().casefold() for label in stop_labels)
        for node in nodes
    )

    # Firefox can remount the contenteditable immediately after a successful
    # Enter.  Observe the submitted payload outside the composer as a second
    # independent completion signal.
    composer_node_ids = set()
    candidates = []
    if current is not None:
        composer_node_ids.add(id(current))
        direct = text_snapshot(current)
        if direct:
            candidates.append(direct)
        parts = []
        stack = list(reversed(children(current)))
        while stack:
            node = stack.pop()
            composer_node_ids.add(id(node))
            value = text_snapshot(node)
            if value:
                parts.append(value)
            stack.extend(reversed(children(node)))
        combined = "".join(parts)
        if combined:
            candidates.append(combined)

    expected_canonical = canonical(expected)
    external_expected_observed = False
    if expected_canonical:
        for node in nodes:
            if id(node) in composer_node_ids:
                continue
            value = text_snapshot(node)
            if not value:
                continue
            value_canonical = canonical(value)
            if value_canonical == expected_canonical:
                external_expected_observed = True
                break
            if (
                len(value_canonical) <= len(expected_canonical) + 256
                and expected_canonical in value_canonical
            ):
                external_expected_observed = True
                break

    content_matches_expected = any(
        value == expected or canonical(value) == expected_canonical
        for value in candidates
    )
    composer_cleared = (
        current is not None
        and not any(value.strip() for value in candidates)
    )

    message_observed = heading_delta or external_expected_observed
    # The caller reaches this path only after ChatGPT was observed idle and the
    # exact composer content was verified.  A newly visible Stop control is
    # therefore also strong evidence that ChatGPT accepted the request.
    completed = composer_cleared or message_observed or assistant_busy
    safe_for_fallback = (
        exact_window
        and not completed
        and current is not None
        and content_matches_expected
    )
    if completed:
        reason = ""
    elif current is None:
        reason = "exact current composer not observable and no submission evidence observed"
    else:
        reason = "composer still contains draft and no submission evidence observed"
    result = {
        "completed": completed,
        "composer_cleared": composer_cleared,
        "content_matches_expected": content_matches_expected,
        "safe_for_fallback": safe_for_fallback,
        "user_message_count": user_message_count,
        "message_observed": message_observed,
        "assistant_busy": assistant_busy,
        "external_expected_observed": external_expected_observed,
        "reason": reason,
    }

print(json.dumps(result, ensure_ascii=False))
'''

_SET_FOCUSED_COMPOSER_TEXT = r'''
import json
import sys
import pyatspi

value = sys.argv[1]


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def state(node, value):
    try:
        return bool(node.getState().contains(value))
    except Exception:
        return False


def children(node):
    try:
        count = int(getattr(node, "childCount", 0))
    except Exception:
        return []
    result = []
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def text_snapshot(node):
    try:
        iface = node.queryText()
        count = int(iface.characterCount)
        return iface.getText(0, count)
    except Exception:
        return ""


def is_chatgpt_window(window, nodes):
    title = safe_name(window).lower()
    if "chatgpt" in title or "openai" in title:
        return True
    for node in nodes:
        name = safe_name(node).lower()
        if name in {"chatgpt", "openai"} or "chatgpt" in name:
            return True
    return False


def is_browser_application(application):
    lower = application.lower()
    return any(
        marker in lower
        for marker in ("firefox", "chrome", "chromium", "brave")
    )


def normalized_composer_text(text):
    return text.replace("\ufffc", "")


def score(node, depth):
    value = depth
    role = safe_role(node)
    name = safe_name(node).lower()
    if state(node, pyatspi.STATE_FOCUSED):
        value += 1000
    if state(node, pyatspi.STATE_EDITABLE):
        value += 200
    if role in {"text", "entry", "paragraph"}:
        value += 100
    if any(term in name for term in ("message", "prompt", "сообщ", "спрос", "напиш")):
        value += 100
    return value


desktop = pyatspi.Registry.getDesktop(0)
candidates = []
for app_index in range(desktop.childCount):
    try:
        app = desktop.getChildAtIndex(app_index)
    except Exception:
        continue
    if app is None:
        continue
    app_name = safe_name(app)
    if not is_browser_application(app_name):
        continue
    for window in children(app):
        stack = [(window, 0)]
        nodes = []
        while stack:
            node, depth = stack.pop()
            nodes.append(node)
            stack.extend((child, depth + 1) for child in children(node))
        if not is_chatgpt_window(window, nodes):
            continue
        for node in nodes:
            if not state(node, pyatspi.STATE_EDITABLE):
                continue
            candidates.append((score(node, 0), node))

if not candidates:
    print(json.dumps({"ok": False, "reason": "no ChatGPT editable candidate"}, ensure_ascii=False))
    raise SystemExit(0)

candidates.sort(key=lambda item: item[0], reverse=True)
node = candidates[0][1]
current = text_snapshot(node)
if normalized_composer_text(current).strip():
    print(json.dumps({"ok": False, "reason": "composer not empty", "text": current}, ensure_ascii=False))
    raise SystemExit(0)

try:
    node.queryComponent().grabFocus()
except Exception:
    pass

try:
    editable = node.queryEditableText()
    editable.setTextContents(value)
except Exception as exc:
    print(json.dumps({"ok": False, "reason": "EditableText failed: " + repr(exc)}, ensure_ascii=False))
    raise SystemExit(0)

observed = normalized_composer_text(text_snapshot(node))
print(json.dumps({"ok": observed == value, "text": observed, "reason": "" if observed == value else "verification mismatch"}, ensure_ascii=False))
'''


_TEMPORARY_CLIPBOARD_OWNER = r'''
import sys
import gi

gi.require_version("Gdk", "3.0")
gi.require_version("Gtk", "3.0")
from gi.repository import Gdk, GLib, Gtk

value = sys.argv[1]
clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
previous = clipboard.wait_for_text()
clipboard.set_text(value, -1)

_restored = False
_ready = False


def announce_ready():
    # READY must mean the GTK main loop is already running and can service
    # Wayland clipboard requests.  Emitting it before Gtk.main() creates a
    # race where the parent may press Ctrl+V while the old owner is still
    # effectively serving the selection.
    global _ready
    if _ready:
        return False
    _ready = True
    print("READY", flush=True)
    return False


def restore():
    global _restored
    if _restored:
        return False
    _restored = True
    if previous is None:
        clipboard.clear()
    else:
        clipboard.set_text(previous, -1)
        clipboard.store()
    Gtk.main_quit()
    return False


def release(_source, _condition):
    # Parent sends one line only after Ctrl+V and Send have completed.  If the
    # parent dies, EOF/HUP also releases and restores the user's clipboard.
    try:
        sys.stdin.readline()
    except Exception:
        pass
    GLib.idle_add(restore)
    return False


GLib.io_add_watch(sys.stdin, GLib.IO_IN | GLib.IO_HUP, release)
GLib.idle_add(announce_ready)
# Last-resort cleanup only; normal lifetime is controlled by the parent.
GLib.timeout_add_seconds(60, restore)
Gtk.main()
'''


_READ_CLIPBOARD_TEXT = r'''
import json
import gi

gi.require_version("Gdk", "3.0")
gi.require_version("Gtk", "3.0")
from gi.repository import Gdk, Gtk

clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
print(json.dumps(clipboard.wait_for_text(), ensure_ascii=False))
'''


class _KeyboardLayoutGuard:
    """Temporarily select the real GNOME/Wayland US input source."""

    def __init__(self, *, socket_path: str) -> None:
        self._socket_path = socket_path
        self._previous_engine: str | None = None

    def __enter__(self) -> "_KeyboardLayoutGuard":
        self._previous_engine = self._current_engine()
        self._select_engine("xkb:us::eng")
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        if self._previous_engine is None:
            return
        try:
            self._select_engine(self._previous_engine)
        except Exception:
            pass

    @staticmethod
    def _current_engine() -> str:
        ibus = _which("ibus")
        if ibus is None:
            raise ChatGPTDesktopError("ibus is not installed")
        result = subprocess.run(
            (ibus, "engine"),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=2.0,
        )
        if result.returncode != 0:
            raise ChatGPTDesktopError(
                "could not query active input engine: "
                + (result.stderr.strip() or f"returncode={result.returncode}")
            )
        return result.stdout.strip()

    def _select_engine(self, target: str) -> None:
        for _ in range(8):
            if self._current_engine() == target:
                return
            self._advance_engine()
        raise ChatGPTDesktopError(f"could not select input engine: {target}")

    def _advance_engine(self) -> None:
        ydotool = _which("ydotool")
        if ydotool is None:
            raise ChatGPTDesktopError("ydotool is not installed")
        env = os.environ.copy()
        env["YDOTOOL_SOCKET"] = self._socket_path
        result = subprocess.run(
            (ydotool, "key", "125:1", "57:1", "57:0", "125:0"),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
            timeout=3.0,
        )
        if result.returncode != 0:
            raise ChatGPTDesktopError(
                "could not switch input engine: "
                + (result.stderr.strip() or f"returncode={result.returncode}")
            )
        self._close_gnome_overview()
        time.sleep(0.4)

    @staticmethod
    def _close_gnome_overview() -> None:
        gdbus = _which("gdbus")
        if gdbus is None:
            return
        subprocess.run(
            (
                gdbus,
                "call",
                "--session",
                "--dest",
                "org.gnome.Shell",
                "--object-path",
                "/org/gnome/Shell",
                "--method",
                "org.freedesktop.DBus.Properties.Set",
                "org.gnome.Shell",
                "OverviewActive",
                "<false>",
            ),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=2.0,
        )


def _which(name: str) -> str | None:
    from shutil import which

    return which(name)


class ChatGPTDesktopBootstrap:
    """
    Mechanical bootstrap bridge to the visible ChatGPT web UI.

    This helper does not decide when to ask ChatGPT or what Heiwa should say.
    It only focuses the visible composer, types already-selected text, submits
    it, and observes visible reply text through AT-SPI.
    """

    def __init__(
        self,
        *,
        motor: DesktopMotor | None = None,
        system_python: str = SYSTEM_PYTHON,
        query_timeout: float = 10.0,
        diagnostics: bool = True,
    ) -> bool:
        if query_timeout <= 0:
            raise ValueError("query_timeout must be > 0")
        self.motor = motor or DesktopMotor(timeout=30.0)
        self.system_python = system_python
        self.query_timeout = query_timeout
        self.diagnostics = diagnostics
        self._atspi = _PersistentFirefoxATSPI(timeout=query_timeout)
        self._composer_hint: tuple[str, str, str, str] | None = None
        self._last_busy: bool | None = None
        self._last_pre_send_response: ChatGPTTextMatch | None = None
        self.last_send_timing = DesktopSendTiming()

    def close(self) -> None:
        self._atspi.close()

    def _diag(self, event: str, **fields: object) -> None:
        if not self.diagnostics:
            return
        payload = {"event": event, **fields}
        print(
            "CHATGPT_DIAG "
            + json.dumps(payload, ensure_ascii=False, sort_keys=True),
            flush=True,
        )

    def focus_composer(self) -> ChatGPTComposer:
        arguments: tuple[str, ...] = self._composer_hint or ()
        payload = self._run_atspi(
            _FIND_AND_FOCUS_COMPOSER,
            *arguments,
            operation="focus_composer",
        )
        if (
            arguments
            and (not isinstance(payload, dict) or not payload.get("ok"))
        ):
            # A cached accessible node is only a hint. Rediscover within the
            # exact already-selected Firefox window, never another ChatGPT tab.
            self._diag("composer_cache.invalidated", window=arguments[1])
            self._composer_hint = None
            payload = self._run_atspi(
                _FIND_AND_FOCUS_COMPOSER,
                arguments[0],
                arguments[1],
                operation="focus_composer_fallback",
            )
        if not isinstance(payload, dict) or not payload.get("ok"):
            reason = payload.get("reason") if isinstance(payload, dict) else "invalid result"
            raise ChatGPTDesktopError(f"could not focus ChatGPT composer: {reason}")

        raw_caret = payload.get("caret_offset")
        caret = raw_caret if isinstance(raw_caret, int) else None
        composer = ChatGPTComposer(
            application=str(payload.get("application", "")),
            window=str(payload.get("window", "")),
            name=str(payload.get("name", "")),
            role=str(payload.get("role", "")),
            text=str(payload.get("text", "")),
            caret_offset=caret,
            score=int(payload.get("score", 0)),
            window_active=bool(payload.get("window_active", False)),
            control_focused=bool(payload.get("control_focused", False)),
            document_showing=bool(payload.get("document_showing", False)),
        )
        if "firefox" not in composer.application.lower():
            raise ChatGPTDesktopError("resolved composer is not in Firefox")
        self._composer_hint = (
            composer.application,
            composer.window,
            composer.name,
            composer.role,
        )
        self._last_busy = bool(payload.get("busy", False))
        latest = str(payload.get("latest_response_text", "")).strip()
        self._last_pre_send_response = (
            ChatGPTTextMatch(
                application=composer.application,
                window=composer.window,
                name="ChatGPT said:",
                role="paragraph",
                text=latest,
            )
            if latest
            else None
        )
        self._diag(
            "composer_state",
            application=composer.application,
            window=composer.window,
            role=composer.role,
            name=composer.name,
            score=composer.score,
            window_active=composer.window_active,
            document_showing=composer.document_showing,
            control_focused=composer.control_focused,
            has_draft=composer.has_draft,
            text_chars=len(composer.text.replace("\ufffc", "")),
        )
        return composer

    def activate_composer(self) -> ChatGPTComposer:
        # Sending is an explicit Desktop action. Activate only the exact
        # Firefox frame that already contains the showing ChatGPT document;
        # never discover or switch to another tab.
        composer = self.focus_composer()
        for attempt in range(1, 4):
            if (
                composer.window_active
                and composer.document_showing
                and composer.control_focused
            ):
                self._diag("activate_composer.accepted", attempt=attempt)
                return composer

            if not composer.document_showing:
                break

            if not composer.window_active:
                self._activate_exact_firefox_window(composer.window, attempt=attempt)

            time.sleep(0.15)
            composer = self.focus_composer()

        failed = [
            name
            for name, value in (
                ("window_active", composer.window_active),
                ("document_showing", composer.document_showing),
                ("control_focused", composer.control_focused),
            )
            if not value
        ]
        self._diag("activate_composer.rejected", failed=failed)
        raise ChatGPTDesktopError(
            "ChatGPT composer activation invariant failed: "
            + ",".join(failed)
            + "; exact visible Firefox window activation failed"
        )

    def _activate_exact_firefox_window(
        self,
        window: str,
        *,
        attempt: int,
    ) -> None:
        payload = self._run_atspi(
            _ACTIVATE_EXACT_FIREFOX_WINDOW,
            window,
            operation="activate_exact_firefox_window",
        )
        if not isinstance(payload, dict):
            raise ChatGPTDesktopError(
                "exact Firefox window activation returned invalid result"
            )
        self._diag(
            "activate_exact_firefox_window.result",
            attempt=attempt,
            window=window,
            ok=bool(payload.get("ok")),
            mechanism=str(payload.get("mechanism", "")),
            window_active=bool(payload.get("window_active", False)),
            reason=str(payload.get("reason", "")),
        )
        return bool(payload.get("ok"))

    def _switch_chatgpt_tab(self) -> None:
        payload = self._run_atspi(_SWITCH_CHATGPT_TAB, operation="switch_chatgpt_tab")
        if not isinstance(payload, dict) or not payload.get("ok"):
            reason = payload.get("reason") if isinstance(payload, dict) else "invalid result"
            raise ChatGPTDesktopError(f"could not switch to ChatGPT tab: {reason}")

    def _press_alt_tab(self) -> None:
        ydotool = _which("ydotool")
        if ydotool is None:
            raise ChatGPTDesktopError("ydotool is not installed")
        env = os.environ.copy()
        env["YDOTOOL_SOCKET"] = self.motor.socket_path
        result = subprocess.run(
            (ydotool, "key", "56:1", "15:1", "15:0", "56:0"),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
            timeout=self.motor.timeout,
        )
        if result.returncode != 0:
            raise ChatGPTDesktopError(
                "Alt+Tab activation failed: "
                + (result.stderr.strip() or f"returncode={result.returncode}")
            )
        time.sleep(0.4)

    def _press_ctrl_tab(self) -> None:
        ydotool = _which("ydotool")
        if ydotool is None:
            raise ChatGPTDesktopError("ydotool is not installed")
        env = os.environ.copy()
        env["YDOTOOL_SOCKET"] = self.motor.socket_path
        result = subprocess.run(
            (ydotool, "key", "29:1", "15:1", "15:0", "29:0"),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
            timeout=self.motor.timeout,
        )
        if result.returncode != 0:
            raise ChatGPTDesktopError(
                "Ctrl+Tab activation failed: "
                + (result.stderr.strip() or f"returncode={result.returncode}")
            )
        time.sleep(0.4)

    @staticmethod
    def _close_gnome_overview() -> None:
        gdbus = _which("gdbus")
        if gdbus is None:
            return
        subprocess.run(
            (
                gdbus,
                "call",
                "--session",
                "--dest",
                "org.gnome.Shell",
                "--object-path",
                "/org/gnome/Shell",
                "--method",
                "org.freedesktop.DBus.Properties.Set",
                "org.gnome.Shell",
                "OverviewActive",
                "<false>",
            ),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=2.0,
        )
        time.sleep(0.2)

    @property
    def last_pre_send_response(self) -> ChatGPTTextMatch | None:
        return self._last_pre_send_response

    def _activate_ready_composer(self) -> ChatGPTComposer:
        composer = self.activate_composer()
        if self._last_busy:
            self.wait_until_idle(timeout=300.0)
            composer = self.activate_composer()
        if composer.has_draft:
            raise ChatGPTDesktopError(
                "ChatGPT composer is not empty; refusing to overwrite an existing draft"
            )
        return composer

    def send_message(self, text: str) -> ChatGPTComposer:
        if self.diagnostics:
            print("HEIWA_SEND_TEXT:", repr(text), flush=True)
        if not isinstance(text, str) or not text:
            raise ValueError("bootstrap message must be a non-empty str")

        self._diag(
            "send_message.start",
            chars=len(text),
            ascii=text.isascii(),
        )
        if text.isascii():
            # Keep the already-proven physical keyboard path for ASCII.
            with _KeyboardLayoutGuard(socket_path=self.motor.socket_path):
                activate_started = time.monotonic()
                composer = self._activate_ready_composer()
                activate_ms = (time.monotonic() - activate_started) * 1000.0
                send_started = time.monotonic()
                self.motor.type_ascii(text)
                time.sleep(0.15)
                self._verify_composer_text(text)
                submission = self._submit_verified_message(text)
                paste_send_ms = (time.monotonic() - send_started) * 1000.0
            self.last_send_timing = DesktopSendTiming(
                activate_ms=activate_ms,
                paste_send_ms=paste_send_ms,
                keyboard_path="physical",
                composer_verified=True,
                send_path=submission.send_path,
                send_attempted=submission.send_attempted,
                send_completed=submission.send_completed,
                composer_cleared=submission.composer_cleared,
                send_ms=submission.send_ms,
            )
            return composer

        # ydotool's `type` path is layout/keycode-oriented. For arbitrary
        # UTF-8, temporarily own the Wayland clipboard, physically paste into
        # the already-focused visible composer, then submit with physical Enter.
        # Firefox exposes the contenteditable composer to AT-SPI as U+FFFC, so
        # the pasted draft cannot be verified reliably before submission.
        with _KeyboardLayoutGuard(socket_path=self.motor.socket_path):
            composer, activate_ms, paste_send_ms, submission = self._paste_unicode_text(text)
        self.last_send_timing = DesktopSendTiming(
            activate_ms=activate_ms,
            paste_send_ms=paste_send_ms,
            keyboard_path="unicode_fallback",
            composer_verified=True,
            send_path=submission.send_path,
            send_attempted=submission.send_attempted,
            send_completed=submission.send_completed,
            composer_cleared=submission.composer_cleared,
            send_ms=submission.send_ms,
        )
        return composer

    def wait_until_idle(
        self,
        *,
        timeout: float = 300.0,
        poll_interval: float = 1.0,
    ) -> None:
        deadline = time.monotonic() + timeout
        poll = 0
        while time.monotonic() < deadline:
            poll += 1
            poll_started = time.monotonic()
            self._diag("wait_idle.poll_start", poll=poll)

            # One AT-SPI traversal is enough to determine whether ChatGPT is
            # still generating. The old path focused the composer and then
            # scanned the same Firefox document up to four separate times per
            # poll, making an idle check take roughly 8-10 seconds.
            arguments = (self._composer_hint[1],) if self._composer_hint else ()
            payload = self._run_atspi(
                _CHATGPT_BUSY,
                *arguments,
                operation="chatgpt_busy",
            )
            if not isinstance(payload, dict):
                raise ChatGPTDesktopError("AT-SPI busy query returned invalid result")
            busy = bool(payload.get("busy"))
            matched_label = str(payload.get("control", "")) if busy else None

            self._diag(
                "wait_idle.poll_result",
                poll=poll,
                busy=busy,
                matched_label=matched_label,
                elapsed_ms=round((time.monotonic() - poll_started) * 1000.0, 1),
            )
            if not busy:
                return
            time.sleep(poll_interval)
        raise ChatGPTDesktopError(
            f"timed out after {timeout:.1f}s waiting for ChatGPT to become idle"
        )

    def _submit_verified_message(self, expected_text: str) -> _SubmissionResult:
        started = time.monotonic()
        send_path = "enter"
        attempted = False
        completed = False
        composer_cleared = False
        message_observed = False
        try:
            baseline = self._submission_snapshot(expected_text)
            baseline_user_count = baseline.user_message_count

            # A stale modifier or a tiny focus race after Ctrl+V can make a
            # perfectly valid Enter keypress do nothing.  Always normalize the
            # virtual keyboard state and re-focus the exact verified composer
            # immediately before the physical keypress.
            self.motor.release_modifiers()
            self.focus_composer()
            self._verify_composer_text(expected_text)

            attempted = True
            self.motor.key_press(KEY_ENTER)
            observation = self._observe_submission(
                expected_text,
                baseline_user_count=baseline_user_count,
            )
            completed = observation.completed
            composer_cleared = observation.composer_cleared
            message_observed = observation.message_observed
            if completed:
                return _SubmissionResult(
                    send_path=send_path,
                    send_attempted=attempted,
                    send_completed=True,
                    composer_cleared=composer_cleared,
                    send_ms=(time.monotonic() - started) * 1000.0,
                )

            # If the exact same draft is still present, Enter was not accepted.
            # One bounded re-focus/release/retry is safe because the observer
            # has verified that no new user message appeared and the draft has
            # not left the composer.
            if observation.safe_for_fallback:
                send_path = "enter_retry"
                self.motor.release_modifiers()
                self.focus_composer()
                self._verify_composer_text(expected_text)
                self.motor.key_press(KEY_ENTER)
                observation = self._observe_submission(
                    expected_text,
                    baseline_user_count=baseline_user_count,
                )
                completed = observation.completed
                composer_cleared = observation.composer_cleared
                message_observed = observation.message_observed
                if completed:
                    return _SubmissionResult(
                        send_path=send_path,
                        send_attempted=attempted,
                        send_completed=True,
                        composer_cleared=composer_cleared,
                        send_ms=(time.monotonic() - started) * 1000.0,
                    )

            if not observation.safe_for_fallback:
                raise ChatGPTDesktopError(
                    "physical Enter submission was not externally confirmed; "
                    "no new user message/composer-clear evidence and exact "
                    "composer is not safe for button fallback"
                )

            send_path = "button_fallback"
            self._click_send_button()
            observation = self._observe_submission(
                expected_text,
                baseline_user_count=baseline_user_count,
            )
            completed = observation.completed
            composer_cleared = observation.composer_cleared
            message_observed = observation.message_observed
            if not completed:
                raise ChatGPTDesktopError(
                    "ChatGPT submission was not externally confirmed after "
                    "two physical Enter attempts and bounded Send button fallback"
                )
            return _SubmissionResult(
                send_path=send_path,
                send_attempted=attempted,
                send_completed=True,
                composer_cleared=composer_cleared,
                send_ms=(time.monotonic() - started) * 1000.0,
            )
        finally:
            elapsed_ms = (time.monotonic() - started) * 1000.0
            print(
                f"send_path={send_path} "
                f"send_attempted={str(attempted).lower()} "
                f"send_completed={str(completed).lower()} "
                f"composer_cleared={str(composer_cleared).lower()} "
                f"message_observed={str(message_observed).lower()} "
                f"send_ms={elapsed_ms:.1f}",
                flush=True,
            )

    def _submission_snapshot(self, expected_text: str) -> _SubmissionObservation:
        payload = self._run_atspi(
            _OBSERVE_EXACT_COMPOSER_SUBMISSION,
            expected_text,
            "-1",
            operation="submission_snapshot",
        )
        if not isinstance(payload, dict):
            raise ChatGPTDesktopError(
                "ChatGPT submission snapshot returned invalid result"
            )
        return _SubmissionObservation(
            completed=False,
            composer_cleared=bool(payload.get("composer_cleared")),
            content_matches_expected=bool(payload.get("content_matches_expected")),
            safe_for_fallback=bool(payload.get("safe_for_fallback")),
            user_message_count=int(payload.get("user_message_count", 0)),
            message_observed=False,
        )

    def _observe_submission(
        self,
        expected_text: str,
        *,
        baseline_user_count: int,
        timeout: float = 4.0,
        poll_interval: float = 0.15,
    ) -> _SubmissionObservation:
        deadline = time.monotonic() + timeout
        latest = _SubmissionObservation(False, False, False, False, 0, False)
        while True:
            payload = self._run_atspi(
                _OBSERVE_EXACT_COMPOSER_SUBMISSION,
                expected_text,
                str(baseline_user_count),
                operation="observe_submission",
            )
            if not isinstance(payload, dict):
                raise ChatGPTDesktopError(
                    "ChatGPT submission observation returned invalid result"
                )
            latest = _SubmissionObservation(
                completed=bool(payload.get("completed")),
                composer_cleared=bool(payload.get("composer_cleared")),
                content_matches_expected=bool(
                    payload.get("content_matches_expected")
                ),
                safe_for_fallback=bool(payload.get("safe_for_fallback")),
                user_message_count=int(payload.get("user_message_count", 0)),
                message_observed=bool(payload.get("message_observed")),
            )
            if latest.completed or time.monotonic() >= deadline:
                return latest
            time.sleep(poll_interval)

    def _probe_composer_text(self, expected: str) -> tuple[bool, str]:
        payload = self._run_atspi(
            _VERIFY_EXACT_COMPOSER_TEXT,
            expected,
            operation="probe_composer_text",
        )
        if not isinstance(payload, dict):
            return False, ""
        return bool(payload.get("verified")), str(payload.get("actual", ""))

    @staticmethod
    def _is_heiwa_protocol_draft(text: str) -> bool:
        """True only for machine protocol drafts owned by Heiwa.

        Arbitrary human drafts must never be erased by automatic recovery.
        """

        normalized = (
            text.replace("\ufffc", "")
            .replace("\r\n", "\n")
            .replace("\r", "\n")
            .lstrip()
        )
        return (
            normalized.startswith("[HEIWA_")
            or "[HEIWA_LANGUAGE_" in normalized
            or "This is Heiwa Language network's own attempt" in normalized
        )

    def _clear_stale_heiwa_draft(self, stale_text: str) -> None:
        if not self._is_heiwa_protocol_draft(stale_text):
            raise ChatGPTDesktopError(
                "ChatGPT composer contains a non-Heiwa draft; refusing to overwrite it"
            )

        # Re-resolve and re-read immediately before destructive input. A stale
        # AT-SPI snapshot must never authorize deletion of a user's draft.
        self.motor.release_modifiers()
        self.focus_composer()
        _matches_expected, current = self._probe_composer_text(stale_text)
        if not self._is_heiwa_protocol_draft(current):
            raise ChatGPTDesktopError(
                "ChatGPT draft changed before stale-Heiwa cleanup; refusing to overwrite it"
            )

        self.motor.clear_focused_editable()
        time.sleep(0.15)
        _still_matches, remaining = self._probe_composer_text(stale_text)
        if remaining.strip():
            raise ChatGPTDesktopError(
                "stale Heiwa draft cleanup was not externally confirmed"
            )
        self._diag("composer.stale_heiwa_draft_cleared", chars=len(stale_text))

    def _verify_composer_text(self, expected: str) -> None:
        payload: object = None
        for attempt in range(1, 3):
            payload = self._run_atspi(
                _VERIFY_EXACT_COMPOSER_TEXT,
                expected,
                operation="verify_composer_text",
            )
            verified = bool(isinstance(payload, dict) and payload.get("verified"))
            self._diag(
                "composer_text.verify",
                attempt=attempt,
                verified=verified,
                expected_chars=len(expected),
                actual_chars=(
                    len(str(payload.get("actual", "")))
                    if isinstance(payload, dict)
                    else 0
                ),
            )
            if verified:
                return
            if attempt == 1:
                self.focus_composer()
                time.sleep(0.1)
        reason = payload.get("reason") if isinstance(payload, dict) else "invalid result"
        actual = str(payload.get("actual", "")) if isinstance(payload, dict) else ""
        raise ChatGPTDesktopError(
            "ChatGPT composer content verification failed: "
            f"{reason}; expected_chars={len(expected)} actual_chars={len(actual)}"
        )

    def _paste_unicode_text(
        self,
        text: str,
    ) -> tuple[ChatGPTComposer, float, float, _SubmissionResult]:
        # A failed previous submit may legitimately leave the exact draft in
        # ChatGPT.  On a runtime retry, resume submission instead of pasting
        # the same text a second time and corrupting the composer contents.
        resume_started = time.monotonic()
        resume_composer = self.activate_composer()
        if self._last_busy:
            self.wait_until_idle(timeout=300.0)
            resume_composer = self.activate_composer()
        draft_matches, observed_draft = self._probe_composer_text(text)
        if draft_matches:
            submission = self._submit_verified_message(text)
            return (
                resume_composer,
                (time.monotonic() - resume_started) * 1000.0,
                0.0,
                submission,
            )
        if observed_draft.strip():
            if (
                self._is_heiwa_protocol_draft(text)
                and self._is_heiwa_protocol_draft(observed_draft)
            ):
                # A failed previous developmental turn can leave an old Heiwa
                # protocol message in the dedicated composer. It is safe to
                # replace only another clearly machine-owned Heiwa draft.
                self._clear_stale_heiwa_draft(observed_draft)
                resume_composer = self.activate_composer()
            else:
                raise ChatGPTDesktopError(
                    "ChatGPT composer contains a different existing draft; "
                    "refusing to append or overwrite it"
                )

        wl_copy = _which("wl-copy")
        wl_paste = _which("wl-paste")
        if wl_copy is None or wl_paste is None:
            raise ChatGPTDesktopError(
                "wl-copy/wl-paste are required for Unicode paste on Wayland"
            )

        def read_clipboard() -> str | None:
            result = subprocess.run(
                (wl_paste, "--no-newline"),
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=3.0,
            )
            if result.returncode != 0:
                return None
            return result.stdout

        previous = read_clipboard()
        previous_available = previous is not None

        # wl-copy is a clipboard owner, not a short-lived command.  Keep it
        # alive explicitly while Firefox consumes Ctrl+V instead of waiting
        # for it with subprocess.run().
        owner = subprocess.Popen(
            (wl_copy, "--foreground"),
            stdin=subprocess.PIPE,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
        )
        if owner.stdin is None:
            owner.terminate()
            raise ChatGPTDesktopError("could not open stdin for wl-copy")
        try:
            owner.stdin.write(text)
            owner.stdin.close()
        except (BrokenPipeError, OSError) as exc:
            if owner.poll() is None:
                owner.terminate()
            raise ChatGPTDesktopError(
                f"could not set Wayland clipboard: {exc!r}"
            ) from exc

        try:
            observed = None
            for _ in range(10):
                observed = read_clipboard()
                if observed == text:
                    break
                time.sleep(0.05)
            if observed != text:
                self._diag(
                    "clipboard.verify_failed",
                    expected_chars=len(text),
                    observed_chars=len(observed) if isinstance(observed, str) else None,
                    backend="wl-clipboard",
                )
                raise ChatGPTDesktopError(
                    "Wayland clipboard verification failed; refusing Ctrl+V"
                )

            # Clipboard ownership may perturb Wayland focus. Resolve/activate
            # once here, immediately before paste, then freshly verify all
            # exact-window/composer invariants. Nothing physical is sent if it
            # fails. A cached node only avoids discovery; its state is reread.
            activate_started = time.monotonic()
            composer = self._activate_ready_composer()
            activate_ms = (time.monotonic() - activate_started) * 1000.0

            ydotool = _which("ydotool")
            if ydotool is None:
                raise ChatGPTDesktopError("ydotool is not installed")
            motor_env = os.environ.copy()
            motor_env["YDOTOOL_SOCKET"] = self.motor.socket_path
            if self.diagnostics:
                print("CLIPBOARD_SET_FOR_HEIWA: OK", flush=True)
            self._diag(
                "clipboard.ready",
                chars=len(text),
                verified=True,
                backend="wl-clipboard",
            )
            paste_started = time.monotonic()
            pasted = subprocess.run(
                (ydotool, "key", "29:1", "47:1", "47:0", "29:0"),
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=motor_env,
                timeout=self.motor.timeout,
            )
            self._diag(
                "clipboard.paste",
                returncode=pasted.returncode,
                elapsed_ms=round((time.monotonic() - paste_started) * 1000.0, 1),
                backend="wl-clipboard",
            )
            if pasted.returncode != 0:
                raise ChatGPTDesktopError(
                    "Unicode paste key failed: "
                    + (
                        pasted.stderr.strip()
                        or f"returncode={pasted.returncode}"
                    )
                )

            # Keep Heiwa's clipboard contents alive until Firefox has consumed
            # the paste and the message has been submitted.
            time.sleep(0.35)
            self._verify_composer_text(text)
            submission = self._submit_verified_message(text)
            paste_send_ms = (time.monotonic() - paste_started) * 1000.0
        finally:
            # Replacing the selection is enough to release the foreground
            # owner, but stop our process first so restoration is unambiguous.
            if owner.poll() is None:
                owner.terminate()
                try:
                    owner.wait(timeout=1.0)
                except subprocess.TimeoutExpired:
                    owner.kill()
                    owner.wait(timeout=1.0)

            if previous_available:
                # Default wl-copy daemonizes and remains the user's clipboard
                # owner.  DEVNULL is intentional: a daemon inheriting PIPEs
                # would keep subprocess.run().communicate() waiting for EOF.
                restored = subprocess.run(
                    (wl_copy,),
                    input=previous,
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    text=True,
                    timeout=3.0,
                )
            else:
                restored = subprocess.run(
                    (wl_copy, "--clear"),
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    text=True,
                    timeout=3.0,
                )
            self._diag(
                "clipboard.restore",
                returncode=restored.returncode,
                restored_previous=previous_available,
                backend="wl-clipboard",
            )
        return composer, activate_ms, paste_send_ms, submission

    def _click_send_button(self) -> None:
        arguments = (self._composer_hint[1],) if self._composer_hint else ()
        payload = self._run_atspi(
            _CLICK_CHATGPT_SEND,
            *arguments,
            operation="click_send",
        )
        if not isinstance(payload, dict) or not payload.get("ok"):
            reason = payload.get("reason") if isinstance(payload, dict) else "invalid result"
            buttons = payload.get("visible_buttons", []) if isinstance(payload, dict) else []
            suffix = f"; visible_buttons={buttons[:8]!r}" if buttons else ""
            raise ChatGPTDesktopError(
                f"could not submit ChatGPT message: {reason}{suffix}"
            )

    def find_visible_text(self, needle: str) -> ChatGPTTextMatch | None:
        payload = self._run_atspi(_FIND_TEXT, needle, operation="find_visible_text")
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise ChatGPTDesktopError("AT-SPI text search returned invalid result")
        return ChatGPTTextMatch(
            application=str(payload.get("application", "")),
            window=str(payload.get("window", "")),
            name=str(payload.get("name", "")),
            role=str(payload.get("role", "")),
            text=str(payload.get("text", "")),
        )

    def latest_response(self) -> ChatGPTTextMatch | None:
        arguments = (self._composer_hint[1],) if self._composer_hint else ()
        payload = self._run_atspi(
            _LATEST_CHATGPT_RESPONSE,
            *arguments,
            operation="latest_response",
        )
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise ChatGPTDesktopError("AT-SPI response query returned invalid result")
        return ChatGPTTextMatch(
            application=str(payload.get("application", "")),
            window=str(payload.get("window", "")),
            name=str(payload.get("name", "")),
            role=str(payload.get("role", "")),
            text=str(payload.get("text", "")),
        )

    def wait_for_new_russian_response(
        self,
        previous_text: str,
        *,
        required_text: str,
        timeout: float = 120.0,
        poll_interval: float = 0.5,
    ) -> ChatGPTTextMatch:
        deadline = time.monotonic() + timeout
        stable_text = ""
        stable_count = 0
        while time.monotonic() < deadline:
            self.activate_composer()
            match = self.latest_response()
            if (
                match is not None
                and match.text != previous_text
                and required_text.casefold() in match.text.casefold()
                and any("А" <= character.upper() <= "Я" for character in match.text)
            ):
                if match.text == stable_text:
                    stable_count += 1
                else:
                    stable_text = match.text
                    stable_count = 1
                if stable_count >= 2:
                    return match
            time.sleep(poll_interval)
        raise ChatGPTDesktopError(
            f"timed out after {timeout:.1f}s waiting for a new Russian ChatGPT response"
        )

    def wait_for_visible_text(
        self,
        needle: str,
        *,
        timeout: float = 90.0,
        poll_interval: float = 0.35,
    ) -> ChatGPTTextMatch:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            # Firefox keeps background-tab accessibility trees stale. Make
            # the exact ChatGPT document visible before reading its reply.
            self.activate_composer()
            match = self.find_visible_text(needle)
            if match is not None:
                return match
            time.sleep(poll_interval)
        raise ChatGPTDesktopError(
            f"timed out after {timeout:.1f}s waiting for visible ChatGPT reply"
        )

    def _run_atspi(
        self,
        script: str,
        *arguments: str,
        operation: str = "atspi",
    ) -> Any:
        if not Path(SNAP_COMMAND).is_file():
            raise ChatGPTDesktopError(
                f"snap command not available: {SNAP_COMMAND}"
            )
        if not (FIREFOX_PYATSPI_DIR / "pyatspi/__init__.py").is_file():
            raise ChatGPTDesktopError(
                f"Firefox pyatspi helper not available: {FIREFOX_PYATSPI_DIR}"
            )

        started = time.monotonic()
        self._diag(
            "atspi.start",
            operation=operation,
            timeout_s=self.query_timeout,
            argument_count=len(arguments),
        )
        try:
            raw = self._atspi.request(script, tuple(arguments))
        except ChatGPTDesktopError as exc:
            elapsed = time.monotonic() - started
            self._diag(
                "atspi.error",
                operation=operation,
                elapsed_ms=round(elapsed * 1000.0, 1),
                error=str(exc),
            )
            raise ChatGPTDesktopError(
                f"AT-SPI operation={operation} failed after {elapsed:.3f}s: {exc}"
            ) from exc

        elapsed = time.monotonic() - started
        self._diag(
            "atspi.worker_done",
            operation=operation,
            elapsed_ms=round(elapsed * 1000.0, 1),
            stdout_chars=len(raw),
        )
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            preview = raw[:600]
            if len(raw) > 600:
                preview += "...<truncated>"
            raise ChatGPTDesktopError(
                f"AT-SPI operation={operation} returned invalid JSON: "
                f"{preview!r}"
            ) from None

        fields: dict[str, object] = {
            "operation": operation,
            "result_type": type(payload).__name__,
        }
        if isinstance(payload, dict):
            fields["ok"] = payload.get("ok")
            reason = payload.get("reason")
            if reason:
                fields["reason"] = str(reason)[:240]
            fields["keys"] = sorted(str(key) for key in payload.keys())
        elif payload is None:
            fields["is_none"] = True
        self._diag("atspi.result", **fields)
        return payload
