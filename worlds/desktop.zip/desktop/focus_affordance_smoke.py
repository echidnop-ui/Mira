from __future__ import annotations

import os
from pathlib import Path
import subprocess
import time
from uuid import uuid4

from contracts.cognition import ActionIntent
from worlds.desktop.adapter import (
    DesktopWorldAdapter,
    FOCUS_NEXT_ACTION,
    TYPE_TEXT_ACTION,
)


_FOCUS_FIRST = r"""
import time
import pyatspi

deadline = time.monotonic() + 5.0

while time.monotonic() < deadline:
    desktop = pyatspi.Registry.getDesktop(0)

    for app_index in range(desktop.childCount):
        try:
            app = desktop.getChildAtIndex(app_index)
            if app is None or app.name != "key_target.py":
                continue
        except Exception:
            continue

        stack = [app]
        while stack:
            node = stack.pop()
            try:
                if (
                    node.getRole() == pyatspi.ROLE_TEXT
                    and node.name == "Heiwa Key First"
                    and node.queryComponent().grabFocus()
                ):
                    raise SystemExit(0)
            except Exception:
                pass

            try:
                for index in range(node.childCount):
                    child = node.getChildAtIndex(index)
                    if child is not None:
                        stack.append(child)
            except Exception:
                pass

    time.sleep(0.1)

raise SystemExit(1)
"""


def main() -> int:
    print("HEIWA DESKTOP FOCUS AFFORDANCE SMOKE")

    project_root = Path(__file__).resolve().parents[2]
    target_env = os.environ.copy()
    target_env["GDK_BACKEND"] = "wayland"
    target_env["NO_AT_BRIDGE"] = "0"

    target = subprocess.Popen(
        ("/usr/bin/python3", "-m", "worlds.desktop.key_target"),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=str(project_root),
        env=target_env,
    )

    adapter = DesktopWorldAdapter()

    try:
        focus = subprocess.run(
            ("/usr/bin/python3", "-c", _FOCUS_FIRST),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=target_env,
            timeout=7.0,
        )
        print("focus_returncode:", focus.returncode)
        if focus.returncode != 0:
            print("FOCUS AFFORDANCE SMOKE FAILED: initial focus")
            return 2

        frame = adapter.poll(time.monotonic())
        actions = tuple(affordance.action for affordance in frame.affordances)
        print("offered_actions:", actions)

        if TYPE_TEXT_ACTION not in actions or FOCUS_NEXT_ACTION not in actions:
            print("FOCUS AFFORDANCE SMOKE FAILED: expected two actions")
            return 3

        focus_affordance = next(
            affordance
            for affordance in frame.affordances
            if affordance.action == FOCUS_NEXT_ACTION
        )

        transition_id = f"desktop-focus-{uuid4().hex}"
        intent = ActionIntent(
            id=f"intent:{transition_id}:{focus_affordance.id}",
            transition_id=transition_id,
            affordance_id=focus_affordance.id,
            world=focus_affordance.world,
            action=focus_affordance.action,
            created_at=time.monotonic(),
            parameters={},
        )

        attempt = adapter.execute(intent, time.monotonic())
        print("attempt_accepted:", attempt.accepted)
        if not attempt.accepted:
            print("attempt_payload:", dict(attempt.payload))
            print("FOCUS AFFORDANCE SMOKE FAILED: attempt rejected")
            return 4

        completion = None
        deadline = time.monotonic() + 2.5
        while time.monotonic() < deadline:
            observed = adapter.poll(time.monotonic())
            for completed in observed.completed_actions:
                if completed.attempt_id == attempt.id:
                    completion = completed
                    break
            if completion is not None:
                break
            time.sleep(0.05)

        print("completion_observed:", completion is not None)
        if completion is None:
            print("FOCUS AFFORDANCE SMOKE FAILED: completion not observed")
            return 5

        print("completed_action:", completion.action)
        print("transition_preserved:", completion.transition_id == transition_id)
        print("verified_by:", completion.payload.get("verified_by"))
        print("from_control:", completion.payload.get("from_control_name"))
        print("to_control:", completion.payload.get("to_control_name"))

        if completion.action != FOCUS_NEXT_ACTION:
            print("FOCUS AFFORDANCE SMOKE FAILED: wrong action")
            return 6
        if completion.transition_id != transition_id:
            print("FOCUS AFFORDANCE SMOKE FAILED: transition_id")
            return 7
        if completion.payload.get("verified_by") != "atspi.focus_change":
            print("FOCUS AFFORDANCE SMOKE FAILED: verification")
            return 8
        if completion.payload.get("from_control_name") == completion.payload.get("to_control_name"):
            print("FOCUS AFFORDANCE SMOKE FAILED: focus did not change")
            return 9

        print(
            "CHAIN: Affordance[desktop.focus_next] -> ActionIntent -> "
            "ActionAttempt -> DesktopMotor.press_key(KEY_TAB) -> "
            "AT-SPI focus observation -> CompletedAction"
        )
        print("HEIWA DESKTOP FOCUS AFFORDANCE SMOKE: OK")
        return 0
    finally:
        adapter.close()
        if target.poll() is None:
            target.terminate()
            try:
                target.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                target.kill()


if __name__ == "__main__":
    raise SystemExit(main())
