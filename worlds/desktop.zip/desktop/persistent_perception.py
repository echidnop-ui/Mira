from __future__ import annotations

import json
import os
from pathlib import Path
import select
import subprocess
from typing import Any

from worlds.desktop.perception import (
    SYSTEM_PYTHON,
    DesktopPerception,
    DesktopPerceptionError,
    FocusedDesktopContext,
)


_ATSPI_WORKER = r'''
import json
import sys
import pyatspi


def safe_name(node):
    try:
        return getattr(node, "name", "") or ""
    except Exception:
        return ""


def safe_role(node):
    try:
        return node.getRoleName() or ""
    except Exception:
        return ""


def safe_state(node, state):
    try:
        return bool(node.getState().contains(state))
    except Exception:
        return False


def children(node):
    try:
        count = int(getattr(node, "childCount", 0))
    except Exception:
        return []
    result = []
    for index in range(count):
        try:
            child = node.getChildAtIndex(index)
        except Exception:
            continue
        if child is not None:
            result.append(child)
    return result


def traversal_children(node):
    # Firefox keeps accessibility trees for background tabs below the active
    # window. Never descend into a hidden web document: it cannot own the
    # real focused control, and walking it makes a persistent query as slow as
    # the old one-shot helpers. Non-web applications are unaffected.
    result = []
    for child in children(node):
        if (
            safe_role(child) == "document web"
            and not safe_state(child, pyatspi.STATE_SHOWING)
            and not safe_state(child, pyatspi.STATE_FOCUSED)
        ):
            continue
        result.append(child)
    return result


def safe_text_snapshot(node):
    try:
        text_iface = node.queryText()
        count = int(text_iface.characterCount)
        text = text_iface.getText(0, count)
        caret = int(text_iface.caretOffset)
        if caret < 0:
            caret = None
        return text, caret
    except Exception:
        return None, None


def payload(app_name, window_name, node):
    text, caret = safe_text_snapshot(node)
    return {
        "application": app_name,
        "window": window_name,
        "name": safe_name(node),
        "role": safe_role(node),
        "focused": safe_state(node, pyatspi.STATE_FOCUSED),
        "focusable": safe_state(node, pyatspi.STATE_FOCUSABLE),
        "editable": safe_state(node, pyatspi.STATE_EDITABLE),
        "text": text,
        "caret_offset": caret,
    }


def focused_context():
    desktop = pyatspi.Registry.getDesktop(0)
    active_windows = []

    for app in children(desktop):
        app_name = safe_name(app)
        for window in children(app):
            if not (
                safe_state(window, pyatspi.STATE_ACTIVE)
                or safe_state(window, pyatspi.STATE_FOCUSED)
            ):
                continue
            active_windows.append((app_name, safe_name(window), window))

    active_windows.sort(key=lambda item: item[0] == "gnome-shell")

    for app_name, window_name, window in active_windows:
        best = None
        stack = [(window, 0)]
        while stack:
            node, depth = stack.pop()
            if safe_state(node, pyatspi.STATE_FOCUSED):
                role = safe_role(node)
                editable = safe_state(node, pyatspi.STATE_EDITABLE)
                focusable = safe_state(node, pyatspi.STATE_FOCUSABLE)
                score = depth
                if role not in {"application", "frame", "window"}:
                    score += 40
                if editable:
                    score += 30
                if role == "text":
                    score += 20
                if focusable:
                    score += 5
                candidate = (score, node)
                if best is None or candidate[0] > best[0]:
                    best = candidate
            stack.extend((child, depth + 1) for child in traversal_children(node))

        if best is not None:
            return payload(app_name, window_name, best[1])

    return None


def target_context(request):
    desktop = pyatspi.Registry.getDesktop(0)
    target_application = request["application"]
    target_window = request["window"]
    target_name = request["name"]
    target_role = request["role"]

    for app in children(desktop):
        if safe_name(app) != target_application:
            continue
        for window in children(app):
            if safe_name(window) != target_window:
                continue
            stack = [window]
            while stack:
                node = stack.pop()
                if safe_name(node) == target_name and safe_role(node) == target_role:
                    return payload(safe_name(app), safe_name(window), node)
                stack.extend(traversal_children(node))
    return None


def focus_control(request):
    # Training/environment reset only. This operation is never exposed as a
    # World Affordance and is never available to Policy.
    desktop = pyatspi.Registry.getDesktop(0)
    target_window = request["window"]
    target_name = request["name"]
    target_role = request.get("role")

    for app in children(desktop):
        for window in children(app):
            if safe_name(window) != target_window:
                continue
            stack = [window]
            while stack:
                node = stack.pop()
                if safe_name(node) == target_name and (
                    target_role is None or safe_role(node) == target_role
                ):
                    try:
                        focused = bool(node.queryComponent().grabFocus())
                    except Exception:
                        focused = False
                    return {
                        "focused": focused,
                        "context": payload(safe_name(app), safe_name(window), node),
                    }
                stack.extend(children(node))
    return {"focused": False, "context": None}


handlers = {
    "focused_context": lambda request: focused_context(),
    "target_context": target_context,
    "focus_control": focus_control,
}

print(json.dumps({"ready": True}), flush=True)

for raw in sys.stdin:
    raw = raw.strip()
    if not raw:
        continue
    try:
        request = json.loads(raw)
        operation = request.get("operation")
        handler = handlers.get(operation)
        if handler is None:
            raise ValueError("unknown AT-SPI worker operation: %r" % (operation,))
        result = handler(request)
        response = {"ok": True, "result": result}
    except Exception as exc:
        response = {"ok": False, "error": repr(exc)}
    print(json.dumps(response, ensure_ascii=False), flush=True)
'''


class PersistentDesktopPerception(DesktopPerception):
    """
    DesktopPerception backed by one long-lived system-Python/AT-SPI worker.

    The public sensor contract is the same as DesktopPerception, so the
    existing DesktopWorldAdapter can use it without modification. Repeated
    queries use a line-delimited JSON pipe instead of spawning Python for every
    observation.
    """

    def __init__(
        self,
        *,
        system_python: str = SYSTEM_PYTHON,
        timeout: float = 1.0,
        startup_timeout: float = 4.0,
    ) -> None:
        super().__init__(system_python=system_python, timeout=timeout)
        self.startup_timeout = float(startup_timeout)
        if self.startup_timeout <= 0.0:
            raise ValueError("startup_timeout must be > 0")
        self._process: subprocess.Popen[str] | None = None

    def focused_context(self) -> FocusedDesktopContext | None:
        result = self._request({"operation": "focused_context"})
        return self._decode_context(result)

    def target_context(
        self,
        *,
        application: str,
        window: str,
        name: str,
        role: str,
    ) -> FocusedDesktopContext | None:
        result = self._request(
            {
                "operation": "target_context",
                "application": application,
                "window": window,
                "name": name,
                "role": role,
            }
        )
        return self._decode_context(result)

    def focus_control_for_training(
        self,
        *,
        window: str,
        name: str,
        role: str | None = None,
    ) -> bool:
        """
        Reset a training fixture through AT-SPI.

        This is deliberately not part of DesktopWorldAdapter and is never an
        Affordance. It exists only so a local curriculum can reset its fixture
        between independent Policy attempts without launching a new helper
        process every time.
        """

        request: dict[str, object] = {
            "operation": "focus_control",
            "window": window,
            "name": name,
        }
        if role is not None:
            request["role"] = role
        result = self._request(request)
        return bool(isinstance(result, dict) and result.get("focused"))

    def close(self) -> None:
        process = self._process
        self._process = None
        if process is None:
            return
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=1.0)

    def __enter__(self) -> "PersistentDesktopPerception":
        self._ensure_worker()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _ensure_worker(self) -> subprocess.Popen[str]:
        process = self._process
        if process is not None and process.poll() is None:
            return process

        if not Path(self.system_python).is_file():
            raise DesktopPerceptionError(
                f"system Python not available: {self.system_python}"
            )

        env = os.environ.copy()
        env["NO_AT_BRIDGE"] = "0"
        try:
            process = subprocess.Popen(
                (self.system_python, "-u", "-c", _ATSPI_WORKER),
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                bufsize=1,
                env=env,
            )
        except OSError as exc:
            raise DesktopPerceptionError(
                f"failed to start persistent AT-SPI worker: {exc}"
            ) from exc

        self._process = process
        ready = self._read_line(process, timeout=self.startup_timeout)
        try:
            payload: Any = json.loads(ready)
        except json.JSONDecodeError as exc:
            self.close()
            raise DesktopPerceptionError(
                f"persistent AT-SPI worker returned invalid handshake: {ready!r}"
            ) from exc
        if not isinstance(payload, dict) or payload.get("ready") is not True:
            self.close()
            raise DesktopPerceptionError(
                f"persistent AT-SPI worker failed handshake: {payload!r}"
            )
        return process

    def _request(self, request: dict[str, object]) -> Any:
        process = self._ensure_worker()
        if process.stdin is None:
            self.close()
            raise DesktopPerceptionError("AT-SPI worker stdin is unavailable")

        try:
            process.stdin.write(json.dumps(request, ensure_ascii=False) + "\n")
            process.stdin.flush()
        except (BrokenPipeError, OSError) as exc:
            self.close()
            raise DesktopPerceptionError(
                f"failed to send request to AT-SPI worker: {exc}"
            ) from exc

        raw = self._read_line(process, timeout=self.timeout)
        try:
            payload: Any = json.loads(raw)
        except json.JSONDecodeError as exc:
            self.close()
            raise DesktopPerceptionError(
                f"persistent AT-SPI worker returned invalid JSON: {raw!r}"
            ) from exc

        if not isinstance(payload, dict):
            raise DesktopPerceptionError(
                "persistent AT-SPI worker returned unexpected payload"
            )
        if payload.get("ok") is not True:
            raise DesktopPerceptionError(
                "persistent AT-SPI worker query failed: "
                + str(payload.get("error", "unknown error"))
            )
        return payload.get("result")

    def _read_line(
        self,
        process: subprocess.Popen[str],
        *,
        timeout: float,
    ) -> str:
        stdout = process.stdout
        if stdout is None:
            self.close()
            raise DesktopPerceptionError("AT-SPI worker stdout is unavailable")

        readable, _, _ = select.select([stdout], [], [], timeout)
        if not readable:
            self.close()
            raise DesktopPerceptionError(
                f"persistent AT-SPI worker timed out after {timeout}s"
            )
        line = stdout.readline()
        if not line:
            code = process.poll()
            self.close()
            raise DesktopPerceptionError(
                f"persistent AT-SPI worker exited unexpectedly: returncode={code}"
            )
        return line.strip()

    @staticmethod
    def _decode_context(payload: Any) -> FocusedDesktopContext | None:
        if payload is None:
            return None
        if not isinstance(payload, dict):
            raise DesktopPerceptionError("AT-SPI context payload is not a dict")

        text = payload.get("text")
        caret = payload.get("caret_offset")
        return FocusedDesktopContext(
            application=str(payload.get("application", "")),
            window=str(payload.get("window", "")),
            name=str(payload.get("name", "")),
            role=str(payload.get("role", "")),
            focused=bool(payload.get("focused", False)),
            focusable=bool(payload.get("focusable", False)),
            editable=bool(payload.get("editable", False)),
            text=text if isinstance(text, str) else None,
            caret_offset=caret if isinstance(caret, int) else None,
        )
