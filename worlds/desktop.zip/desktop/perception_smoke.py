from __future__ import annotations

import os
from pathlib import Path
import subprocess
import time

from worlds.desktop.perception import (
    DesktopPerception,
    DesktopPerceptionError,
)


_FOCUS_TARGET = r"""
import time
import pyatspi

deadline = time.monotonic() + 5.0

while time.monotonic() < deadline:
    desktop = pyatspi.Registry.getDesktop(0)

    for app_index in range(desktop.childCount):
        try:
            app = desktop.getChildAtIndex(app_index)
            if app is None or app.name != "motor_target.py":
                continue
        except Exception:
            continue

        stack = [app]

        while stack:
            node = stack.pop()

            try:
                if (
                    node.getRole() == pyatspi.ROLE_TEXT
                    and node.queryComponent().grabFocus()
                ):
                    raise SystemExit(0)
            except Exception:
                pass

            try:
                for index in range(node.childCount):
                    child = node.getChildAtIndex(index)
                    if child is not None:
                        stack.append(child)
            except Exception:
                pass

    time.sleep(0.1)

raise SystemExit(1)
"""


def main() -> int:
    print("HEIWA DESKTOP PERCEPTION SMOKE")

    project_root = Path(__file__).resolve().parents[2]

    target_env = os.environ.copy()
    target_env["GDK_BACKEND"] = "wayland"
    target_env["NO_AT_BRIDGE"] = "0"

    target = subprocess.Popen(
        (
            "/usr/bin/python3",
            "-m",
            "worlds.desktop.motor_target",
        ),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=str(project_root),
        env=target_env,
    )

    try:
        focus = subprocess.run(
            (
                "/usr/bin/python3",
                "-c",
                _FOCUS_TARGET,
            ),
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=target_env,
            timeout=7.0,
        )

        print("focus_returncode:", focus.returncode)

        if focus.returncode != 0:
            print("focus_stderr:", focus.stderr.strip())
            print("PERCEPTION SMOKE FAILED: target focus")
            return 2

        perception = DesktopPerception()

        context = None
        deadline = time.monotonic() + 3.0

        while time.monotonic() < deadline:
            try:
                context = perception.focused_context()
            except DesktopPerceptionError as exc:
                print("PERCEPTION SMOKE FAILED:", str(exc))
                return 3

            if (
                context is not None
                and context.application == "motor_target.py"
                and context.window == "Heiwa Motor Smoke"
            ):
                break

            time.sleep(0.1)

        if context is None:
            print("PERCEPTION SMOKE FAILED: no focused context")
            return 4

        print("application:", context.application)
        print("window:", context.window)
        print("name:", context.name)
        print("role:", context.role)
        print("focused:", context.focused)
        print("focusable:", context.focusable)
        print("editable:", context.editable)

        if context.application != "motor_target.py":
            print("PERCEPTION SMOKE FAILED: wrong focused application")
            return 5

        if context.window != "Heiwa Motor Smoke":
            print("PERCEPTION SMOKE FAILED: wrong focused window")
            return 6

        if context.role != "text":
            print("PERCEPTION SMOKE FAILED: focused control is not text")
            return 7

        if not context.focused:
            print("PERCEPTION SMOKE FAILED: control is not focused")
            return 8

        if not context.editable:
            print("PERCEPTION SMOKE FAILED: control is not editable")
            return 9

        print(
            "CHAIN: GNOME/Wayland -> AT-SPI -> "
            "DesktopPerception -> focused semantic control"
        )
        print("HEIWA DESKTOP PERCEPTION SMOKE: OK")
        return 0

    finally:
        if target.poll() is None:
            target.terminate()
            try:
                target.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                target.kill()


if __name__ == "__main__":
    raise SystemExit(main())
